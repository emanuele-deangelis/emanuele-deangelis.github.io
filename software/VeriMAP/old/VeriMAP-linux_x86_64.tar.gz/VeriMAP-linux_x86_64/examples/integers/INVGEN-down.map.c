# 1 "MAP/SAFE-exbench/INVGEN-down.tmp.c"
# 1 "<command-line>"
# 1 "MAP/SAFE-exbench/INVGEN-down.tmp.c"
# 20 "MAP/SAFE-exbench/INVGEN-down.tmp.c"
void main() {
  int n;
  int k = 0;
  int i = 0;
  ;
  while( i < n ) {
 i++;
 k++;
  }
  int j = n;
  while( j > 0 ) {
 __VERIFIER_assert( k > 0 );
 j--;
 k--;
  }
}
