int y;
int incr(int z) { z = z+y; y=0; }
void main() {
  int x;
  __VERIFIER_assume(y >= 0);
  if (x < y) {
    x = incr(x);
    if (x >= y) 
      goto END;
  }
  while (x < y) 
    x=x+1;
  END: __VERIFIER_assert(x >= 0);
}
