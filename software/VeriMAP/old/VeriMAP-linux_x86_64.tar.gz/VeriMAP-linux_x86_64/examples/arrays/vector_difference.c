/*
  From: "On Solving Universally Quantified Horn Clauses"
  Bjorner, McMillan, and Rybalchenko
  SAS 2013
*/


int i;
int n;
int a[n];
int b[n];
int c[n];

void main() {
  
  while (i < n) {
    c[i] = a[i] - b[i];
    i = i + 1;
  }

}

/*
  
  % MAP_specification:

  phiInit(G) :-
    lookup(scalar(int(n)),G,N), 
    lookup(array(int(a)),G,(A,[N])),
    lookup(array(int(b)),G,(B,[N])),
    lookup(array(int(c)),G,(C,[N])),
    lookup(scalar(int(i)),G,I), 
    N>=0, I=:=0.

  phiError(G) :- 
    lookup(array(int(a)),G,(A,[N])), read((A,[N]),[K1],X),
    lookup(array(int(b)),G,(B,[N])), read((B,[N]),[K2],Y),
    lookup(array(int(c)),G,(C,[N])), read((C,[N]),[K3],Z),
    K1>=0, K1+1=<N, Z >= X-Y+1, K1=:=K2, K2=:=K3.

  phiError(G) :- 
    lookup(array(int(a)),G,(A,[N])), read((A,[N]),[K1],X),
    lookup(array(int(b)),G,(B,[N])), read((B,[N]),[K2],Y),
    lookup(array(int(c)),G,(C,[N])), read((C,[N]),[K3],Z),
    K1>=0, K1+1=<N, Z+1 =< X-Y, K1=:=K2, K2=:=K3.

*/
