/*
 * Copies elements of b to a.
 */

/*

  Original from dillig-esop2010-casestudy.txt

void copy(int* a, int*b,  int size)
{
  int i;
  for(i=0; i<size; i++) 
  {
	a[i] = b[i];
  }

  for(i=0; i<size; i++)
  {
	static_assert(a[i] == b[i]);
  }
}

*/

int i;
int size;
int a[size];
int b[size];  

void main()
{
  for(i=0; i<size; i++) 
  {
	a[i] = b[i];
  }
}

/*
  % MAP_specification

  phiInit(G) :-  
    lookup(scalar(int(size)),G,Size), lookup(array(int(a)),G,(A,[Size])), lookup(scalar(int(b)),G,(B,[Size])),
    Size>=0.

  phiError(G) :-
    lookup(array(int(a)),G,(A,[Size])), lookup(array(int(b)),G,(B,[Size])),
    K>=0, Size-K>=1, J-I>=1, K=:=K1,
    read((A,[Size]),[K],I), read((B,[Size]),[K1],J).

  phiError(G) :-
    lookup(array(int(a)),G,(A,[Size])), lookup(array(int(b)),G,(B,[Size])),
    K>=0, Size-K>=1, I-J>=1, K=:=K1,
    read((A,[Size]),[K],I), read((B,[Size]),[K1],J).

*/
