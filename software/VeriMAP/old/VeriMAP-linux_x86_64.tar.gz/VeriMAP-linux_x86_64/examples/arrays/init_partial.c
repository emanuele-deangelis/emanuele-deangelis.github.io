/*
 * Initializes num_to_init number of elements of a to 0.
 */

/*

void init_partial(int* a, int size, int num_to_init)
{
  assert(num_to_init <= size);
  int i;
  for(i=0; i<num_to_init; i++) 
  {
	a[i] = 0;
  }

  for(i=0; i<num_to_init; i++)
  {
	static_assert(a[i] == 0);
  }
}

*/

int i;
int num_to_init;
int size;
int a[size];

void main()
{
  for(i=0; i<num_to_init; i++) 
  {
	a[i] = 0;
  }
}


/*

  % MAP_specification

  phiInit(G) :-  lookup(scalar(int(size)),G,Size), lookup(array(int(a)),G,(A,[Size])), lookup(scalar(int(num_to_init)),G,NInit),
                 Size>=0, NInit=<Size.

  phiError(G) :- lookup(scalar(int(size)),G,Size), lookup(array(int(a)),G,(A,[Size])), lookup(scalar(int(num_to_init)),G,NInit),
                 K>=0, K+1=<NInit, M>=1, read((A,[Size]),[K],M).
  phiError(G) :- lookup(scalar(int(size)),G,Size), lookup(array(int(a)),G,(A,[Size])), lookup(scalar(int(num_to_init)),G,NInit),
                 K>=0, K+1=<NInit, M+1=<0, read((A,[Size]),[K],M).

*/
