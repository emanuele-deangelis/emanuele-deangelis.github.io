/*
 * Reverses array a and checks it is reversed for 
 * any k between 0 and size-1.
 */

/* 

   Original from dillig-esop2010-casestudy.txt

void reverse(int* a, int size, int k)
{	
	int i;
	int* a_copy = malloc(sizeof(int)*size);
	for(i=0; i<size; i++)
	{
		a_copy[i] = a[i];
	}
	
	for(i=0; i<size; i++)
	{
		a[i] = a_copy[size-1-i];
	}
	
	if(k>=0 && k<size)
	{
		static_assert(a[k] == a_copy[size-1-k]);
	}

	free(a_copy);	
}

*/

int i;
int size;
int a[size];
int a_copy[size];

void main()
{	
	for(i=0; i<size; i++)
	{
		a_copy[i] = a[i];
	}
	
	for(i=0; i<size; i++)
	{
		a[i] = a_copy[size-1-i];
	}
}

/*

  % MAP_specification

  phiInit(G) :-  lookup(scalar(int(size)),G,Size), 
                 lookup(array(int(a)),G,(A,[Size])), lookup(array(int(a_copy)),G,(ACopy,[Size])),
                 Size>=0.

  phiError(G) :- lookup(array(int(a)),G,(A,[Size])), lookup(array(int(a_copy)),G,(ACopy,[Size])),
                 K>=0, K+1=<Size, K1=:=Size-K-1, X+1=<Y, read((A,[Size]),[K],X), read((ACopy,[Size]),[K1],Y).
  phiError(G) :- lookup(array(int(a)),G,(A,[Size])), lookup(array(int(a_copy)),G,(ACopy,[Size])),
                 K>=0, K+1=<Size, K1=:=Size-K-1, Y+1=<X, read((A,[Size]),[K],X), read((ACopy,[Size]),[K1],Y).

*/
