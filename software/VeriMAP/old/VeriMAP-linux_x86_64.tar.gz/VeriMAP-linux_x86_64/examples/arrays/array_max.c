int i;
int n;
int a[n]; 
int max; 

void main() {
   
  while (i < n) {

    if(a[i] > max)
      max=a[i];

    i = i + 1;
  }

}

/*

  % MAP_specification

  phiInit(G) :-  
    lookup(scalar(int(i)),G,I), lookup(scalar(int(n)),G,N), lookup(array(int(a)),G,(A,[N])), lookup(scalar(int(max)),G,Max), 
    I=:=0, N>=1, Max=:=M, I>=0, I+1=<N, read((A,[N]),[I],M).

  phiError(G) :-
    lookup(array(int(a)),G,(A,[N])), lookup(scalar(int(max)),G,Max),
    K>=0, K+1=<N, Max+1=<M, read((A,[N]),[K],M).

*/
