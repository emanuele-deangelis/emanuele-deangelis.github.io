/*  
 * Copies non-negative elements of A to B 
 * and copies negative elements of A to C

/*

  Original from VMCAI13

int main()
{
  const int N;
  assume(N >= 0);
  int A[N], B[N], C[N];

  int a=0, b=0, c=0;
  while (a < N) 
  {
    if (A[a] >= 0) {
      B[b]=A[a];
      b++;
    } else {
      C[c]=A[a];
      c++;
    }
    ++a;
  }
}



*/


int size;
int a[size];
int b[size];  
int c[size];  
int i=0, j=0, k=0;

void main()
{

  while (i < size) 
  {
    if (a[i] >= 0) {
      b[j]=a[i];
      j++;
    } else {
      c[k]=a[i];
      k++;
    }
    ++i;
  }
}



/*
  % MAP_specification

  phiInit(G) :-  
    lookup(scalar(int(size)),G,Size), lookup(array(int(a)),G,(A,[Size])), 
    lookup(array(int(b)),G,(B,[Size])), lookup(array(int(c)),G,(C,[Size])),
    Size>=0.

  phiError(G) :-
    lookup(array(int(b)),G,(B,[Size])), 
    lookup(scalar(int(j)),G,J), 
    M>=0, J-M>=1, 0 >= X+1, read((B,[Size]),[M],X).

  phiError(G) :-
    lookup(array(int(c)),G,(C,[Size])), 
    lookup(scalar(int(k)),G,K), 
    M>=0, K-M>=1, X>=0, read((C,[Size]),[M],X).

*/

