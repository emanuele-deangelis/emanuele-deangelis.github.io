int i;
int n;
int a[n];

void main() {

   i=1;
   a[0]=7;

   while (i < n) {
      a[i]=a[i-1] + 1;
      i++;
   }

}

/*

  % MAP_specification

  phiInit(G) :- 
    lookup(scalar(int(n)),G,N), 
    lookup(array(int(a)),G,(A,[N])), N>=0.

  % k1=k+1 AND a[k1] != a[k] + 1
  phiError(G) :- lookup(array(int(a)),G,(A,[N])), 
     K>=0, K+1=<N, K1>=0, K1+1=<N, K1=:=K+1, J=<I,
     read((A,[N]),[K],I), read((A,[N]),[K1],J).

  phiError(G) :- lookup(array(int(a)),G,(A,[N])), 
    K>=0, K+1=<N, K1>=0, K1+1=<N, K1=:=K+1, J>=I+2, 
    read((A,[N]),[K],I), read((A,[N]),[K1],J).

*/
