int x=0;
int y=0;
int n;

void main() {

  while (x < n) {
    x = x + 1; 
    y = y + x; 
  }

  __VERIFIER_assert( x<=y );

}
