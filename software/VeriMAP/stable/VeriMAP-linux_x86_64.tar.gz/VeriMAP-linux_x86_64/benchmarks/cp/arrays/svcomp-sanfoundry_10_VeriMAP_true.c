/*
extern void __VERIFIER_error() __attribute__ ((__noreturn__));
void __VERIFIER_assert(int cond) { if(!(cond)) { ERROR: __VERIFIER_error(); } }
*/
/*
 * Adapted from http://www.sanfoundry.com/c-programming-examples-arrays/
 * C program to accept an array of integers and delete the
 * specified integer from the list
 */
/*
int main()
{
    int i;
    int n = 100000;
    int pos;
    int element;
    int found = 0;
    int vectorx[n];
 
    for (i = 0; i < n && !found; i++)
    {
        if (vectorx[i] == element)
        {
            found = 1;
            pos = i;
        }
    }
    if ( found )
    {
        for (i = pos; i <  n - 1; i++)
        {
            vectorx[i] = vectorx[i + 1];
        }
    }
    
    if ( found ) {
      int x;
      for ( x = 0 ; x < pos ; x++ ) {
        __VERIFIER_assert(  vectorx[x] != element  );
      }
    }
  return 0;
}
*/

int i;
int i1;
int n;
int pos;
int element;
int found = 0;
int vectorx[n];

int main()
{

 
    for (i = 0; i < n && !found; i++)
    {
        if (vectorx[i] == element)
        {
            found = 1;
            pos = i;
        }
    }
    if ( found )
    {
        for (i = pos; i <  n - 1; i++)
        {  
            i1 = i + 1;
            vectorx[i] = vectorx[i1];
        }
    }
    
    /*
    if ( found ) {
      int x;
      for ( x = 0 ; x < pos ; x++ ) {
        __VERIFIER_assert(  vectorx[x] != element  );
      }
    }
    */
    /*@
      requires n>=1;
      ensures found==1 ==> (\forall integer x; 0<=x<pos ==> vectorx[x]!=element);
    */
  return 0;
}
