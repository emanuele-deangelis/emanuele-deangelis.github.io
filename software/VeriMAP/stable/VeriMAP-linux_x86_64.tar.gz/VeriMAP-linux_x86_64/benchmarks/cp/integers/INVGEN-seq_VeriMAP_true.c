# 1 "MAP/SAFE-exbench/INVGEN-seq.tmp.c"
# 1 "<command-line>"
# 1 "MAP/SAFE-exbench/INVGEN-seq.tmp.c"
# 20 "MAP/SAFE-exbench/INVGEN-seq.tmp.c"
void main() {
  int n0, n1;
  int i0 = 0;
  int k = 0;

  while( i0 < n0 ) {
    ;
    i0++;
    k++;
  }
  int i1 = 0;
  while( i1 < n1 ) {
    ;
    i1++;
    k++;
  }
  int j1 = 0;
  while( j1 < n0 + n1 ) {
    ;
    if(k <= 0) ERROR: goto ERROR;
    j1++;
    k--;
  }
}
