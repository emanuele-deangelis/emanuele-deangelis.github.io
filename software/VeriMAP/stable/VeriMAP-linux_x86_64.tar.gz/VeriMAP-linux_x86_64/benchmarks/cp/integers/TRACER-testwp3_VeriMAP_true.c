# 1 "MAP/SAFE-exbench/TRACER-testwp3.tmp.c"
# 1 "<command-line>"
# 1 "MAP/SAFE-exbench/TRACER-testwp3.tmp.c"
# 21 "MAP/SAFE-exbench/TRACER-testwp3.tmp.c"
void main(){
  int x,y;

  if (y>0)


    x=2;
  else{


    x=47;
  }




  x++;
  x=x+2;


  __VERIFIER_assert(!( x > 50 ));

}
