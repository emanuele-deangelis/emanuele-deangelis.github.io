% Progs/0_src/09_COMP/09.08_twice_array_sum.transformed/p1.c.map.transform.pl
p13(A,B,C,D,E,F,G,H) :- I=:=C+rat(2,1)*J, K=:=rat(1,1)+L, D=:=L, A-L>=rat(1,1), 
          read((B,A),L,J), val(i,K), val(s1,I), val(n,A), val(a,B), val(s1,C), 
          val(i,D), val(n,E), val(a,F), val(s1,G), val(i,H), 
          p13(A,B,I,K,E,F,G,H).
p13(A,B,C,D,A,B,C,D) :- D-A>=rat(0,1), val(i,D), val(s1,C), val(a,B), val(n,A).
p12(A,B,C,D,E,F,G,H) :- val(n,A), val(a,B), val(s1,C), val(i,D), val(n,E), 
          val(a,F), val(s1,G), val(i,H), p13(A,B,C,D,E,F,G,H).
p11(A,B,C) :- D=:=rat(0,1), E=:=rat(0,1), val(i,F), val(a,G), val(n,H), 
          val(i,E), val(s1,D), p12(A,B,D,E,H,G,C,F).

verimap(pred_smtvars_types([specint,p11('Int','(Array Int Int)','Int'),p12('Int','(Array Int Int)','Int','Int','Int','(Array Int Int)','Int','Int'),p13('Int','(Array Int Int)','Int','Int','Int','(Array Int Int)','Int','Int')])).

% Progs/0_src/09_COMP/09.08_twice_array_sum.transformed/p2.c.map.transform.pl
p25(A,B,C,D,E,F,G,H) :- I=:=C+J, K=:=rat(1,1)+L, D=:=L, A-L>=rat(1,1), 
          read((B,A),L,J), val(i,K), val(s2,I), val(n,A), val(a,B), val(s2,C), 
          val(i,D), val(n,E), val(a,F), val(s2,G), val(i,H), 
          p25(A,B,I,K,E,F,G,H).
p25(A,B,C,D,A,B,C,D) :- D-A>=rat(0,1), val(i,D), val(s2,C), val(a,B), val(n,A).
p24(A,B,C,D,E,F,G,H) :- I=:=C+J, K=:=rat(1,1)+L, D=:=L, A-L>=rat(1,1), 
          read((B,A),L,J), val(i,K), val(s2,I), val(n,A), val(a,B), val(s2,C), 
          val(i,D), val(n,E), val(a,F), val(s2,G), val(i,H), 
          p24(A,B,I,K,E,F,G,H).
p24(A,B,C,D,A,B,C,D) :- D-A>=rat(0,1), val(i,D), val(s2,C), val(a,B), val(n,A).
p23(A,B,C,D,E,F,G,H) :- val(n,A), val(a,B), val(s2,C), val(i,D), val(n,E), 
          val(a,F), val(s2,G), val(i,H), p24(A,B,C,D,E,F,G,H).
p22(A,B,C,D,E,F,G,H) :- val(n,A), val(a,B), val(s2,C), val(i,D), val(n,E), 
          val(a,F), val(s2,G), val(i,H), p25(A,B,C,D,E,F,G,H).
p21(A,B,C) :- D=:=rat(0,1), E=:=rat(0,1), F=:=rat(0,1), val(i,G), val(a,H), 
          val(n,I), val(i,D), val(s2,J), val(a,K), val(n,L), val(s2,E), 
          val(i,F), val(i,M), p22(A,B,E,F,L,K,J,M), p23(L,K,J,D,I,H,C,G).

verimap(pred_smtvars_types([specint,p21('Int','(Array Int Int)','Int'),p22('Int','(Array Int Int)','Int','Int','Int','(Array Int Int)','Int','Int'),p23('Int','(Array Int Int)','Int','Int','Int','(Array Int Int)','Int','Int'),p24('Int','(Array Int Int)','Int','Int','Int','(Array Int Int)','Int','Int'),p25('Int','(Array Int Int)','Int','Int','Int','(Array Int Int)','Int','Int')])).

% Progs/0_src/09_COMP/09.08_twice_array_sum/relprop
incorrect :- N>=1, Sum1=\=Sum2, p11(N,A,Sum1), p21(N,A,Sum2), 
  val(n,N), val(a,A), val(s1,Sum1), val(s2,Sum2). 

verimap(pred_smtvars_types([incorrect])).

verimap(data_types([array-int,bool,uint,long,int])).
