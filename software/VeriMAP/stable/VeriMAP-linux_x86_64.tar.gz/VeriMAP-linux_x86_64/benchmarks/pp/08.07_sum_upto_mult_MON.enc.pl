% Progs/0_src/09_COMP/09.07_sum_upto_mult_MON.transformed/p1.c.map.transform.pl
p12(A,B,C,D,E,F) :- G=<H, G=:=C, H=:=A, I=:=J+K, J=:=B, K=:=C, L=:=M+N, M=:=C, 
          N=:=1, p12(A,I,L,D,E,F).
p12(A,B,C,A,B,C) :- D>=E+1, D=:=C, E=:=A.
p11(A,B) :- C=:=0, D=:=0, p12(A,D,C,E,B,F).

% Progs/0_src/09_COMP/09.07_sum_upto_mult_MON.transformed/p2.c.map.transform.pl
p23(A,B,C,D,E,F,G,H,I,J) :- K=<L, K=:=D, L=:=B, M=:=N+O, N=:=C, O=:=E, P=:=Q+R, 
          Q=:=D, R=:=1, p23(A,B,M,P,E,F,G,H,I,J).
p23(A,B,C,D,E,A,B,C,D,E) :- F>=G+1, F=:=D, G=:=B.
p22(A,B,C,D,E,F,G,H,I,J) :- K=<L, K=:=D, L=:=A, M=:=N+O, N=:=C, O=:=D, P=:=Q+R, 
          Q=:=D, R=:=1, p22(A,B,M,P,E,F,G,H,I,J).
p22(A,B,C,D,E,F,G,H,I,J) :- K>=L+1, K=:=D, L=:=A, M=:=N-O, N=:=D, O=:=1, 
          p23(A,B,C,D,M,F,G,H,I,J).
p21(A,B,C) :- D=:=0, E=:=0, p22(A,B,E,D,F,G,H,C,I,J).

% Progs/0_src/09_COMP/09.07_sum_upto_mult_MON/relprop
% {N>=1, N=<M1, M2=M1} p21~p11 {Sum1=<Sum2}
incorrect :- N>=1, N=<M1, M2=M1, Sum1>=Sum2+1, p21(N,M1,Sum1), p11(M2,Sum2). 
