% Progs/compopt/pre01.transformed/1.c.map.transform.pl
new12(A,B,C,D,E,F) :- G>=H+1, G=:=C, H=:=0, F=:=I+J, I=:=C, J=:=1, D=:=F, E=:=F.
new12(A,B,C,A,D,E) :- F=<G, F=:=C, G=:=0, E=:=H+I, H=:=C, I=:=1, D=:=E.
new11(A,B,C) :- new12(D,A,B,E,C,F).
specint :- new11(A,B,C).

verimap(pred_smtvars_types([specint,new11('Int','Int','Int'),new12('Int','Int','Int','Int','Int','Int')])).

% Progs/compopt/pre01.transformed/2.c.map.transform.pl
new22(A,B,C,D,E,F) :- G>=H+1, G=:=C, H=:=0, F=:=I+J, I=:=C, J=:=1, D=:=F, E=:=D.
new22(A,B,C,A,D,E) :- F=<G, F=:=C, G=:=0, E=:=H+I, H=:=C, I=:=1, D=:=E.
new21(A,B,C) :- new22(D,A,B,E,C,F).
specint :- new21(A,B,C).

verimap(pred_smtvars_types([incorrect,new21('Int','Int','Int'),new22('Int','Int','Int','Int','Int','Int')])).

% Progs/compopt/pre01/relprop
incorrect :- X1=\=X2, new11(A,B,X1), new21(A,B,X2).
