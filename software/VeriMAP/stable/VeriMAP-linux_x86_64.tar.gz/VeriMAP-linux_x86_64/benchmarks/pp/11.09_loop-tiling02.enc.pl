% Progs/compopt/loop-tiling02.transformed/1.c.map.transform.pl
new13(A,B,C,A,B,C) :- D>=E, D=:=A, E=:=B.
new13(A,B,C,D,E,F) :- G+1=<H, G=:=A, H=:=B, I=:=J+K, J=:=C, K=:=1, L=:=M+N, 
          M=:=A, N=:=1, new13(L,B,I,D,E,F).
new12(A,B,C,D,E,F) :- G=:=0, new13(G,B,C,D,E,F).
new11(A,B,C,D) :- new12(A,B,C,E,F,D).

verimap(pred_smtvars_types([specint,new11('Int','Int','Int','Int'),new12('Int','Int','Int','Int','Int','Int'),new13('Int','Int','Int','Int','Int','Int')])).

% Progs/compopt/loop-tiling02.transformed/2.c.map.transform.pl
new24(A,B,C,D,E,F,G,H,I,J) :- K+1=<L, K=:=C, L=:=D, M=:=N+O, N=:=E, O=:=1, 
          P=:=Q+R, Q=:=C, R=:=1, new24(A,B,P,D,M,F,G,H,I,J).
new24(A,B,C,D,E,F,G,H,I,J) :- K>=L, K=:=C, L=:=D, M=:=N+O, N=:=A, O=:=D, 
          new23(M,B,C,D,E,F,G,H,I,J).
new23(A,B,C,D,E,A,B,C,D,E) :- F>=G, F=:=A, G=:=B.
new23(A,B,C,D,E,F,G,H,I,J) :- K+1=<L, K=:=A, L=:=B, M=:=0, 
          new24(A,B,M,D,E,F,G,H,I,J).
new22(A,B,C,D,E,F,G,H,I,J) :- K=:=0, new23(K,B,C,D,E,F,G,H,I,J).
new21(A,B,C,D,E) :- new22(A,B,F,C,D,G,H,I,J,E).

verimap(pred_smtvars_types([incorrect,new21('Int','Int','Int','Int','Int'),new22('Int','Int','Int','Int','Int','Int','Int','Int','Int','Int'),new23('Int','Int','Int','Int','Int','Int','Int','Int','Int','Int'),new24('Int','Int','Int','Int','Int','Int','Int','Int','Int','Int')])).

% Progs/compopt/loop-tiling02/relprop
incorrect :- C=:=B, X1=\=X2, new11(A,B,X,X1), new21(A,B,C,X,X2).
