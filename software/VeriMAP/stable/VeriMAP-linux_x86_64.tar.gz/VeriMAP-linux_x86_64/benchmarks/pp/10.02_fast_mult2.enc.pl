% Progs/0_src/11_SPEC/11.02_fast_mult2.transformed/fast_mult2.c.map.transform.pl
fast_mult22(A,B,C,D,E,F,G,H,I,J) :- K>=L+1, K=:=A, A>=0, L=:=0, M=1, A=:=2*N+1, 
          O>=P, O=:=M, M>=0, P=:=1, Q=:=R-S, R=:=A, A>=0, S=:=1, T=:=U+V, 
          U=:=C, C>=0, V=:=B, B>=0, Q=:=2*D, W=:=D, D>=0, X=:=Y*Z, Y=:=2, 
          Z=:=B, B>=0, fast_mult22(W,X,T,D,M,F,G,H,I,J).
fast_mult22(A,B,C,D,E,F,G,H,I,J) :- K>=L+1, K=:=A, A>=0, L=:=0, M=0, A=:=2*N, 
          O+1=<P, O=:=M, M>=0, P=:=1, A=:=2*D, Q=:=D, D>=0, R=:=S*T, S=:=2, 
          T=:=B, B>=0, fast_mult22(Q,R,C,D,M,F,G,H,I,J).
fast_mult22(A,B,C,D,E,A,B,C,D,E) :- F=<G, F=:=A, A>=0, G=:=0.
fast_mult21(A,B,C) :- D=:=0, fast_mult22(A,B,D,E,F,G,H,C,I,J).

% Progs/0_src/11_SPEC/11.02_fast_mult2/relprop
  % fast_mult2 -- first predicate fast_mult21
 
  % fast_mult2(P,Q,M) :- P=0, M=0.
  incorrect :- fast_mult21(P,Q,M), P=0, M=\=0.
  
  % fast_mult2(P,Q,M) :- P>=1, P1>=0, P=2*P1+1, M=M1+Q, Q1=2*Q, fast_mult2(P1,Q1,M1).
  incorrect :- fast_mult21(P,Q,M), P>=1, P1>=0, P=2*P1+1, M=\=M1+Q, Q1=2*Q, fast_mult21(P1,Q1,M1).
    
  % fast_mult2(P,Q,M) :- P>=2, P1>=0, P=2*P1, Q1=2*Q, fast_mult2(P1,Q1,M).
  incorrect :- fast_mult21(P,Q,M), P>=2, P1>=0, P=2*P1, M=\=M1, Q1=2*Q, fast_mult21(P1,Q1,M1).

