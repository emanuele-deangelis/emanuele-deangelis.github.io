% Progs/0_src/11_SPEC/11.05_fusc.transformed/fusc.c.map.transform.pl
fusc2(A,B,C,D,E,F,G,H,I,J,K,L) :- M>=N+1, M=:=D, D>=0, N=:=0, O=0, D=:=2*P, 
          Q=<R, Q=:=O, O>=0, R=:=0, S=:=T+U, T=:=B, B>=0, U=:=C, C>=0, D=:=2*F, 
          V=:=F, F>=0, fusc2(A,B,S,V,O,F,G,H,I,J,K,L).
fusc2(A,B,C,D,E,F,G,H,I,J,K,L) :- M>=N+1, M=:=D, D>=0, N=:=0, O=1, D=:=2*P+1, 
          Q>=R+1, Q=:=O, O>=0, R=:=0, S=:=T+U, T=:=B, B>=0, U=:=C, C>=0, 
          V=:=W-X, W=:=D, D>=0, X=:=1, V=:=2*F, Y=:=F, F>=0, 
          fusc2(A,S,C,Y,O,F,G,H,I,J,K,L).
fusc2(A,B,C,D,E,F,A,B,C,D,E,F) :- G=<H, G=:=D, D>=0, H=:=0.
fusc1(A,B) :- C=:=0, D=:=1, E=:=A, A>=0, fusc2(A,C,D,E,F,G,H,B,I,J,K,L).

% Progs/0_src/11_SPEC/11.05_fusc/relprop

    %fusc(N,F) :- N=:=0, F=:=0.
    incorrect :- fusc1(N,F), N=:=0, F=\=0.

    %fusc(N,F) :- N=:=1, F=:=1.
    incorrect :- fusc1(N,F), N=:=1, F=\=1.

    %fusc(N,F)  :- N>=2, N=:=K+K, K>=1, fusc(K,F1), F=:=F1.                    % even(N)  
    incorrect :- fusc1(N,F), N>=2, N=:=K+K, K>=1, fusc1(K,F1), F=\=F1.   
    
    %fusc(N,F2) :- N>=2, N=:=K+K+1, K>=1, fusc(K,F), K1=K+1, fusc(K1,F1), F2=:=F+F1.  %  odd(N) 
    incorrect :- fusc1(N,F2), N>=2, N=:=K+K+1, K>=1, fusc1(K,F), K1=K+1, fusc1(K1,F1), F2=\=F+F1.   

