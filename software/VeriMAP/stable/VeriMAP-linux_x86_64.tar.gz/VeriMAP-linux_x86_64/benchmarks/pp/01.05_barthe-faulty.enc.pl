% Progs/0_src/01_ITE/01.05_barthe-faulty.transformed/1.c.map.transform.pl
new13(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q+1=<R, Q=:=F, R=:=D, S=:=T+U, 
          T=:=V*W, V=:=5, W=:=F, U=:=E, X=:=Y+Z, Y=:=H, Z=:=S, A1=:=B1+C1, 
          B1=:=F, C1=:=1, new13(A,B,C,D,E,A1,S,X,I,J,K,L,M,N,O,P).
new13(A,B,C,D,E,F,G,H,A,B,C,D,E,F,G,H) :- I>=J, I=:=F, J=:=D.
new12(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q=:=0, R=:=0, S=:=0, 
          new13(A,B,C,D,E,Q,R,S,I,J,K,L,M,N,O,P).
new11(A,B,C) :- D=:=A, E=:=B, C=:=F, new12(A,B,G,D,E,H,I,J,K,L,M,N,O,P,Q,F).

% Progs/0_src/01_ITE/01.05_barthe-faulty.transformed/2.c.map.transform.pl
new23(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q+1=<R, Q=:=F, R=:=D, S=:=T+U, T=:=H, 
          U=:=G, V=:=W+X, W=:=G, X=:=5, Y=:=Z, Y=:=F, Z=:=10, A1=:=10, 
          B1=:=C1+D1, C1=:=F, D1=:=1, new23(A,B,C,D,E,B1,A1,S,I,J,K,L,M,N,O,P).
new23(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q+1=<R, Q=:=F, R=:=D, S=:=T+U, T=:=H, 
          U=:=G, V=:=W+X, W=:=G, X=:=5, Y=\=Z, Y=:=F, Z=:=10, A1=:=B1+C1, 
          B1=:=F, C1=:=1, new23(A,B,C,D,E,A1,V,S,I,J,K,L,M,N,O,P).
new23(A,B,C,D,E,F,G,H,A,B,C,D,E,F,G,H) :- I>=J, I=:=F, J=:=D.
new22(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q=:=0, R=:=E, S=:=0, 
          new23(A,B,C,D,E,Q,R,S,I,J,K,L,M,N,O,P).
new21(A,B,C) :- D=:=A, E=:=B, C=:=F, new22(A,B,G,D,E,H,I,J,K,L,M,N,O,P,Q,F).

% Progs/0_src/01_ITE/01.05_barthe-faulty/relprop
incorrect :- A=:=X, B=:=Y, C=\=Z, new11(A,B,C), new21(X,Y,Z).
