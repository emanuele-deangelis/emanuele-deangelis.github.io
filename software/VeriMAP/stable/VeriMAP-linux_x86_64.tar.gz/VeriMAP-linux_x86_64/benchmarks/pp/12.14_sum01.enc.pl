% Progs/NONINT/sum01.transformed/1.c.map.transform.pl
new17(A,B,C,D,E,A,B,C,D,E) :- F>=G+1, F=:=E, G=:=D.
new17(A,B,C,D,E,F,G,H,I,J) :- K=<L, K=:=E, L=:=D, M=:=N+O, N=:=E, O=:=1, 
          new17(A,B,C,D,M,F,G,H,I,J).
new15(A,B,C,D,E,A,B,C,D,E) :- F>=G+1, F=:=E, G=:=D.
new15(A,B,C,D,E,F,G,H,I,J) :- K=<L, K=:=E, L=:=D, M=:=N+O, N=:=E, O=:=1, 
          new15(A,B,C,D,M,F,G,H,I,J).
new14(A,B,C,D,E,F,G,H,I,J) :- K=:=0, new15(A,B,C,D,K,F,G,H,I,J).
new13(A,B,C,D,E,F,G,H,I,J) :- K=:=0, L>=M, L=:=D, M=:=1, N=:=1, 
          new17(A,B,C,D,N,F,G,H,I,J).
new13(A,B,C,D,E,F,G,H,I,J) :- K=:=0, L+1=<M, L=:=D, M=:=1, 
          new17(A,B,C,D,K,F,G,H,I,J).
new12(A,B,C,D,E,F,G,H,I,J,K,D,E,L,M,N) :- O=:=0, P=:=D, M=:=Q, R=:=S+T, S=:=M, 
          T=:=E, U=:=D, N=:=V, L=:=W-X, W=:=R, X=:=N, 
          new13(A,B,C,P,Y,Z,A1,B1,C1,Q), new14(Z,A1,B1,U,D1,I,J,K,E1,V).
new11(A,B,C) :- D=:=A, E=:=B, C=:=F, new12(A,B,G,D,E,H,I,J,K,L,M,N,O,F,P,Q).
specint :- new11(A,B,C).

verimap(pred_smtvars_types([specint,new11('Int','Int','Int'),new12('Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int'),new13('Int','Int','Int','Int','Int','Int','Int','Int','Int','Int'),new14('Int','Int','Int','Int','Int','Int','Int','Int','Int','Int'),new15('Int','Int','Int','Int','Int','Int','Int','Int','Int','Int'),new17('Int','Int','Int','Int','Int','Int','Int','Int','Int','Int')])).

% Progs/NONINT/sum01.transformed/2.c.map.transform.pl
new27(A,B,C,D,E,A,B,C,D,E) :- F>=G+1, F=:=E, G=:=D.
new27(A,B,C,D,E,F,G,H,I,J) :- K=<L, K=:=E, L=:=D, M=:=N+O, N=:=E, O=:=1, 
          new27(A,B,C,D,M,F,G,H,I,J).
new25(A,B,C,D,E,A,B,C,D,E) :- F>=G+1, F=:=E, G=:=D.
new25(A,B,C,D,E,F,G,H,I,J) :- K=<L, K=:=E, L=:=D, M=:=N+O, N=:=E, O=:=1, 
          new25(A,B,C,D,M,F,G,H,I,J).
new24(A,B,C,D,E,F,G,H,I,J) :- K=:=0, new25(A,B,C,D,K,F,G,H,I,J).
new23(A,B,C,D,E,F,G,H,I,J) :- K=:=0, L>=M, L=:=D, M=:=1, N=:=1, 
          new27(A,B,C,D,N,F,G,H,I,J).
new23(A,B,C,D,E,F,G,H,I,J) :- K=:=0, L+1=<M, L=:=D, M=:=1, 
          new27(A,B,C,D,K,F,G,H,I,J).
new22(A,B,C,D,E,F,G,H,I,J,K,D,E,L,M,N) :- O=:=0, P=:=D, M=:=Q, R=:=S+T, S=:=M, 
          T=:=E, U=:=D, N=:=V, L=:=W-X, W=:=R, X=:=N, 
          new23(A,B,C,P,Y,Z,A1,B1,C1,Q), new24(Z,A1,B1,U,D1,I,J,K,E1,V).
new21(A,B,C) :- D=:=A, E=:=B, C=:=F, new22(A,B,G,D,E,H,I,J,K,L,M,N,O,F,P,Q).
specint :- new21(A,B,C).

verimap(pred_smtvars_types([incorrect,new21('Int','Int','Int'),new22('Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int'),new23('Int','Int','Int','Int','Int','Int','Int','Int','Int','Int'),new24('Int','Int','Int','Int','Int','Int','Int','Int','Int','Int'),new25('Int','Int','Int','Int','Int','Int','Int','Int','Int','Int'),new27('Int','Int','Int','Int','Int','Int','Int','Int','Int','Int')])).

% Progs/NONINT/sum01/relprop
incorrect :- B=:=Y,  C=\=Z, new11(A,B,C), new21(X,Y,Z).
