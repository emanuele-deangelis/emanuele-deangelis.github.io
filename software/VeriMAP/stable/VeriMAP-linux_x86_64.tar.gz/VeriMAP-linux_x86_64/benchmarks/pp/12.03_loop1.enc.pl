% Progs/NONINT/loop1.transformed/1.c.map.transform.pl
new17(A,B,C,D,E,F,A,B,C,D,E,F) :- G>=H+1, G=:=E, H=:=D.
new17(A,B,C,D,E,F,G,H,I,J,K,L) :- M=<N, M=:=E, N=:=D, O=:=P+Q, P=:=F, Q=:=2, 
          R=:=S+T, S=:=E, T=:=1, new17(A,B,C,D,R,O,G,H,I,J,K,L).
new15(A,B,C,D,E,F,A,B,C,D,E,F) :- G>=H, G=:=E, H=:=D.
new15(A,B,C,D,E,F,G,H,I,J,K,L) :- M+1=<N, M=:=E, N=:=D, O=:=P+Q, P=:=F, Q=:=2, 
          R=:=S+T, S=:=E, T=:=1, new15(A,B,C,D,R,O,G,H,I,J,K,L).
new14(A,B,C,D,E,F,G,H,I,J,K,L) :- M=:=0, N=:=0, new15(A,B,C,D,M,N,G,H,I,J,K,L).
new13(A,B,C,D,E,F,G,H,I,J,K,L) :- M=:=1, N=:=0, new17(A,B,C,D,M,N,G,H,I,J,K,L).
new12(A,B,C,D,E,F,G,H,I,J,K,D,E,L,M,N) :- O=:=0, P=:=D, M=:=Q, R=:=S+T, S=:=M, 
          T=:=E, U=:=D, N=:=V, L=:=W-X, W=:=R, X=:=N, 
          new13(A,B,C,P,Y,Z,A1,B1,C1,D1,E1,Q), 
          new14(A1,B1,C1,U,F1,G1,I,J,K,H1,I1,V).
new11(A,B,C) :- D=:=A, E=:=B, C=:=F, new12(A,B,G,D,E,H,I,J,K,L,M,N,O,F,P,Q).
specint :- new11(A,B,C).

verimap(pred_smtvars_types([specint,new11('Int','Int','Int'),new12('Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int'),new13('Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int'),new14('Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int'),new15('Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int'),new17('Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int')])).

% Progs/NONINT/loop1.transformed/2.c.map.transform.pl
new27(A,B,C,D,E,F,A,B,C,D,E,F) :- G>=H+1, G=:=E, H=:=D.
new27(A,B,C,D,E,F,G,H,I,J,K,L) :- M=<N, M=:=E, N=:=D, O=:=P+Q, P=:=F, Q=:=2, 
          R=:=S+T, S=:=E, T=:=1, new27(A,B,C,D,R,O,G,H,I,J,K,L).
new25(A,B,C,D,E,F,A,B,C,D,E,F) :- G>=H, G=:=E, H=:=D.
new25(A,B,C,D,E,F,G,H,I,J,K,L) :- M+1=<N, M=:=E, N=:=D, O=:=P+Q, P=:=F, Q=:=2, 
          R=:=S+T, S=:=E, T=:=1, new25(A,B,C,D,R,O,G,H,I,J,K,L).
new24(A,B,C,D,E,F,G,H,I,J,K,L) :- M=:=0, N=:=0, new25(A,B,C,D,M,N,G,H,I,J,K,L).
new23(A,B,C,D,E,F,G,H,I,J,K,L) :- M=:=1, N=:=0, new27(A,B,C,D,M,N,G,H,I,J,K,L).
new22(A,B,C,D,E,F,G,H,I,J,K,D,E,L,M,N) :- O=:=0, P=:=D, M=:=Q, R=:=S+T, S=:=M, 
          T=:=E, U=:=D, N=:=V, L=:=W-X, W=:=R, X=:=N, 
          new23(A,B,C,P,Y,Z,A1,B1,C1,D1,E1,Q), 
          new24(A1,B1,C1,U,F1,G1,I,J,K,H1,I1,V).
new21(A,B,C) :- D=:=A, E=:=B, C=:=F, new22(A,B,G,D,E,H,I,J,K,L,M,N,O,F,P,Q).
specint :- new21(A,B,C).

verimap(pred_smtvars_types([incorrect,new21('Int','Int','Int'),new22('Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int'),new23('Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int'),new24('Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int'),new25('Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int'),new27('Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int')])).

% Progs/NONINT/loop1/relprop
incorrect :- B=:=Y,  C=\=Z, new11(A,B,C), new21(X,Y,Z).
