% Progs/0_src/09_COMP/09.04_array_sum_k.transformed/p1.c.map.transform.pl
p13(A,B,C,D,E,F,G,H,I,J) :- C=:=K-D-L, M=:=rat(1,1)+N, E=:=N, A-N>=rat(1,1), 
          read((B,A),N,L), val(i,M), val(s1,K), val(n,A), val(a,B), val(k,C), 
          val(s1,D), val(i,E), val(n,F), val(a,G), val(k,H), val(s1,I), 
          val(i,J), p13(A,B,C,K,M,F,G,H,I,J).
p13(A,B,C,D,E,A,B,C,D,E) :- E-A>=rat(0,1), val(i,E), val(s1,D), val(k,C), 
          val(a,B), val(n,A).
p12(A,B,C,D,E,F,G,H,I,J) :- K=:=rat(0,1), val(s1,K), val(n,A), val(a,B), 
          val(k,C), val(s1,D), val(i,E), val(n,F), val(a,G), val(k,H), 
          val(s1,I), val(i,J), p13(A,B,C,K,E,F,G,H,I,J).
p11(A,B,C,D) :- E=:=rat(0,1), val(i,F), val(k,G), val(a,H), val(n,I), val(i,E), 
          val(s1,J), p12(A,B,C,J,E,I,H,G,D,F).

verimap(pred_smtvars_types([specint,p11('Int','(Array Int Int)','Int','Int'),p12('Int','(Array Int Int)','Int','Int','Int','Int','(Array Int Int)','Int','Int','Int'),p13('Int','(Array Int Int)','Int','Int','Int','Int','(Array Int Int)','Int','Int','Int')])).

% Progs/0_src/09_COMP/09.04_array_sum_k.transformed/p2.c.map.transform.pl
p25(A,B,C,D,E,F,G,H,I,J) :- C=:=K-L, M=:=rat(1,1)+N, E=:=N, O=:=N, 
          A-N>=rat(1,1), read((B,A),N,L), write((B,A),O,K,(P,A)), val(i,M), 
          val(a,P), val(n,A), val(a,B), val(k,C), val(s2,D), val(i,E), 
          val(n,F), val(a,G), val(k,H), val(s2,I), val(i,J), 
          p25(A,P,C,D,M,F,G,H,I,J).
p25(A,B,C,D,E,A,B,C,D,E) :- E-A>=rat(0,1), val(i,E), val(s2,D), val(k,C), 
          val(a,B), val(n,A).
p24(A,B,C,D,E,F,G,H,I,J) :- K=:=D+L, M=:=rat(1,1)+N, E=:=N, A-N>=rat(1,1), 
          read((B,A),N,L), val(i,M), val(s2,K), val(n,A), val(a,B), val(k,C), 
          val(s2,D), val(i,E), val(n,F), val(a,G), val(k,H), val(s2,I), 
          val(i,J), p24(A,B,C,K,M,F,G,H,I,J).
p24(A,B,C,D,E,A,B,C,D,E) :- E-A>=rat(0,1), val(i,E), val(s2,D), val(k,C), 
          val(a,B), val(n,A).
p23(A,B,C,D,E,F,G,H,I,J) :- K=:=rat(0,1), val(s2,K), val(n,A), val(a,B), 
          val(k,C), val(s2,D), val(i,E), val(n,F), val(a,G), val(k,H), 
          val(s2,I), val(i,J), p24(A,B,C,K,E,F,G,H,I,J).
p22(A,B,C,D,E,F,G,H,I,J) :- val(n,A), val(a,B), val(k,C), val(s2,D), val(i,E), 
          val(n,F), val(a,G), val(k,H), val(s2,I), val(i,J), 
          p25(A,B,C,D,E,F,G,H,I,J).
p21(A,B,C,D) :- E=:=rat(0,1), F=:=rat(0,1), val(i,G), val(k,H), val(a,I), 
          val(n,J), val(i,E), val(s2,K), val(k,L), val(a,M), val(n,N), 
          val(s2,O), val(i,F), val(i,P), p22(A,B,C,O,F,N,M,L,K,P), 
          p23(N,M,L,K,E,J,I,H,D,G).

verimap(pred_smtvars_types([specint,p21('Int','(Array Int Int)','Int','Int'),p22('Int','(Array Int Int)','Int','Int','Int','Int','(Array Int Int)','Int','Int','Int'),p23('Int','(Array Int Int)','Int','Int','Int','Int','(Array Int Int)','Int','Int','Int'),p24('Int','(Array Int Int)','Int','Int','Int','Int','(Array Int Int)','Int','Int','Int'),p25('Int','(Array Int Int)','Int','Int','Int','Int','(Array Int Int)','Int','Int','Int')])).

% Progs/0_src/09_COMP/09.04_array_sum_k/relprop
%{N>=1, K1<K2} p11~p21 {Sum1<Sum2}
incorrect :- N>=1, K1>=0, K1+1=<K2, Sum1>=Sum2, p11(N,A,K1,Sum1), p21(N,A,K2,Sum2), val(n,N), val(a,A), val(s1,Sum1), val(s2,Sum2). 

verimap(pred_smtvars_types([incorrect])).

verimap(data_types([array-int,bool,uint,long,int])).
