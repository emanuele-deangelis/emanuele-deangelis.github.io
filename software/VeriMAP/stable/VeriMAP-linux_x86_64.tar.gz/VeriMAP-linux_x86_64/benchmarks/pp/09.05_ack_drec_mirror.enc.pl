ackermann1(M1,N1,A1) :- ack1(M1,N1,A1).
ack1(M1,N1,A1) :- M1=<0, A1=N1+1.
ack1(M1,N1,A1) :- M1>=1, N1=0, X1=M1-1, Y1=1, ack1(X1,Y1,A1).
ack1(M1,N1,A1) :- M1>=1, N1>=1, X1=M1-1, Y1=N1-1, ack1(M1,Y1,Z1), ack1(X1,Z1,A1).

ackermann2(M2,N2,A2) :- ack2(M2,N2,A2).
ack2(M2,N2,A2) :- M2=0, A2=N2+1.
ack2(M2,N2,A2) :- M2>=1, N2=0, X2=M2-1, Y2=1, ack2(X2,Y2,A2).
ack2(M2,N2,A2) :- M2>=1, N2>=1, X2=M2-1, Y2=N2-1, ack2(M2,Y2,Z2), ack2(X2,Z2,A2).

incorrect :- M1=M2, M1>=0, N1=N2, N1>=0, A1=\=A2, ackermann1(M1,N1,A1), ackermann2(M2,N2,A2).
