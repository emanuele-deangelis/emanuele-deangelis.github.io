% Progs/0_src/01_ITE/01.18_nested-while-faulty.transformed/1.c.map.transform.pl
new15(A,B,C,D,E,F,G,H,I,J,K,L) :- new13(A,B,C,D,E,F,G,H,I,J,K,L).
new14(A,B,C,D,E,F,G,H,I,J,K,L) :- M+1=<N, M=:=D, N=:=F, O=:=P+Q, P=:=D, Q=:=2, 
          R=:=S-T, S=:=O, T=:=1, U=:=V+W, V=:=E, W=:=1, 
          new14(A,B,C,R,U,F,G,H,I,J,K,L).
new14(A,B,C,D,E,F,G,H,I,J,K,L) :- M>=N, M=:=D, N=:=F, 
          new15(A,B,C,D,E,F,G,H,I,J,K,L).
new13(A,B,C,D,E,F,G,H,I,J,K,L) :- M+1=<N, M=:=F, N=:=D, O=:=P+Q, P=:=F, Q=:=1, 
          R=:=S-T, S=:=E, T=:=2, U=:=V+W, V=:=R, W=:=1, 
          new14(A,B,C,D,U,O,G,H,I,J,K,L).
new13(A,B,C,D,E,F,A,B,C,D,E,F) :- G>=H, G=:=F, H=:=D.
new12(A,B,C,D,E,F,G,H,I,J,K,L) :- M=:=0, new13(A,B,C,D,E,M,G,H,I,J,K,L).
new11(A,B,C) :- D=:=A, E=:=B, C=:=F, new12(A,B,G,D,E,H,I,J,K,L,F,M).

% Progs/0_src/01_ITE/01.18_nested-while-faulty.transformed/2.c.map.transform.pl
new25(A,B,C,D,E,F,G,H,I,J,K,L) :- new23(A,B,C,D,E,F,G,H,I,J,K,L).
new24(A,B,C,D,E,F,G,H,I,J,K,L) :- M+1=<N, M=:=D, N=:=F, O=:=P+Q, P=:=D, Q=:=1, 
          R=:=S+T, S=:=E, T=:=2, new24(A,B,C,O,R,F,G,H,I,J,K,L).
new24(A,B,C,D,E,F,G,H,I,J,K,L) :- M>=N, M=:=D, N=:=F, 
          new25(A,B,C,D,E,F,G,H,I,J,K,L).
new23(A,B,C,D,E,F,G,H,I,J,K,L) :- M+1=<N, M=:=F, N=:=D, O=:=P+Q, P=:=F, Q=:=1, 
          R=:=S-T, S=:=E, T=:=2, new24(A,B,C,D,R,O,G,H,I,J,K,L).
new23(A,B,C,D,E,F,A,B,C,D,E,F) :- G>=H, G=:=F, H=:=D.
new22(A,B,C,D,E,F,G,H,I,J,K,L) :- M=:=0, new23(A,B,C,D,E,M,G,H,I,J,K,L).
new21(A,B,C) :- D=:=A, E=:=B, C=:=F, new22(A,B,G,D,E,H,I,J,K,L,F,M).

% Progs/0_src/01_ITE/01.18_nested-while-faulty/relprop
incorrect :- A=:=X, B=:=Y, C=\=Z, new11(A,B,C), new21(X,Y,Z).
