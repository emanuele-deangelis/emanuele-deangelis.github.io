% Progs/0_src/08_FUN/08.01_add-horn.transformed/1.c.map.transform.pl
new12(A,B,C,D,E,F,A,B,C,D,E,G) :- H=:=0, I=:=J, I=:=D, J=:=0, G=:=E.
new12(A,B,C,D,E,F,G,H,I,D,E,J) :- K=:=0, L=\=M, L=:=D, M=:=0, N=:=O-P, O=:=D, 
          P=:=1, Q=:=R+S, R=:=E, S=:=1, J=:=T, new12(A,B,C,N,Q,U,G,H,I,V,W,T).
new11(A,B,C) :- D=:=A, E=:=B, C=:=F, new12(A,B,G,D,E,H,I,J,K,L,M,F).

% Progs/0_src/08_FUN/08.01_add-horn.transformed/2.c.map.transform.pl
new22(A,B,C,D,E,F,A,B,C,D,E,G) :- H=:=0, I=:=J, I=:=D, J=:=0, G=:=E.
new22(A,B,C,D,E,F,G,H,I,D,E,J) :- K=:=0, L=\=M, L=:=D, M=:=0, N=:=O-P, O=:=D, 
          P=:=1, Q=:=R+S, R=:=E, S=:=1, J=:=T, new22(A,B,C,N,Q,U,G,H,I,V,W,T).
new21(A,B,C) :- D=:=A, E=:=B, C=:=F, new22(A,B,G,D,E,H,I,J,K,L,M,F).

% Progs/0_src/08_FUN/08.01_add-horn/relprop
incorrect :- X1=<0, X2=<0, Y2=:=Y1, Z2>=Z1+1, new11(X1,Y1,Z1), new21(X2,Y2,Z2).
