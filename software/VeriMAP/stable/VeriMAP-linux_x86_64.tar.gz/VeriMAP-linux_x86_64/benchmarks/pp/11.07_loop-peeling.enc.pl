% Progs/compopt/loop-peeling.transformed/1.c.map.transform.pl
new13(A,B,C,A,B,C) :- D>=E, D=:=A, E=:=B.
new13(A,B,C,D,E,F) :- G+1=<H, G=:=A, H=:=B, I=:=J+K, J=:=C, K=:=A, L=:=M+N, 
          M=:=A, N=:=1, new13(L,B,I,D,E,F).
new12(A,B,C,D,E,F) :- new13(A,B,C,D,E,F).
new11(A,B,C,D,E) :- new12(A,B,C,D,F,E).

verimap(pred_smtvars_types([specint,new11('Int','Int','Int','Int','Int'),new12('Int','Int','Int','Int','Int','Int'),new13('Int','Int','Int','Int','Int','Int')])).

% Progs/compopt/loop-peeling.transformed/2.c.map.transform.pl
new23(A,B,C,A,B,C) :- D>=E, D=:=A, E=:=B.
new23(A,B,C,D,E,F) :- G+1=<H, G=:=A, H=:=B, I=:=J+K, J=:=C, K=:=A, L=:=M+N, 
          M=:=A, N=:=1, new23(L,B,I,D,E,F).
new22(A,B,C,A,B,C) :- D>=E, D=:=A, E=:=B.
new22(A,B,C,D,E,F) :- G+1=<H, G=:=A, H=:=B, I=:=J+K, J=:=C, K=:=A, L=:=M+N, 
          M=:=A, N=:=1, new23(L,B,I,D,E,F).
new21(A,B,C,D,E) :- new22(A,B,C,D,F,E).

verimap(pred_smtvars_types([incorrect,new21('Int','Int','Int','Int','Int'),new22('Int','Int','Int','Int','Int','Int'),new23('Int','Int','Int','Int','Int','Int')])).

% Progs/compopt/loop-peeling/relprop
incorrect :- E=\=Z, new11(A,B,C,D,E), new21(A,B,C,V,Z).
