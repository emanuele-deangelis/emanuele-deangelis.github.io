% Progs/0_src/07_INJ/07.07_product.transformed/1.c.map.transform.pl
new13(A,B,C,D,E,F,G,H,I) :- J>=K+1, J=:=E, K=:=0, L=:=M+N, M=:=F, N=:=D, 
          O=:=P-Q, P=:=E, Q=:=1, new13(A,B,C,D,O,L,G,H,I).
new13(A,B,C,D,E,F,D,E,F) :- G=<H, G=:=E, H=:=0.
new12(A,B,C,D,E,F,G,H,I) :- J=:=0, new13(A,B,C,D,E,J,G,H,I).
new11(A,B,C) :- D=:=A, E=:=B, C=:=F, new12(A,B,G,D,E,H,I,J,F).

% Progs/0_src/07_INJ/07.07_product.transformed/2.c.map.transform.pl
new23(A,B,C,D,E,F,G,H,I) :- J>=K+1, J=:=E, K=:=0, L=:=M+N, M=:=F, N=:=D, 
          O=:=P-Q, P=:=E, Q=:=1, new23(A,B,C,D,O,L,G,H,I).
new23(A,B,C,D,E,F,D,E,F) :- G=<H, G=:=E, H=:=0.
new22(A,B,C,D,E,F,G,H,I) :- J=:=0, new23(A,B,C,D,E,J,G,H,I).
new21(A,B,C) :- D=:=A, E=:=B, C=:=F, new22(A,B,G,D,E,H,I,J,F).

% Progs/0_src/07_INJ/07.07_product/relprop
incorrect :- Y1>=1, Y1=:=Y2, X2>=X1+1, Z1=:=Z2, new11(X1,Y1,Z1), new21(X2,Y2,Z2).
