% Progs/compopt/code-sinking.transformed/1.c.map.transform.pl
new12(A,B,C,D,E,F,A,G,C,D,H,F) :- I>=J, I=:=D, J=:=A, H=:=K, L=:=M-N, M=:=A, 
          N=:=1, O=:=C, P=:=Q-R, Q=:=A, R=:=1, S=:=H, T=:=F, read((B,A),L,K), 
          write((B,A),P,O,(U,A)), write((U,A),T,S,(G,A)).
new12(A,B,C,D,E,F,G,H,I,J,K,L) :- M=:=rat(1,1)+D, N=:=D, O=:=P, Q=:=D, 
          P-C>=rat(1,1), A-D>=rat(1,1), read((B,A),Q,P), 
          new12(A,B,O,M,E,N,G,H,I,J,K,L).
new12(A,B,C,D,E,F,G,H,I,J,K,L) :- M+1=<N, M=:=D, N=:=A, O>=P, O=:=C, P=:=Q, 
          R=:=D, S=:=T+U, T=:=D, U=:=1, read((B,A),R,Q), 
          new12(A,B,C,S,E,F,G,H,I,J,K,L).
new11(A,B,C) :- A=:=A, D=:=0, E=:=0, F=:=G, H=:=0, read((B,A),H,G), 
          new12(A,B,F,D,I,E,J,K,C,L,M,N).
specint :- new11(A,B,C).

verimap(pred_smtvars_types([specint,new11('Int','(Array Int Int)','Int'),new12('Int','(Array Int Int)','Int','Int','Int','Int','Int','(Array Int Int)','Int','Int','Int','Int')])).

% Progs/compopt/code-sinking.transformed/2.c.map.transform.pl
new22(A,B,C,D,E,F,A,B,C,D,E,F) :- G>=H, G=:=D, H=:=A.
new22(A,B,C,D,E,F,G,H,I,J,K,L) :- M=:=rat(1,1), N=:=rat(0,1), O=:=rat(0,1), 
          P=:=Q, D=:=rat(0,1), A>=rat(1,1), read((B,A),O,Q), 
          new22(A,B,P,M,E,N,G,H,I,J,K,L).
new22(A,B,C,D,E,F,G,H,I,J,K,L) :- M=:=rat(1,1)+D, N=:=D, O=:=P, Q=:=D, 
          P-C>=rat(1,1), A-D>=rat(1,1), D=\=rat(0,1), read((B,A),Q,P), 
          new22(A,B,O,M,E,N,G,H,I,J,K,L).
new22(A,B,C,D,E,F,G,H,I,J,K,L) :- M+1=<N, M=:=D, N=:=A, O=\=P, O=:=D, P=:=0, 
          Q>=R, Q=:=C, R=:=S, T=:=D, U=\=V, U=:=D, V=:=A, W=:=X+Y, X=:=D, 
          Y=:=1, read((B,A),T,S), new22(A,B,C,W,E,F,G,H,I,J,K,L).
new21(A,B,C) :- A=:=A, D=:=0, new22(A,B,E,D,F,G,H,I,C,J,K,L).
specint :- new21(A,B,C).

verimap(pred_smtvars_types([incorrect,new21('Int','(Array Int Int)','Int'),new22('Int','(Array Int Int)','Int','Int','Int','Int','Int','(Array Int Int)','Int','Int','Int','Int')])).

% Progs/compopt/code-sinking/relprop
incorrect :- N>=1, new11(N,A,Max1), new21(N,A,Max2), Max1=\=Max2. 

verimap(pred_smtvars_types([incorrect])).

verimap(data_types([array-int,bool,uint,long,int])).
