% Progs/0_src/04_I-R/04.02_sumprod.transformed/1.c.map.transform.pl
new12(A,B,C,D,E,C,F,E) :- G=:=0, H=<I, H=:=C, I=:=0, F=:=0.
new12(A,B,C,D,E,C,F,G) :- H=:=0, I>=J+1, I=:=C, J=:=0, K=:=L-M, L=:=C, M=:=1, 
          G=:=N, F=:=O+P, O=:=G, P=:=C, new12(A,B,K,Q,R,S,N,T).
new11(A,B) :- C=:=A, B=:=D, new12(A,E,C,F,G,H,D,I).

% Progs/0_src/04_I-R/04.02_sumprod.transformed/2.c.map.transform.pl
new23(A,B,C,D,E,F,G,H,I) :- J>=K+1, J=:=D, K=:=0, L=:=M+N, M=:=F, N=:=E, 
          O=:=P-Q, P=:=D, Q=:=1, new23(A,B,C,O,E,L,G,H,I).
new23(A,B,C,D,E,F,D,E,F) :- G=<H, G=:=D, H=:=0.
new22(A,B,C,D,E,F,G,H,I) :- J=:=0, new23(A,B,C,D,E,J,G,H,I).
new21(A,B,C) :- D=:=A, E=:=B, C=:=F, new22(A,B,G,D,E,H,I,J,F).

% Progs/0_src/04_I-R/04.02_sumprod/relprop
incorrect :- A>=0, A=:=X, Y>=X, C>=Z+1, new11(A,C), new21(X,Y,Z).
