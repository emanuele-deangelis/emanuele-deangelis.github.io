% Progs/NONINT/strengthred.transformed/1.c.map.transform.pl
new17(A,B,C,D,E,F,A,B,C,D,E,F) :- G>=H, G=:=D, H=:=E.
new17(A,B,C,D,E,F,G,H,I,J,K,L) :- M+1=<N, M=:=D, N=:=E, O=:=P*Q, P=:=D, Q=:=2, 
          R=:=S+T, S=:=D, T=:=1, new17(A,B,C,R,E,O,G,H,I,J,K,L).
new15(A,B,C,D,E,F,G,A,B,C,D,E,F,G) :- H>=I, H=:=D, I=:=E.
new15(A,B,C,D,E,F,G,H,I,J,K,L,M,N) :- O+1=<P, O=:=D, P=:=E, Q=:=G, R=:=S+T, 
          S=:=G, T=:=2, U=:=V+W, V=:=D, W=:=1, 
          new15(A,B,C,U,E,Q,R,H,I,J,K,L,M,N).
new14(A,B,C,D,E,F,G,H,I,J,K,L,M,N) :- O=:=0, P=:=Q*R, Q=:=D, R=:=2, 
          new15(A,B,C,D,E,O,P,H,I,J,K,L,M,N).
new13(A,B,C,D,E,F,G,H,I,J,K,L) :- M=:=0, new17(A,B,C,D,E,M,G,H,I,J,K,L).
new12(A,B,C,D,E,F,G,H,I,J,K,D,E,L,M,N) :- O=:=0, P=:=D, Q=:=E, M=:=R, S=:=T+U, 
          T=:=M, U=:=E, V=:=D, W=:=E, N=:=X, L=:=Y-Z, Y=:=S, Z=:=N, 
          new13(A,B,C,P,Q,A1,B1,C1,D1,E1,F1,R), 
          new14(B1,C1,D1,V,W,G1,H1,I,J,K,I1,J1,X,K1).
new11(A,B,C) :- D=:=A, E=:=B, C=:=F, new12(A,B,G,D,E,H,I,J,K,L,M,N,O,F,P,Q).
specint :- new11(A,B,C).

verimap(pred_smtvars_types([specint,new11('Int','Int','Int'),new12('Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int'),new13('Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int'),new14('Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int'),new15('Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int'),new17('Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int')])).

% Progs/NONINT/strengthred.transformed/2.c.map.transform.pl
new27(A,B,C,D,E,F,A,B,C,D,E,F) :- G>=H, G=:=D, H=:=E.
new27(A,B,C,D,E,F,G,H,I,J,K,L) :- M+1=<N, M=:=D, N=:=E, O=:=P*Q, P=:=D, Q=:=2, 
          R=:=S+T, S=:=D, T=:=1, new27(A,B,C,R,E,O,G,H,I,J,K,L).
new25(A,B,C,D,E,F,G,A,B,C,D,E,F,G) :- H>=I, H=:=D, I=:=E.
new25(A,B,C,D,E,F,G,H,I,J,K,L,M,N) :- O+1=<P, O=:=D, P=:=E, Q=:=G, R=:=S+T, 
          S=:=G, T=:=2, U=:=V+W, V=:=D, W=:=1, 
          new25(A,B,C,U,E,Q,R,H,I,J,K,L,M,N).
new24(A,B,C,D,E,F,G,H,I,J,K,L,M,N) :- O=:=0, P=:=Q*R, Q=:=D, R=:=2, 
          new25(A,B,C,D,E,O,P,H,I,J,K,L,M,N).
new23(A,B,C,D,E,F,G,H,I,J,K,L) :- M=:=0, new27(A,B,C,D,E,M,G,H,I,J,K,L).
new22(A,B,C,D,E,F,G,H,I,J,K,D,E,L,M,N) :- O=:=0, P=:=D, Q=:=E, M=:=R, S=:=T+U, 
          T=:=M, U=:=E, V=:=D, W=:=E, N=:=X, L=:=Y-Z, Y=:=S, Z=:=N, 
          new23(A,B,C,P,Q,A1,B1,C1,D1,E1,F1,R), 
          new24(B1,C1,D1,V,W,G1,H1,I,J,K,I1,J1,X,K1).
new21(A,B,C) :- D=:=A, E=:=B, C=:=F, new22(A,B,G,D,E,H,I,J,K,L,M,N,O,F,P,Q).
specint :- new21(A,B,C).

verimap(pred_smtvars_types([incorrect,new21('Int','Int','Int'),new22('Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int'),new23('Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int'),new24('Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int'),new25('Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int'),new27('Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int')])).

% Progs/NONINT/strengthred/relprop
incorrect :- B=:=Y,  C=\=Z, new11(A,B,C), new21(X,Y,Z).
