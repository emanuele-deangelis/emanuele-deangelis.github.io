% Progs/0_src/11_SPEC/11.11_sumfirst.transformed/sumfirst.c.map.transform.pl
sumfirst2(A,B,C,D,E,F) :- G=<H, G=:=C, C>=0, H=:=A, A>=0, I=:=J+K, J=:=B, B>=0, 
          K=:=C, C>=0, L=:=M+N, M=:=C, C>=0, N=:=1, sumfirst2(A,I,L,D,E,F).
sumfirst2(A,B,C,A,B,C) :- D>=E+1, D=:=C, C>=0, E=:=A, A>=0.
sumfirst1(A,B) :- C=:=0, D=:=0, sumfirst2(A,C,D,E,B,F).

% Progs/0_src/11_SPEC/11.11_sumfirst/relprop
   
   % sumfirst(N,S) :- N=:=0, S=:=0.
   incorrect :- sumfirst1(N,S), N=:=0, S=\=0.

   % sumfirst(N,S) :- N>=1, N1=:=N-1, S=:=N+S1, sumfirst(N1,S1).
   incorrect :- sumfirst1(N,S), N>=1, N1=:=N-1, sumfirst1(N1,S1), S=\=N+S1.

