% Progs/compopt/strength-reduction.transformed/1.c.map.transform.pl
new13(A,B,C,A,B,C) :- D>=E, D=:=A, E=:=B.
new13(A,B,C,D,E,F) :- G+1=<H, G=:=A, H=:=B, I=:=J*K, J=:=A, K=:=2, L=:=M+N, 
          M=:=A, N=:=1, new13(L,B,I,D,E,F).
new12(A,B,C,D,E,F) :- new13(A,B,C,D,E,F).
new11(A,B,C,D) :- new12(A,B,C,E,F,D).
specint :- new11(A,B,C,D).

verimap(pred_smtvars_types([specint,new11('Int','Int','Int','Int'),new12('Int','Int','Int','Int','Int','Int'),new13('Int','Int','Int','Int','Int','Int')])).

% Progs/compopt/strength-reduction.transformed/2.c.map.transform.pl
new23(A,B,C,D,A,B,C,D) :- E>=F, E=:=A, F=:=B.
new23(A,B,C,D,E,F,G,H) :- I+1=<J, I=:=A, J=:=B, K=:=D, L=:=M+N, M=:=D, N=:=2, 
          O=:=P+Q, P=:=A, Q=:=1, new23(O,B,K,L,E,F,G,H).
new22(A,B,C,D,E,F,G,H) :- I=:=J*K, J=:=A, K=:=2, new23(A,B,C,I,E,F,G,H).
new21(A,B,C,D) :- new22(A,B,C,E,F,G,D,H).
specint :- new21(A,B,C,D).

verimap(pred_smtvars_types([incorrect,new21('Int','Int','Int','Int'),new22('Int','Int','Int','Int','Int','Int','Int','Int'),new23('Int','Int','Int','Int','Int','Int','Int','Int')])).

% Progs/compopt/strength-reduction/relprop
incorrect :- X1=\=X2, new11(A,B,C,X1), new21(A,B,C,X2).
