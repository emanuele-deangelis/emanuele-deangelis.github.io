% Progs/0_src/11_SPEC/11.13_padovan.transformed/padovan.c.map.transform.pl
padovan2(A,B,C,D,E,F,G,H,I,J) :- K>=L+1, K=:=A, L=:=1, M=:=B, N=:=O+P, O=:=C, 
          P=:=E, Q=:=C, R=:=M, S=:=T-U, T=:=A, U=:=1, 
          padovan2(S,N,R,M,Q,F,G,H,I,J).
padovan2(A,B,C,D,E,A,B,C,D,E) :- F=<G, F=:=A, G=:=1.
padovan1(A,B) :- C=:=1, D=:=C, E=:=0, F=:= -1, G>=H, G=:=A, H=:=1, I=:=0, 
          padovan2(A,I,D,E,F,J,B,K,L,M).
padovan1(A,B) :- C=:=1, D=:=C, E=:=0, F=:= -1, G+1=<H, G=:=A, H=:=1, 
          padovan2(A,C,D,E,F,I,B,J,K,L).

% Progs/0_src/11_SPEC/11.13_padovan/relprop
% padovan(N,P) :- N=:=0, P=:=1.
incorrect :- padovan1(N,P), N=:=0, P=\=1.

% padovan(N,P) :- N=:=1, P=:=0.
incorrect :- padovan1(N,P), N=:=1, P=\=0.

% padovan(N,P) :- N=:=2, P=:=0.
incorrect :- padovan1(N,P), N=:=2, P=\=0.

% padovan(N,P) :- N>=3, N2=:=N-2, N3=:=N-3, P=:=P2+P3, padovan(N2,P2), padovan(N3,P3).
incorrect :- padovan1(N,P), N>=3, N2=:=N-2, N3=:=N-3, P=\=P2+P3, padovan1(N2,P2), padovan1(N3,P3).

