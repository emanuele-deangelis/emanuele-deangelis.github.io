% Progs/0_src/09_COMP/09.10_two_array_sum_diffsize.transformed/p1.c.map.transform.pl
p13(A,B,C,D,E,F,G,H,I,J,K,L,M,N) :- O=:=E+P+Q, R=:=rat(1,1)+S, F=:=S, T=:=S, 
          A-S>=rat(1,1), B-S>=rat(1,1), G-S>=rat(1,1), read((C,A),S,Q), 
          read((D,B),T,P), val(i,R), val(s1,O), val(size_a,A), val(size_b,B), 
          val(a,C), val(b,D), val(s1,E), val(i,F), val(n,G), val(size_a,H), 
          val(size_b,I), val(a,J), val(b,K), val(s1,L), val(i,M), val(n,N), 
          p13(A,B,C,D,O,R,G,H,I,J,K,L,M,N).
p13(A,B,C,D,E,F,G,H,I,J,K,L,M,N) :- O=:=E+P, Q=:=rat(1,1)+R, F=:=R, 
          B-R=<rat(0,1), A-R>=rat(1,1), G-R>=rat(1,1), read((C,A),R,P), 
          val(i,Q), val(s1,O), val(size_a,A), val(size_b,B), val(a,C), 
          val(b,D), val(s1,E), val(i,F), val(n,G), val(size_a,H), 
          val(size_b,I), val(a,J), val(b,K), val(s1,L), val(i,M), val(n,N), 
          p13(A,B,C,D,O,Q,G,H,I,J,K,L,M,N).
p13(A,B,C,D,E,F,G,H,I,J,K,L,M,N) :- O=:=E+P, Q=:=rat(1,1)+R, F=:=R, 
          A-R=<rat(0,1), B-R>=rat(1,1), G-R>=rat(1,1), read((D,B),R,P), 
          val(i,Q), val(s1,O), val(size_a,A), val(size_b,B), val(a,C), 
          val(b,D), val(s1,E), val(i,F), val(n,G), val(size_a,H), 
          val(size_b,I), val(a,J), val(b,K), val(s1,L), val(i,M), val(n,N), 
          p13(A,B,C,D,O,Q,G,H,I,J,K,L,M,N).
p13(A,B,C,D,E,F,G,H,I,J,K,L,M,N) :- O=:=rat(1,1)+F, A-F=<rat(0,1), 
          B-F=<rat(0,1), G-F>=rat(1,1), val(i,O), val(size_a,A), val(size_b,B), 
          val(a,C), val(b,D), val(s1,E), val(i,F), val(n,G), val(size_a,H), 
          val(size_b,I), val(a,J), val(b,K), val(s1,L), val(i,M), val(n,N), 
          p13(A,B,C,D,E,O,G,H,I,J,K,L,M,N).
p13(A,B,C,D,E,F,G,A,B,C,D,E,F,G) :- G-F=<rat(0,1), val(n,G), val(i,F), 
          val(s1,E), val(b,D), val(a,C), val(size_b,B), val(size_a,A).
p12(A,B,C,D,E,F,G,H,I,J,K,L,M,N) :- val(size_a,A), val(size_b,B), val(a,C), 
          val(b,D), val(s1,E), val(i,F), val(n,G), val(size_a,H), 
          val(size_b,I), val(a,J), val(b,K), val(s1,L), val(i,M), val(n,N), 
          p13(A,B,C,D,E,F,G,H,I,J,K,L,M,N).
p11(A,B,C,D,E) :- C=:=F, G=:=rat(0,1), H=:=rat(0,1), A-F=<rat(-1,1), val(n,I), 
          val(i,J), val(b,K), val(a,L), val(size_b,M), val(size_a,N), val(n,F), 
          val(i,H), val(s1,G), p12(A,C,B,D,G,H,F,N,M,L,K,E,J,I).
p11(A,B,C,D,E) :- A=:=F, G=:=rat(0,1), H=:=rat(0,1), C-F=<rat(0,1), val(n,I), 
          val(i,J), val(b,K), val(a,L), val(size_b,M), val(size_a,N), val(n,F), 
          val(i,H), val(s1,G), p12(A,C,B,D,G,H,F,N,M,L,K,E,J,I).

verimap(pred_smtvars_types([specint,p11('Int','(Array Int Int)','Int','(Array Int Int)','Int'),p12('Int','Int','(Array Int Int)','(Array Int Int)','Int','Int','Int','Int','Int','(Array Int Int)','(Array Int Int)','Int','Int','Int'),p13('Int','Int','(Array Int Int)','(Array Int Int)','Int','Int','Int','Int','Int','(Array Int Int)','(Array Int Int)','Int','Int','Int')])).

% Progs/0_src/09_COMP/09.10_two_array_sum_diffsize.transformed/p2.c.map.transform.pl
p25(A,B,C,D,E,F,G,H,I,J,K,L) :- M=:=E+N, O=:=rat(1,1)+P, F=:=P, A-P>=rat(1,1), 
          read((C,A),P,N), val(i,O), val(s2,M), val(size_a,A), val(size_b,B), 
          val(a,C), val(b,D), val(s2,E), val(i,F), val(size_a,G), 
          val(size_b,H), val(a,I), val(b,J), val(s2,K), val(i,L), 
          p25(A,B,C,D,M,O,G,H,I,J,K,L).
p25(A,B,C,D,E,F,A,B,C,D,E,F) :- F-A>=rat(0,1), val(i,F), val(s2,E), val(b,D), 
          val(a,C), val(size_b,B), val(size_a,A).
p24(A,B,C,D,E,F,G,H,I,J,K,L) :- M=:=E+N, O=:=rat(1,1)+P, F=:=P, B-P>=rat(1,1), 
          read((D,B),P,N), val(i,O), val(s2,M), val(size_a,A), val(size_b,B), 
          val(a,C), val(b,D), val(s2,E), val(i,F), val(size_a,G), 
          val(size_b,H), val(a,I), val(b,J), val(s2,K), val(i,L), 
          p24(A,B,C,D,M,O,G,H,I,J,K,L).
p24(A,B,C,D,E,F,A,B,C,D,E,F) :- F-B>=rat(0,1), val(i,F), val(s2,E), val(b,D), 
          val(a,C), val(size_b,B), val(size_a,A).
p23(A,B,C,D,E,F,G,H,I,J,K,L) :- M=:=rat(0,1), val(i,M), val(size_a,A), 
          val(size_b,B), val(a,C), val(b,D), val(s2,E), val(i,F), 
          val(size_a,G), val(size_b,H), val(a,I), val(b,J), val(s2,K), 
          val(i,L), p24(A,B,C,D,E,M,G,H,I,J,K,L).
p22(A,B,C,D,E,F,G,H,I,J,K,L) :- M=:=rat(0,1), val(i,M), val(size_a,A), 
          val(size_b,B), val(a,C), val(b,D), val(s2,E), val(i,F), 
          val(size_a,G), val(size_b,H), val(a,I), val(b,J), val(s2,K), 
          val(i,L), p25(A,B,C,D,E,M,G,H,I,J,K,L).
p21(A,B,C,D,E) :- F=:=rat(0,1), val(i,G), val(b,H), val(a,I), val(size_b,J), 
          val(size_a,K), val(i,L), val(s2,M), val(b,N), val(a,O), 
          val(size_b,P), val(size_a,Q), val(s2,F), val(i,R), val(i,S), 
          p22(A,C,B,D,F,R,Q,P,O,N,M,S), p23(Q,P,O,N,M,L,K,J,I,H,E,G).

verimap(pred_smtvars_types([specint,p21('Int','(Array Int Int)','Int','(Array Int Int)','Int'),p22('Int','Int','(Array Int Int)','(Array Int Int)','Int','Int','Int','Int','(Array Int Int)','(Array Int Int)','Int','Int'),p23('Int','Int','(Array Int Int)','(Array Int Int)','Int','Int','Int','Int','(Array Int Int)','(Array Int Int)','Int','Int'),p24('Int','Int','(Array Int Int)','(Array Int Int)','Int','Int','Int','Int','(Array Int Int)','(Array Int Int)','Int','Int'),p25('Int','Int','(Array Int Int)','(Array Int Int)','Int','Int','Int','Int','(Array Int Int)','(Array Int Int)','Int','Int')])).

% Progs/0_src/09_COMP/09.10_two_array_sum_diffsize/relprop
incorrect :- N>=1, M>=1, Sum1=\=Sum2, p11(N,A,M,B,Sum1),p21(N,A,M,B,Sum2), 
  val(n,N), val(a,A), val(b,B), val(m,M), val(s1,Sum1), val(s2,Sum2).  

verimap(pred_smtvars_types([incorrect])).

verimap(data_types([array-int,bool,uint,long,int])).
