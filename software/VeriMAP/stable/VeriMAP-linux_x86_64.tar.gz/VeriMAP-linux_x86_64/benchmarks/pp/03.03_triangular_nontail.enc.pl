% Progs/0_src/04_I-R/04.03_triangular_nontail.transformed/1.c.map.transform.pl
new13(A,B,C,D,E,F) :- G>=H+1, G=:=C, C>=0, H=:=0, I=:=J+K, J=:=D, D>=0, K=:=C, 
          C>=0, L=:=M-N, M=:=C, C>=0, N=:=1, new13(A,B,L,I,E,F).
new13(A,B,C,D,C,D) :- E=<F, E=:=C, C>=0, F=:=0.
new12(A,B,C,D,E,F) :- G=:=0, new13(A,B,C,G,E,F).
new11(A,B) :- C=:=A, A>=0, D=:=E, E>=0, F=:=D, B=:=F, F>=0, new12(A,G,C,H,I,E).

% Progs/0_src/04_I-R/04.03_triangular_nontail.transformed/2.c.map.transform.pl
new22(A,B,C,D,E,C,F,E) :- G=:=0, H=<I, H=:=C, C>=0, I=:=0, F=:=0.
new22(A,B,C,D,E,C,F,G) :- H=:=0, I>=J+1, I=:=C, C>=0, J=:=0, K=:=L-M, L=:=C, 
          C>=0, M=:=1, G=:=N, N>=0, F=:=O+P, O=:=G, G>=0, P=:=C, C>=0, 
          new22(A,B,K,Q,R,S,N,T).
new21(A,B) :- C=:=A, A>=0, D=:=E, E>=0, F=:=D, B=:=F, F>=0, 
          new22(A,G,C,H,I,J,E,K).

% Progs/0_src/04_I-R/04.03_triangular_nontail/relprop
incorrect :- A1=:=A2, B1=\=B2, new11(A1,B1), new21(A2,B2).
