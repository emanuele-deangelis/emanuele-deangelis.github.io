% Progs/0_src/02_REC/02.14_triangular-mod.transformed/1.c.map.transform.pl
new13(A,B,C,D,E,A,B,C,F,G) :- H=:=0, G=:=0, I=<J, I=:=C, J=:=0, F=:=0.
new13(A,B,C,D,E,F,G,C,H,I) :- J=:=0, K=:=0, L>=M+1, L=:=C, M=:=0, N=:=O-P, 
          O=:=C, P=:=1, Q=:=R, S=:=T+U, T=:=Q, U=:=C, V>=W+1, V=:=S, W=:=15, 
          I=:=X-Y, X=:=S, Y=:=32, H=:=I, new13(A,B,N,Z,A1,F,G,B1,R,C1).
new13(A,B,C,D,E,F,G,C,H,I) :- J=:=0, K=:=0, L>=M+1, L=:=C, M=:=0, N=:=O-P, 
          O=:=C, P=:=1, Q=:=R, S=:=T+U, T=:=Q, U=:=C, V=<W, V=:=S, W=:=15, 
          X+1=<Y, X=:=S, Y=:= -16, I=:=Z+A1, Z=:=S, A1=:=32, H=:=I, 
          new13(A,B,N,B1,C1,F,G,D1,R,E1).
new13(A,B,C,D,E,F,G,C,H,I) :- J=:=0, K=:=0, L>=M+1, L=:=C, M=:=0, N=:=O-P, 
          O=:=C, P=:=1, Q=:=R, I=:=S+T, S=:=Q, T=:=C, U=<V, U=:=I, V=:=15, 
          W>=X, W=:=I, X=:= -16, H=:=I, new13(A,B,N,Y,Z,F,G,A1,R,B1).
new12(A,B,C,D,E,F,C,G) :- H=:=C, G=:=I, new13(A,B,H,J,K,E,F,L,I,M).
new11(A,B) :- C=:=A, B=:=D, new12(A,E,C,F,G,H,I,D).

% Progs/0_src/02_REC/02.14_triangular-mod.transformed/2.c.map.transform.pl
new23(A,B,C,D,E,F,G,H,A,B,C,D,I,J,K,L) :- L=:=0, J=:=0, K=:=0, M=:=0, N=<O, 
          N=:=C, O=:=0, I=:=D.
new23(A,B,C,D,E,F,G,H,I,J,C,D,K,L,M,N) :- O=:=0, P=:=0, Q=:=0, R=:=0, S>=T+1, 
          S=:=C, T=:=0, L=:=U-V, U=:=C, V=:=1, W=:=X+Y, X=:=C, Y=:=D, Z>=A1+1, 
          Z=:=W, A1=:=15, N=:=B1-C1, B1=:=W, C1=:=32, M=:=N, D1=:=L, E1=:=M, 
          K=:=F1, new23(A,B,D1,E1,G1,H1,I1,J1,I,J,K1,L1,F1,M1,N1,O1).
new23(A,B,C,D,E,F,G,H,I,J,C,D,K,L,M,N) :- O=:=0, P=:=0, Q=:=0, R=:=0, S>=T+1, 
          S=:=C, T=:=0, L=:=U-V, U=:=C, V=:=1, W=:=X+Y, X=:=C, Y=:=D, Z=<A1, 
          Z=:=W, A1=:=15, B1+1=<C1, B1=:=W, C1=:= -16, N=:=D1+E1, D1=:=W, 
          E1=:=32, M=:=N, F1=:=L, G1=:=M, K=:=H1, 
          new23(A,B,F1,G1,I1,J1,K1,L1,I,J,M1,N1,H1,O1,P1,Q1).
new23(A,B,C,D,E,F,G,H,I,J,C,D,K,L,M,N) :- O=:=0, P=:=0, Q=:=0, R=:=0, S>=T+1, 
          S=:=C, T=:=0, L=:=U-V, U=:=C, V=:=1, N=:=W+X, W=:=C, X=:=D, Y=<Z, 
          Y=:=N, Z=:=15, A1>=B1, A1=:=N, B1=:= -16, M=:=N, C1=:=L, D1=:=M, 
          K=:=E1, new23(A,B,C1,D1,F1,G1,H1,I1,I,J,J1,K1,E1,L1,M1,N1).
new22(A,B,C,D,E,F,C,G) :- H=:=C, I=:=0, G=:=J, 
          new23(A,B,H,I,K,L,M,N,E,F,O,P,J,Q,R,S).
new21(A,B) :- C=:=A, B=:=D, new22(A,E,C,F,G,H,I,D).

% Progs/0_src/02_REC/02.14_triangular-mod/relprop
incorrect :- A=:=X, C=\=Z, new11(A,C), new21(X,Z).
