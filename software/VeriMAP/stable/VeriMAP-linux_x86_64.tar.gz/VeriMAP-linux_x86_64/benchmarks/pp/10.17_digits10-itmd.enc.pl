% Progs/0_src/11_SPEC/11.17_digits10-itmd.transformed/digits10_itmd.c.map.transform.pl
digits10_itmd2(A,B,C,D,E,F) :- G>=H+1, G=:=A, A>=0, H=:=0, I=:=J+K, J=:=B, 
          B>=0, K=:=1, L=:=A, A>=0, L=:=10*M+N, M>=0, N>=0, N=<9, O>=P+1, 
          O=:=M, M>=0, P=:=0, Q=:=R+S, R=:=I, I>=0, S=:=1, T=:=M, M>=0, 
          T=:=10*U+V, U>=0, V>=0, V=<9, W>=X+1, W=:=U, U>=0, X=:=0, Y=:=Z+A1, 
          Z=:=Q, Q>=0, A1=:=1, B1=:=U, U>=0, B1=:=10*C1+D1, C1>=0, D1>=0, 
          D1=<9, E1>=F1+1, E1=:=C1, C1>=0, F1=:=0, G1=:=H1+I1, H1=:=Y, Y>=0, 
          I1=:=1, J1=:=C1, C1>=0, J1=:=10*K1+L1, K1>=0, L1>=0, L1=<9, 
          digits10_itmd2(K1,G1,J1,D,E,F).
digits10_itmd2(A,B,C,D,E,F) :- G>=H+1, G=:=A, A>=0, H=:=0, I=:=J+K, J=:=B, 
          B>=0, K=:=1, L=:=A, A>=0, L=:=10*M+N, M>=0, N>=0, N=<9, O>=P+1, 
          O=:=M, M>=0, P=:=0, Q=:=R+S, R=:=I, I>=0, S=:=1, T=:=M, M>=0, 
          T=:=10*U+V, U>=0, V>=0, V=<9, W>=X+1, W=:=U, U>=0, X=:=0, Y=:=Z+A1, 
          Z=:=Q, Q>=0, A1=:=1, B1=:=U, U>=0, B1=:=10*C1+D1, C1>=0, D1>=0, 
          D1=<9, E1=<F1, E1=:=C1, C1>=0, F1=:=0, digits10_itmd2(C1,Y,B1,D,E,F).
digits10_itmd2(A,B,C,D,E,F) :- G>=H+1, G=:=A, A>=0, H=:=0, I=:=J+K, J=:=B, 
          B>=0, K=:=1, L=:=A, A>=0, L=:=10*M+N, M>=0, N>=0, N=<9, O>=P+1, 
          O=:=M, M>=0, P=:=0, Q=:=R+S, R=:=I, I>=0, S=:=1, T=:=M, M>=0, 
          T=:=10*U+V, U>=0, V>=0, V=<9, W=<X, W=:=U, U>=0, X=:=0, 
          digits10_itmd2(U,Q,T,D,E,F).
digits10_itmd2(A,B,C,D,E,F) :- G>=H+1, G=:=A, A>=0, H=:=0, I=:=J+K, J=:=B, 
          B>=0, K=:=1, L=:=A, A>=0, L=:=10*M+N, M>=0, N>=0, N=<9, O=<P, O=:=M, 
          M>=0, P=:=0, digits10_itmd2(M,I,L,D,E,F).
digits10_itmd2(A,B,C,A,B,C) :- D=<E, D=:=A, A>=0, E=:=0.
digits10_itmd1(A,B) :- C=:=1, D=:=A, A>=0, D=:=10*E+F, E>=0, F>=0, F=<9, 
          digits10_itmd2(E,C,D,G,B,H).

% Progs/0_src/11_SPEC/11.17_digits10-itmd/relprop

  % digits10_itmd(N,R) :- N>=0, N=<9, R=:=1.
  incorrect :- digits10_itmd1(N,R), N>=0, N=<9, R=\=1.

  % digits10_itmd(N,R) :- N>=10, R=:=R1+1, N=:=10*N1+K, K>=0, K=<9, digits10_itmd(N1,R1).
  incorrect :- digits10_itmd1(N,R), N>=10, R=\=R1+1, N=:=10*N1+K, N1>=1, K>=0,K=<9, digits10_itmd1(N1,R1).
