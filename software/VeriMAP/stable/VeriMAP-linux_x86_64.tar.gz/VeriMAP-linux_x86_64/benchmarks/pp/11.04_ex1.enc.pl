% Progs/compopt/ex1.transformed/1.c.map.transform.pl
new13(A,B,C,D,E,F,A,B,C,D,E,F) :- G>=H, G=:=E, H=:=F.
new13(A,B,C,D,E,F,G,H,I,J,K,L) :- M+1=<N, M=:=E, N=:=F, O>=P, O=:=E, P=:=10, 
          Q=:=R+S, R=:=T*U, T=:=2, U=:=E, S=:=F, V=:=W-X, W=:=Y+Z, Y=:=D, 
          Z=:=E, X=:=1, A1=:=B1+C1, B1=:=D1*E1, D1=:=2, E1=:=E, C1=:=F, 
          F1=:=G1+H1, G1=:=E, H1=:=1, new13(A,B,A1,V,F1,F,G,H,I,J,K,L).
new13(A,B,C,D,E,F,G,H,I,J,K,L) :- M+1=<N, M=:=E, N=:=F, O+1=<P, O=:=E, P=:=10, 
          Q=:=R+S, R=:=T*U, T=:=2, U=:=E, S=:=F, V=:=W+X, W=:=E, X=:=1, 
          new13(A,B,Q,D,V,F,G,H,I,J,K,L).
new12(A,B,C,D,E,F,G,H,I,J,K,L) :- new13(A,B,C,D,E,F,G,H,I,J,K,L).
new11(A,B,C,D) :- E=:=0, F=:=0, G=:=A, H=:=B, new12(A,B,E,F,G,H,I,J,C,D,K,L).
specint :- new11(A,B,C,D).

verimap(pred_smtvars_types([specint,new11('Int','Int','Int','Int'),new12('Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int'),new13('Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int')])).

% Progs/compopt/ex1.transformed/2.c.map.transform.pl
new23(A,B,C,D,E,F,A,B,C,D,E,F) :- G>=H, G=:=E, H=:=F.
new23(A,B,C,D,E,F,G,H,I,J,K,L) :- M+1=<N, M=:=E, N=:=F, O>=P, O=:=E, P=:=10, 
          Q=:=R-S, R=:=T+U, T=:=D, U=:=E, S=:=1, V=:=W+X, W=:=Y*Z, Y=:=2, 
          Z=:=E, X=:=F, A1=:=B1+C1, B1=:=E, C1=:=1, 
          new23(A,B,V,Q,A1,F,G,H,I,J,K,L).
new23(A,B,C,D,E,F,G,H,I,J,K,L) :- M+1=<N, M=:=E, N=:=F, O+1=<P, O=:=E, P=:=10, 
          Q=:=R+S, R=:=T*U, T=:=2, U=:=E, S=:=F, V=:=W+X, W=:=E, X=:=1, 
          new23(A,B,Q,D,V,F,G,H,I,J,K,L).
new22(A,B,C,D,E,F,G,H,I,J,K,L) :- new23(A,B,C,D,E,F,G,H,I,J,K,L).
new21(A,B,C,D) :- E=:=0, F=:=0, G=:=A, H=:=B, new22(A,B,E,F,G,H,I,J,C,D,K,L).
specint :- new21(A,B,C,D).

verimap(pred_smtvars_types([incorrect,new21('Int','Int','Int','Int'),new22('Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int'),new23('Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int')])).

% Progs/compopt/ex1/relprop
incorrect :- A=:=X, B=:=Y, C=\=W, new11(A,B,C,D), new21(X,Y,W,Z).
