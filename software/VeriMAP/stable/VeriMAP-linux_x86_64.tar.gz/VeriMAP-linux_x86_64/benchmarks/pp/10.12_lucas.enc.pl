% Progs/0_src/11_SPEC/11.12_lucas.transformed/lucas.c.map.transform.pl
lucas2(A,B,C,D,E,F,G,H,I,J) :- K>=L+1, K=:=A, L=:=0, M=:=B, N=:=O+P, O=:=B, 
          P=:=C, Q=:=M, R=:=S-T, S=:=A, T=:=1, lucas2(R,N,Q,M,E,F,G,H,I,J).
lucas2(A,B,C,D,E,A,B,C,D,E) :- F=<G, F=:=A, G=:=0.
lucas1(A,B) :- C=:=2, D=:= -1, E=:=0, F=:=0, lucas2(A,C,D,E,F,G,B,H,I,J).

% Progs/0_src/11_SPEC/11.12_lucas/relprop
% lucas(N,L) :- N=:=0, L=:=2.
incorrect :- lucas1(N,L), N=:=0, L=\=2.

% lucas(N,L) :- N=:=1, L=:=1.
incorrect :- lucas1(N,L), N=:=1, L=\=1.

% lucas(N,L) :- N>=2, N1=:=N-1, N2=:=N-2, L=:=L1+L2, lucas(N1,L1), lucas(N2,L2).
incorrect :- lucas1(N,L), N>=2, N1=:=N-1, N2=:=N-2, L=\=L1+L2, lucas1(N1,L1), lucas1(N2,L2).

