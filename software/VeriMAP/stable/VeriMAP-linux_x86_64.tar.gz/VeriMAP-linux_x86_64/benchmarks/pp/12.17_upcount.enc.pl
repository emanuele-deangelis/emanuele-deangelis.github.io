% Progs/NONINT/upcount.transformed/1.c.map.transform.pl
new17(A,B,C,D,E,A,B,C,D,E) :- F+1=<G, F=:=D, G=:=0.
new17(A,B,C,D,E,F,G,H,I,J) :- K>=L, K=:=D, L=:=0, M=:=N+O, N=:=E, O=:=1, 
          P=:=Q-R, Q=:=D, R=:=1, new17(A,B,C,P,M,F,G,H,I,J).
new15(A,B,C,D,E,A,B,C,D,E) :- F=<G, F=:=D, G=:=0.
new15(A,B,C,D,E,F,G,H,I,J) :- K>=L+1, K=:=D, L=:=0, M=:=N+O, N=:=E, O=:=1, 
          P=:=Q-R, Q=:=D, R=:=1, new15(A,B,C,P,M,F,G,H,I,J).
new14(A,B,C,D,E,F,G,H,I,J) :- K=:=0, new15(A,B,C,D,K,F,G,H,I,J).
new13(A,B,C,D,E,F,G,H,I,J) :- K=:=0, new17(A,B,C,D,K,F,G,H,I,J).
new12(A,B,C,D,E,F,G,A,B,C,D,E,H,G) :- H=:=0, I+1=<J, I=:=D, J=:=0.
new12(A,B,C,D,E,F,G,H,I,J,D,E,K,L) :- M=:=0, N>=O, N=:=D, O=:=0, P=:=D, Q=:=R, 
          S=:=D, L=:=T+U, T=:=V, U=:=1, K=:=W-X, W=:=Q, X=:=L, 
          new13(A,B,C,P,Y,Z,A1,B1,C1,R), new14(Z,A1,B1,S,D1,H,I,J,E1,V).
new11(A,B,C) :- D=:=A, E=:=B, C=:=F, new12(A,B,G,D,E,H,I,J,K,L,M,N,F,O).
specint :- new11(A,B,C).

verimap(pred_smtvars_types([specint,new11('Int','Int','Int'),new12('Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int'),new13('Int','Int','Int','Int','Int','Int','Int','Int','Int','Int'),new14('Int','Int','Int','Int','Int','Int','Int','Int','Int','Int'),new15('Int','Int','Int','Int','Int','Int','Int','Int','Int','Int'),new17('Int','Int','Int','Int','Int','Int','Int','Int','Int','Int')])).

% Progs/NONINT/upcount.transformed/2.c.map.transform.pl
new27(A,B,C,D,E,A,B,C,D,E) :- F+1=<G, F=:=D, G=:=0.
new27(A,B,C,D,E,F,G,H,I,J) :- K>=L, K=:=D, L=:=0, M=:=N+O, N=:=E, O=:=1, 
          P=:=Q-R, Q=:=D, R=:=1, new27(A,B,C,P,M,F,G,H,I,J).
new25(A,B,C,D,E,A,B,C,D,E) :- F=<G, F=:=D, G=:=0.
new25(A,B,C,D,E,F,G,H,I,J) :- K>=L+1, K=:=D, L=:=0, M=:=N+O, N=:=E, O=:=1, 
          P=:=Q-R, Q=:=D, R=:=1, new25(A,B,C,P,M,F,G,H,I,J).
new24(A,B,C,D,E,F,G,H,I,J) :- K=:=0, new25(A,B,C,D,K,F,G,H,I,J).
new23(A,B,C,D,E,F,G,H,I,J) :- K=:=0, new27(A,B,C,D,K,F,G,H,I,J).
new22(A,B,C,D,E,F,G,A,B,C,D,E,H,G) :- H=:=0, I+1=<J, I=:=D, J=:=0.
new22(A,B,C,D,E,F,G,H,I,J,D,E,K,L) :- M=:=0, N>=O, N=:=D, O=:=0, P=:=D, Q=:=R, 
          S=:=D, L=:=T+U, T=:=V, U=:=1, K=:=W-X, W=:=Q, X=:=L, 
          new23(A,B,C,P,Y,Z,A1,B1,C1,R), new24(Z,A1,B1,S,D1,H,I,J,E1,V).
new21(A,B,C) :- D=:=A, E=:=B, C=:=F, new22(A,B,G,D,E,H,I,J,K,L,M,N,F,O).
specint :- new21(A,B,C).

verimap(pred_smtvars_types([incorrect,new21('Int','Int','Int'),new22('Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int'),new23('Int','Int','Int','Int','Int','Int','Int','Int','Int','Int'),new24('Int','Int','Int','Int','Int','Int','Int','Int','Int','Int'),new25('Int','Int','Int','Int','Int','Int','Int','Int','Int','Int'),new27('Int','Int','Int','Int','Int','Int','Int','Int','Int','Int')])).

% Progs/NONINT/upcount/relprop
incorrect :- B=:=Y,  C=\=Z, new11(A,B,C), new21(X,Y,Z).
