% Progs/0_src/11_SPEC/11.10_remainder.transformed/rem.c.map.transform.pl
rem2(A,B,C,D) :- E>=F, E=:=B, B>=0, F=:=A, A>=0, G=:=H-I, H=:=B, B>=0, I=:=A, 
          A>=0, rem2(A,G,C,D).
rem2(A,B,A,B) :- C+1=<D, C=:=B, B>=0, D=:=A, A>=0.
rem1(A,B,C) :- rem2(B,A,D,C).

% Progs/0_src/11_SPEC/11.10_remainder/relprop
% Precondition  r>=1, y>=1

% rem(X,Y,Z) :- X=<Y-1, Z=:=X.
incorrect :- rem1(X,Y,Z), X=<Y-1, Z=\=X.

% rem(X,Y,Z) :- X=:=Y, Z=:=0.
incorrect :-  rem1(X,Y,Z), X=:=Y, Z=\=0.

% rem(X,Y,Z) :- X>=Y+1, X1=:=X-Y, Y1=:=Y, Z1=:=Z, rem(X1,Y1,Z1).
incorrect :- rem1(X,Y,Z), X>=Y+1, X1=:=X-Y, Y1=:=Y, Z1=\=Z, rem1(X1,Y1,Z1).

