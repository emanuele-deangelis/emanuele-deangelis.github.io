% Progs/0_src/10_NLIN/10.03_mccarthy91.transformed/1.c.map.transform.pl
new12(A,B,C,D,A,B,C,E) :- F=:=0, G>=H+1, G=:=C, H=:=100, E=:=I-J, I=:=C, J=:=10.
new12(A,B,C,D,E,F,C,G) :- H=:=0, I=<J, I=:=C, J=:=100, K=:=L+M, L=:=C, M=:=11, 
          N=:=O, P=:=N, G=:=Q, new12(A,B,K,R,S,T,U,O), new12(S,T,P,V,E,F,W,Q).
new11(A,B) :- C=:=A, B=:=D, new12(A,E,C,F,G,H,I,D).

% Progs/0_src/10_NLIN/10.03_mccarthy91.transformed/2.c.map.transform.pl
new22(A,B,C,D,E,F,C,G) :- H=:=0, I+1=<J, I=:=C, J=:=101, K=:=L+M, L=:=11, 
          M=:=C, N=:=O, P=:=N, G=:=Q, new22(A,B,K,R,S,T,U,O), 
          new22(S,T,P,V,E,F,W,Q).
new22(A,B,C,D,A,B,C,E) :- F=:=0, G>=H, G=:=C, H=:=101, E=:=I-J, I=:=C, J=:=10.
new21(A,B) :- C=:=A, B=:=D, new22(A,E,C,F,G,H,I,D).

% Progs/0_src/10_NLIN/10.03_mccarthy91/relprop
incorrect :- A=:=X, C=\=Z, new11(A,C), new21(X,Z).
