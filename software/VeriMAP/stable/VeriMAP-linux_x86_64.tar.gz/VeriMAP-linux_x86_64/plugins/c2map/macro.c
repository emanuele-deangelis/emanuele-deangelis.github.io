#define errorFn()                { goto ERROR; ERROR: goto ERROR; }
#define error()                  { goto ERROR; ERROR: goto ERROR; }
#define __VERIFIER_error()       { goto ERROR; ERROR: goto ERROR; }
#define __VERIFIER_assert(cond)  if(cond); else { goto ERROR; ERROR: goto ERROR; }
#define __VERIFIER_assume(cond)  if(cond); else { LOOP: goto LOOP; }

