int __VERIFIER_nondet_int() {
   int val;
   return val;
}

long __VERIFIER_nondet_long() {
   long val;
   return val;
}

unsigned int __VERIFIER_nondet_uint() {
   unsigned int val;
   return val;
}

_Bool __VERIFIER_nondet_bool() {
   _Bool val;
   return val;
}

void __VERIFIER_assume(int expression) {
   if (!expression) { LOOP: goto LOOP; }
   return;
}

void __VERIFIER_assert(int cond) {
  if (!(cond)) {
    ERROR: goto ERROR;
  }
  return;
}

void error(void)
{
  ERROR: goto ERROR;
}

void errorFn(void)
{
  ERROR: goto ERROR;
}

void __VERIFIER_error() 
{ 
  ERROR: goto ERROR; 
}
