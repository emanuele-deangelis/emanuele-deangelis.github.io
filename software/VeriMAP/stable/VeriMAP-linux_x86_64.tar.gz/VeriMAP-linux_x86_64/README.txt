README for VeriMAP
------------------
April, 2017

Quick start
-----------
Download VeriMAP from http://map.uniroma2.it/VeriMAP

and run the following commands: 

  tar -zxvf VeriMAP-linux_x86_64.tar.gz
  cd VeriMAP-linux_x86_64
  

Usage
-----

Getting help

./VeriMAP -h 


Verification Conditions (VCs) generation

./VeriMAP program.c -v smallstep

where 'smallstep' denote the interpeter for the smallstep semantics
(use 'multistep' to get the VCs from the multistep semantics).

The VCs can be found in the file named 'program.c.map.transform.pl' 
located in the same folder as the 'program.c' file.


Constraint propagation

./VeriMAP program.pl -c mdg

where 'mdg' denotes monovariant generalization with widening and convex-hull 
(try 'VeriMAP -h' to get the complete arguments list for the -c option).

The transformed CHCs can be found in the file named 'program.transform.pl' 
located in the same folder as the 'program.pl' file.

Clause reversal and constraint propagation

./VeriMAP program.pl -c mdg -r


Predicate pairing

./VeriMAP program.pl -p

The transformed CHCs can be found in the file named 'program.transform.pl' 
located in the same folder as the 'program.pl' file.


Convert CHCs from Prolog syntax to muZ SMT-LIB2 extension (*) 

./VeriMAP program.pl -o muZ

and run Z3 with Duality

VeriMAP-linux_x86_64$ z3 -smt2 program.z3 fixedpoint.engine=duality

(*) http://rise4fun.com/z3/tutorialcontent/fixedpoints
The translated CHCs can be found in the file named 'program.z3' located in 
the same folder as the 'program.pl' file.


Convert CHCs from Prolog syntax to pure SMT-LIB2

./VeriMAP program.pl -o smt


Benchmarks of hundreds of examples of verification problems can be found in 
'benchmarks/cp/' (divided into 'integers' and 'arrays', for integers and 
integer arrays programs, respectively) and 'benchmarks/pp/'.
