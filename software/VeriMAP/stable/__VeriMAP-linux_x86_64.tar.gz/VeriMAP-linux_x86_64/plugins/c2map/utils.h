int __VERIFIER_nondet_int();
long __VERIFIER_nondet_long();
unsigned int __VERIFIER_nondet_uint();
_Bool __VERIFIER_nondet_bool();
void __VERIFIER_assume(int expression);
void __VERIFIER_assert(int cond);
void error(void);
void errorFn(void);
void __VERIFIER_error();
