# 1 "MAP/SAFE-exbench/INVGEN-up5.tmp.c"
# 1 "<command-line>"
# 1 "MAP/SAFE-exbench/INVGEN-up5.tmp.c"
# 20 "MAP/SAFE-exbench/INVGEN-up5.tmp.c"
void main() {
  int n;
  int i = 0;
  int k = 0;
  while( i < n ) {
   ;
 i++;
 k = k + 2;
  }
  int j = 0;
  while( j < n ) {
   ;
    if(k <= 0) ERROR: goto ERROR;
 j = j + 2;
 k--;
  }
}
