/*
extern void __VERIFIER_error() __attribute__ ((__noreturn__));
void __VERIFIER_assert(int cond) { if(!(cond)) { ERROR: __VERIFIER_error(); } }

#define N 100000

int main ( ) {
  int a[N]; int e;
  int i = 0;
  while( i < N && a[i] != e ) {
    i = i + 1;
  }
  
  int x;
  for ( x = 0 ; x < i ; x++ ) {
    __VERIFIER_assert(  a[x] != e  );
  }
  return 0;
}
*/

int N;
int a[N]; int e;
int i = 0;

int main ( ) { 

  while( i < N && a[i] != e ) {
    i = i + 1;
  }
  
  /*
  int x;
  for ( x = 0 ; x < i ; x++ ) {
    __VERIFIER_assert(  a[x] != e  );
  }
  */
  /*@
    requires N>=1;
    ensures \forall integer x; 0<=x<i ==> a[x]!=e;
  */
  return 0;
}

