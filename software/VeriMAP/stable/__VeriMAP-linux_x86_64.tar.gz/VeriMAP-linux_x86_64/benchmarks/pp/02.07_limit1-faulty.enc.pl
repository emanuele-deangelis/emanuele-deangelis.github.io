% Progs/0_src/02_REC/02.07_limit1-faulty.transformed/1.c.map.transform.pl
new12(A,B,C,D,E,F) :- G>=H+1, G=:=C, H=:=1, I=:=J-K, J=:=C, K=:=2, L=:=M, 
          N=:=O+P, O=:=L, P=:=2, Q+1=<R, Q=:=N, R=:=2, F=:=0, 
          new12(A,B,I,D,E,M).
new12(A,B,C,D,E,F) :- G>=H+1, G=:=C, H=:=1, I=:=J-K, J=:=C, K=:=2, L=:=M, 
          F=:=N+O, N=:=L, O=:=2, P>=Q, P=:=F, Q=:=2, new12(A,B,I,D,E,M).
new12(A,B,C,A,B,D) :- E=<F, E=:=C, F=:=1, G+1=<H, G=:=C, H=:=2, D=:=0.
new11(A,B) :- C=:=A, B=:=D, new12(A,E,C,F,G,D).

% Progs/0_src/02_REC/02.07_limit1-faulty.transformed/2.c.map.transform.pl
new22(A,B,C,D,A,B,C,E) :- F=:=0, G=<H, G=:=C, H=:=1, E=:=C.
new22(A,B,C,D,E,F,C,G) :- H=:=0, I>=J+1, I=:=C, J=:=1, K=:=L-M, L=:=C, M=:=3, 
          N=:=O, G=:=P+Q, P=:=R+S, R=:=C, S=:=T-U, T=:=C, U=:=1, Q=:=N, 
          new22(A,B,K,V,E,F,W,O).
new21(A,B) :- C=:=A, B=:=D, new22(A,E,C,F,G,H,I,D).

% Progs/0_src/02_REC/02.07_limit1-faulty/relprop
incorrect :- A=:=X, C=\=Z, new11(A,C), new21(X,Z).
