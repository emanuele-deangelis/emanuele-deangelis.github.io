% Progs/compopt/sw-pipelining.transformed/1.c.map.transform.pl
new13(A,B,C,D,A,B,C,D) :- E>=F, E=:=A, F=:=B.
new13(A,B,C,D,E,F,G,H) :- I+1=<J, I=:=A, J=:=B, K=:=L+M, L=:=C, M=:=A, N=:=O+P, 
          O=:=D, P=:=K, Q=:=R+S, R=:=A, S=:=1, new13(Q,B,K,N,E,F,G,H).
new12(A,B,C,D,E,F,G,H) :- new13(A,B,C,D,E,F,G,H).
new11(A,B,C,D,E,F) :- new12(A,B,C,D,G,H,E,F).
specint :- new11(A,B,C,D,E,F).

verimap(pred_smtvars_types([specint,new11('Int','Int','Int','Int','Int','Int'),new12('Int','Int','Int','Int','Int','Int','Int','Int'),new13('Int','Int','Int','Int','Int','Int','Int','Int')])).

% Progs/compopt/sw-pipelining.transformed/2.c.map.transform.pl
new23(A,B,C,D,E,B,C,F) :- G>=H, G=:=A, H=:=I-J, I=:=B, J=:=1, F=:=K+L, K=:=D, 
          L=:=C, E=:=M+N, M=:=A, N=:=1.
new23(A,B,C,D,E,F,G,H) :- I+1=<J, I=:=A, J=:=K-L, K=:=B, L=:=1, M=:=N+O, N=:=D, 
          O=:=C, P=:=Q+R, Q=:=A, R=:=1, S=:=T+U, T=:=C, U=:=P, 
          new23(P,B,S,M,E,F,G,H).
new22(A,B,C,D,A,B,C,D) :- E>=F, E=:=A, F=:=B.
new22(A,B,C,D,E,F,G,H) :- I+1=<J, I=:=A, J=:=B, K=:=L+M, L=:=C, M=:=A, 
          new23(A,B,K,D,E,F,G,H).
new21(A,B,C,D,E,F) :- new22(A,B,C,D,G,H,E,F).
specint :- new21(A,B,C,D,E,F).

verimap(pred_smtvars_types([incorrect,new21('Int','Int','Int','Int','Int','Int'),new22('Int','Int','Int','Int','Int','Int','Int','Int'),new23('Int','Int','Int','Int','Int','Int','Int','Int')])).

% Progs/compopt/sw-pipelining/relprop
incorrect :- X1=\=X2, new11(A,B,C,D,X1,Y1), new21(A,B,C,D,X2,Y2).
