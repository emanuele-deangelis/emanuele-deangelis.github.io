% Progs/NONINT/nonint1.transformed/1.c.map.transform.pl
new12(A,B,C,D,B,C) :- E>=F+1, E=:=G+H, G=:=C, H=:=B, F=:=999, I=:= -1, J=:=B, 
          D=:=K-L, K=:=J, L=:=B.
new12(A,B,C,D,B,C) :- E=<F, E=:=G+H, G=:=C, H=:=B, F=:=999, I=:=B, D=:=J-K, 
          J=:=I, K=:=B.
new11(A,B,C,D) :- new12(A,B,C,D,E,F).
specint :- new11(A,B,C,D).

verimap(pred_smtvars_types([specint,new11('Int','Int','Int','Int'),new12('Int','Int','Int','Int','Int','Int')])).

% Progs/NONINT/nonint1.transformed/2.c.map.transform.pl
new22(A,B,C,D,B,C) :- E>=F+1, E=:=G+H, G=:=C, H=:=B, F=:=999, I=:= -1, J=:=B, 
          D=:=K-L, K=:=J, L=:=B.
new22(A,B,C,D,B,C) :- E=<F, E=:=G+H, G=:=C, H=:=B, F=:=999, I=:=B, D=:=J-K, 
          J=:=I, K=:=B.
new21(A,B,C,D) :- new22(A,B,C,D,E,F).
specint :- new21(A,B,C,D).

verimap(pred_smtvars_types([incorrect,new21('Int','Int','Int','Int'),new22('Int','Int','Int','Int','Int','Int')])).

% Progs/NONINT/nonint1/relprop
incorrect :- L=:=L1,
			new11(L,H,J,OutL),
			new21(L1,H1,J1,OutL1),
			OutL =\= OutL1.