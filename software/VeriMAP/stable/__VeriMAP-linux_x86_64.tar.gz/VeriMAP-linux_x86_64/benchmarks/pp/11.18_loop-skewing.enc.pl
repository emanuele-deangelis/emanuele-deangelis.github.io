% Progs/compopt/loop-skewing.transformed/1.c.map.transform.pl
new14(A,B,C,D,E,F,G,H,I,J) :- K+1=<L, K=:=C, L=:=D, M=:=N+O, N=:=E, O=:=1, 
          P=:=Q+R, Q=:=C, R=:=1, new14(A,B,P,D,M,F,G,H,I,J).
new14(A,B,C,D,E,F,G,H,I,J) :- K>=L, K=:=C, L=:=D, M=:=N+O, N=:=A, O=:=1, 
          new13(M,B,C,D,E,F,G,H,I,J).
new13(A,B,C,D,E,A,B,C,D,E) :- F>=G, F=:=A, G=:=B.
new13(A,B,C,D,E,F,G,H,I,J) :- K+1=<L, K=:=A, L=:=B, M=:=0, 
          new14(A,B,M,D,E,F,G,H,I,J).
new12(A,B,C,D,E,F,G,H,I,J) :- K=:=0, new13(A,B,C,D,K,F,G,H,I,J).
new11(A,B,C,D) :- new12(A,B,E,C,F,G,H,I,J,D).
specint :- new11(A,B,C,D).

verimap(pred_smtvars_types([specint,new11('Int','Int','Int','Int'),new12('Int','Int','Int','Int','Int','Int','Int','Int','Int','Int'),new13('Int','Int','Int','Int','Int','Int','Int','Int','Int','Int'),new14('Int','Int','Int','Int','Int','Int','Int','Int','Int','Int')])).

% Progs/compopt/loop-skewing.transformed/2.c.map.transform.pl
new24(A,B,C,D,E,F,G,H,I,J,K,L,M,N) :- O+1=<P, O=:=E, P=:=Q+R, Q=:=D, R=:=F, 
          S=:=T-U, T=:=E, U=:=F, V=:=W+X, W=:=G, X=:=1, Y=:=Z+A1, Z=:=E, 
          A1=:=1, new24(A,B,S,D,Y,F,V,H,I,J,K,L,M,N).
new24(A,B,C,D,E,F,G,H,I,J,K,L,M,N) :- O>=P, O=:=E, P=:=Q+R, Q=:=D, R=:=F, 
          S=:=D, T=:=U+V, U=:=A, V=:=1, new23(T,B,S,D,E,F,G,H,I,J,K,L,M,N).
new23(A,B,C,D,E,F,G,A,B,C,D,E,F,G) :- H>=I, H=:=A, I=:=B.
new23(A,B,C,D,E,F,G,H,I,J,K,L,M,N) :- O+1=<P, O=:=A, P=:=B, Q=:=F, R=:=S-T, 
          S=:=Q, T=:=F, U+1=<V, U=:=Q, V=:=W+X, W=:=D, X=:=F, 
          new24(A,B,R,D,Q,F,G,H,I,J,K,L,M,N).
new23(A,B,C,D,E,F,G,H,I,J,K,L,M,N) :- O+1=<P, O=:=A, P=:=B, Q=:=F, R=:=S-T, 
          S=:=Q, T=:=F, U>=V, U=:=Q, V=:=W+X, W=:=D, X=:=F, Y=:=Z+A1, Z=:=A, 
          A1=:=1, new23(Y,B,R,D,Q,F,G,H,I,J,K,L,M,N).
new22(A,B,C,D,E,F,G,H,I,J,K,L,M,N) :- O=:=0, new23(A,B,C,D,E,F,O,H,I,J,K,L,M,N).
new21(A,B,C,D) :- new22(A,B,E,C,F,G,H,I,J,K,L,M,N,D).
specint :- new21(A,B,C,D).

verimap(pred_smtvars_types([incorrect,new21('Int','Int','Int','Int'),new22('Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int'),new23('Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int'),new24('Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int')])).

% Progs/compopt/loop-skewing/relprop
incorrect :- X1=\=X2, new11(A,B,C,X1), new21(A,B,C,X2).
