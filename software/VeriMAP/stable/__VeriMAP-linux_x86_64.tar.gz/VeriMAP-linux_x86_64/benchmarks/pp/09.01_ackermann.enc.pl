% Progs/0_src/10_NLIN/10.01_ackermann.transformed/1.c.map.transform.pl
new12(A,B,C,D,E,F,G,D,E,H,I) :- I=:=0, J=:=0, K=:=L, K=:=D, L=:=0, H=:=M+N, 
          M=:=E, N=:=1.
new12(A,B,C,D,E,F,G,D,E,H,I) :- I=:=0, J=:=0, K=\=L, K=:=D, L=:=0, M>=N+1, 
          M=:=D, N=:=0, O=:=P, O=:=E, P=:=0, Q=:=R-S, R=:=D, S=:=1, T=:=1, 
          H=:=U, new12(A,B,C,Q,T,V,W,X,Y,U,Z).
new12(A,B,C,D,E,F,G,D,E,H,I) :- J=:=0, K=:=0, L=\=M, L=:=D, M=:=0, N>=O+1, 
          N=:=D, O=:=0, P=\=Q, P=:=E, Q=:=0, R=:=D, S=:=T-U, T=:=E, U=:=1, 
          I=:=V, W=:=X-Y, X=:=D, Y=:=1, Z=:=I, H=:=A1, 
          new12(A,B,C,R,S,B1,C1,D1,E1,V,F1), new12(A,B,C,W,Z,G1,H1,I1,J1,A1,K1).
new12(A,B,C,D,E,F,G,D,E,H,I) :- J=:=0, K=:=0, L=\=M, L=:=D, M=:=0, N=<O, N=:=D, 
          O=:=0, P=:=D, Q=:=R-S, R=:=E, S=:=1, I=:=T, U=:=V-W, V=:=D, W=:=1, 
          X=:=I, H=:=Y, new12(A,B,C,P,Q,Z,A1,B1,C1,T,D1), 
          new12(A,B,C,U,X,E1,F1,G1,H1,Y,I1).
new11(A,B,C) :- D=:=A, E=:=B, C=:=F, new12(A,B,G,D,E,H,I,J,K,F,L).

% Progs/0_src/10_NLIN/10.01_ackermann.transformed/2.c.map.transform.pl
new22(A,B,C,D,E,F,G,D,E,H,I) :- I=:=0, J=:=0, K=:=L, K=:=D, L=:=0, H=:=M+N, 
          M=:=E, N=:=1.
new22(A,B,C,D,E,F,G,D,E,H,I) :- I=:=0, J=:=0, K=\=L, K=:=D, L=:=0, M>=N+1, 
          M=:=D, N=:=0, O=:=P, O=:=E, P=:=0, Q=:=R-S, R=:=D, S=:=1, T=:=1, 
          H=:=U, new22(A,B,C,Q,T,V,W,X,Y,U,Z).
new22(A,B,C,D,E,F,G,D,E,H,I) :- J=:=0, K=:=0, L=\=M, L=:=D, M=:=0, N>=O+1, 
          N=:=D, O=:=0, P=\=Q, P=:=E, Q=:=0, R=:=D, S=:=T-U, T=:=E, U=:=1, 
          I=:=V, W=:=X-Y, X=:=D, Y=:=1, Z=:=I, H=:=A1, 
          new22(A,B,C,R,S,B1,C1,D1,E1,V,F1), new22(A,B,C,W,Z,G1,H1,I1,J1,A1,K1).
new22(A,B,C,D,E,F,G,D,E,H,I) :- J=:=0, K=:=0, L=\=M, L=:=D, M=:=0, N=<O, N=:=D, 
          O=:=0, P=:=D, Q=:=R-S, R=:=E, S=:=1, I=:=T, U=:=V-W, V=:=D, W=:=1, 
          X=:=I, H=:=Y, new22(A,B,C,P,Q,Z,A1,B1,C1,T,D1), 
          new22(A,B,C,U,X,E1,F1,G1,H1,Y,I1).
new21(A,B,C) :- D=:=A, E=:=B, C=:=F, new22(A,B,G,D,E,H,I,J,K,F,L).

% Progs/0_src/10_NLIN/10.01_ackermann/relprop
incorrect :- A=:=X, B=:=Y, C=\=Z, new11(A,B,C), new21(X,Y,Z).
