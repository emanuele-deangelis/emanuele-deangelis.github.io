% Progs/0_src/01_ITE/01.19_simple-loop.transformed/1.c.map.transform.pl
new13(A,B,C,D,E,F,G,H) :- I=<J, I=:=D, J=:=10, K=:=L+M, L=:=D, M=:=1, 
          new13(A,B,C,K,E,F,G,H).
new13(A,B,C,D,A,B,C,D) :- E>=F+1, E=:=D, F=:=10.
new12(A,B,C,D,E,F,G,H) :- I=:=0, new13(A,B,C,I,E,F,G,H).
new11(A,B) :- C=:=A, B=:=D, new12(A,E,C,F,G,H,I,D).

% Progs/0_src/01_ITE/01.19_simple-loop.transformed/2.c.map.transform.pl
new23(A,B,C,D,E,F,G,H) :- I=<J, I=:=D, J=:=10, K=:=L+M, L=:=D, M=:=1, 
          new23(A,B,C,K,E,F,G,H).
new23(A,B,C,D,A,B,C,D) :- E>=F+1, E=:=D, F=:=10.
new22(A,B,C,D,E,F,G,H) :- I=:=1, new23(A,B,C,I,E,F,G,H).
new21(A,B) :- C=:=A, B=:=D, new22(A,E,C,F,G,H,I,D).

% Progs/0_src/01_ITE/01.19_simple-loop/relprop
incorrect :- A=:=X, C=\=Z, new11(A,C), new21(X,Z).
