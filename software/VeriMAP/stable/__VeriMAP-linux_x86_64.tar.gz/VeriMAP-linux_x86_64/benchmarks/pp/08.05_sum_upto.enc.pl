% Progs/0_src/09_COMP/09.05_sum_upto.transformed/p1.c.map.transform.pl
p12(A,B,C,D,E,F) :- G=<H, G=:=C, H=:=A, I=:=J+K, J=:=B, K=:=C, L=:=M+N, M=:=C, 
          N=:=1, p12(A,I,L,D,E,F).
p12(A,B,C,A,B,C) :- D>=E+1, D=:=C, E=:=A.
p11(A,B) :- C=:=0, D=:=0, p12(A,D,C,E,B,F).

% Progs/0_src/09_COMP/09.05_sum_upto.transformed/p2.c.map.transform.pl
p23(A,B,C,D,E,F,G,H) :- I=<J, I=:=D, J=:=B, K=:=L+M, L=:=C, M=:=D, N=:=O+P, 
          O=:=D, P=:=1, p23(A,B,K,N,E,F,G,H).
p23(A,B,C,D,A,B,C,D) :- E>=F+1, E=:=D, F=:=B.
p22(A,B,C,D,E,F,G,H) :- I=<J, I=:=D, J=:=A, K=:=L+M, L=:=C, M=:=D, N=:=O+P, 
          O=:=D, P=:=1, p22(A,B,K,N,E,F,G,H).
p22(A,B,C,D,E,F,G,H) :- I>=J+1, I=:=D, J=:=A, p23(A,B,C,D,E,F,G,H).
p21(A,B,C) :- D=:=0, E=:=0, p22(A,B,E,D,F,G,C,H).

% Progs/0_src/09_COMP/09.05_sum_upto/relprop
incorrect :- N1>=1, N1+1=<M1, M2=M1, Sum2=\=Sum1, p11(M2,Sum1), p21(N1,M1,Sum2). 
