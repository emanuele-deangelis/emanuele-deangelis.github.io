% Progs/0_src/02_REC/02.09_limit2.transformed/1.c.map.transform.pl
new12(A,B,C,D,A,B,C,E) :- F=:=0, G=<H, G=:=C, H=:=0, E=:=C.
new12(A,B,C,D,E,F,C,G) :- H=:=0, I>=J+1, I=:=C, J=:=0, K=:=L-M, L=:=C, M=:=1, 
          N=:=O, G=:=P+Q, P=:=C, Q=:=N, new12(A,B,K,R,E,F,S,O).
new11(A,B) :- C=:=A, B=:=D, new12(A,E,C,F,G,H,I,D).

% Progs/0_src/02_REC/02.09_limit2.transformed/2.c.map.transform.pl
new22(A,B,C,D,A,B,C,E) :- F=:=0, G=<H, G=:=C, H=:=1, E=:=C.
new22(A,B,C,D,E,F,C,G) :- H=:=0, I>=J+1, I=:=C, J=:=1, K=:=L-M, L=:=C, M=:=1, 
          N=:=O, G=:=P+Q, P=:=C, Q=:=N, new22(A,B,K,R,E,F,S,O).
new21(A,B) :- C=:=A, B=:=D, new22(A,E,C,F,G,H,I,D).

% Progs/0_src/02_REC/02.09_limit2/relprop
incorrect :- A=:=X, C=\=Z, new11(A,C), new21(X,Z).
