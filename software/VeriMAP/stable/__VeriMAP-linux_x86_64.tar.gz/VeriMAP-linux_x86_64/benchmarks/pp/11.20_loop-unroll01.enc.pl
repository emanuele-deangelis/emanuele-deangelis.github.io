% Progs/compopt/loop-unroll01.transformed/1.c.map.transform.pl
new13(A,B,C,A,B,C) :- D>=E, D=:=A, E=:=B.
new13(A,B,C,D,E,F) :- G+1=<H, G=:=A, H=:=B, I=:=A, J=:=K+L, K=:=A, L=:=1, 
          new13(J,B,I,D,E,F).
new12(A,B,C,D,E,F) :- new13(A,B,C,D,E,F).
new11(A,B,C,D) :- new12(A,B,C,E,F,D).
specint :- new11(A,B,C,D).

verimap(pred_smtvars_types([specint,new11('Int','Int','Int','Int'),new12('Int','Int','Int','Int','Int','Int'),new13('Int','Int','Int','Int','Int','Int')])).

% Progs/compopt/loop-unroll01.transformed/2.c.map.transform.pl
new23(A,B,C,D,B,E) :- F>=G, F=:=H+I, H=:=A, I=:=1, G=:=B, J+1=<K, J=:=A, K=:=B, 
          E=:=A, D=:=L+M, L=:=A, M=:=1.
new23(A,B,C,A,B,C) :- D>=E, D=:=F+G, F=:=A, G=:=1, E=:=B, H>=I, H=:=A, I=:=B.
new23(A,B,C,D,E,F) :- G+1=<H, G=:=I+J, I=:=A, J=:=1, H=:=B, K=:=A, L=:=M+N, 
          M=:=A, N=:=1, O=:=L, P=:=Q+R, Q=:=L, R=:=1, new23(P,B,O,D,E,F).
new22(A,B,C,D,E,F) :- new23(A,B,C,D,E,F).
new21(A,B,C,D) :- new22(A,B,C,E,F,D).
specint :- new21(A,B,C,D).

verimap(pred_smtvars_types([incorrect,new21('Int','Int','Int','Int'),new22('Int','Int','Int','Int','Int','Int'),new23('Int','Int','Int','Int','Int','Int')])).

% Progs/compopt/loop-unroll01/relprop
incorrect :- X1=\=X2, new11(A,B,X,X1), new21(A,B,X,X2).
