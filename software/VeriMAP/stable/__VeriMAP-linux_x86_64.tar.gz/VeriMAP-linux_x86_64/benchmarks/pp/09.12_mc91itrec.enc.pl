mc91it4(A,B,C,D,A,B,C,D) :- D=<rat(0,1).
mc91it4(A,B,C,D,E,F,G,H) :- I=:=rat(-10,1)+C, J=:=rat(-1,1)+D, rat(101,1)-C=<0, 
          D>=rat(1,1), mc91it4(A,B,I,J,E,F,G,H).
mc91it4(A,B,C,D,E,F,G,H) :- I=:=rat(11,1)+C, J=:=rat(1,1)+D, C-rat(100,1)=<0, 
          D>=rat(1,1), mc91it4(A,B,I,J,E,F,G,H).
mc91it2(A,B,C,D) :- D=:=E, F=:=A, G=:=rat(1,1), mc91it4(A,B,F,G,C,H,E,I).
mc91it1(A,B) :- mc91it2(A,C,D,B).

mc91rec3(A,B,C,D,A,B,C,E) :- E=:=rat(-10,1)+C, C>=rat(101,1).
mc91rec3(A,B,C,D,E,F,C,G) :- G=:=H, C=:=rat(-11,1)+I, J=:=K, I=<rat(111,1), 
          mc91rec3(A,B,I,L,M,N,O,K), mc91rec3(M,N,J,P,E,F,Q,H).
mc91rec2(A,B,C,D) :- D=:=E, F=:=A, mc91rec3(A,B,F,G,C,H,I,E).
mc91rec1(A,B) :- mc91rec2(A,C,D,B).

incorrect :- A1>=0, A1=:=A2, mc91it1(A1,B1), mc91rec1(A2,B2),  B1=\=B2.
