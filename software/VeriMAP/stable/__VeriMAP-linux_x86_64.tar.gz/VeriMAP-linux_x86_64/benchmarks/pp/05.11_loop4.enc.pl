% Progs/0_src/06_MON/06.11_loop4.transformed/1.c.map.transform.pl
new13(A,B,C,D,E,F,G,H,I,J) :- K+1=<L, K=:=D, L=:=M+N, M=:=C, N=:=C, O=:=P+Q, 
          P=:=E, Q=:=1, R=:=S+T, S=:=D, T=:=1, new13(A,B,C,R,O,F,G,H,I,J).
new13(A,B,C,D,E,A,B,C,D,E) :- F>=G, F=:=D, G=:=H+I, H=:=C, I=:=C.
new12(A,B,C,D,E,F,G,H,I,J) :- K=:=0, L=:=0, new13(A,B,C,K,L,F,G,H,I,J).
new11(A,B) :- C=:=A, B=:=D, new12(A,E,C,F,G,H,I,J,K,D).

% Progs/0_src/06_MON/06.11_loop4.transformed/2.c.map.transform.pl
new23(A,B,C,D,E,F,G,H,I,J) :- K+1=<L, K=:=D, L=:=M+N, M=:=C, N=:=C, O=:=P+Q, 
          P=:=E, Q=:=1, R=:=S+T, S=:=D, T=:=1, new23(A,B,C,R,O,F,G,H,I,J).
new23(A,B,C,D,E,A,B,C,D,E) :- F>=G, F=:=D, G=:=H+I, H=:=C, I=:=C.
new22(A,B,C,D,E,F,G,H,I,J) :- K=:=0, L=:=0, new23(A,B,C,K,L,F,G,H,I,J).
new21(A,B) :- C=:=A, B=:=D, new22(A,E,C,F,G,H,I,J,K,D).

% Progs/0_src/06_MON/06.11_loop4/relprop
incorrect :- X2>=X1, Y1>=Y2+1, new11(X1,Y1), new21(X2,Y2).
