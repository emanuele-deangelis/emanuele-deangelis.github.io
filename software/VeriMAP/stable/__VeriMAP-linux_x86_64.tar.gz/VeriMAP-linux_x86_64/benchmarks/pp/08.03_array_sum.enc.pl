% Progs/0_src/09_COMP/09.03_array_sum.transformed/p1.c.map.transform.pl
p13(A,B,C,D,E,F,G,H) :- I=:=rat(1,1)+C+J, K=:=rat(1,1)+L, D=:=L, A-L>=rat(1,1), 
          read((B,A),L,J), val(i,K), val(s1,I), val(n,A), val(a,B), val(s1,C), 
          val(i,D), val(n,E), val(a,F), val(s1,G), val(i,H), 
          p13(A,B,I,K,E,F,G,H).
p13(A,B,C,D,A,B,C,D) :- D-A>=rat(0,1), val(i,D), val(s1,C), val(a,B), val(n,A).
p12(A,B,C,D,E,F,G,H) :- I=:=rat(0,1), val(s1,I), val(n,A), val(a,B), val(s1,C), 
          val(i,D), val(n,E), val(a,F), val(s1,G), val(i,H), 
          p13(A,B,I,D,E,F,G,H).
p11(A,B,C) :- D=:=rat(0,1), val(i,E), val(a,F), val(n,G), val(i,D), val(s1,H), 
          p12(A,B,H,D,G,F,C,E).

verimap(pred_smtvars_types([specint,p11('Int','(Array Int Int)','Int'),p12('Int','(Array Int Int)','Int','Int','Int','(Array Int Int)','Int','Int'),p13('Int','(Array Int Int)','Int','Int','Int','(Array Int Int)','Int','Int')])).

% Progs/0_src/09_COMP/09.03_array_sum.transformed/p2.c.map.transform.pl
p25(A,B,C,D,E,F,G,H) :- I=:=rat(1,1)+J, D=:=J, K=:=J, L=:=rat(1,1)+M, 
          A-J>=rat(1,1), read((B,A),J,M), write((B,A),K,L,(N,A)), val(i,I), 
          val(a,N), val(n,A), val(a,B), val(s2,C), val(i,D), val(n,E), 
          val(a,F), val(s2,G), val(i,H), p25(A,N,C,I,E,F,G,H).
p25(A,B,C,D,A,B,C,D) :- D-A>=rat(0,1), val(i,D), val(s2,C), val(a,B), val(n,A).
p24(A,B,C,D,E,F,G,H) :- I=:=C+J, K=:=rat(1,1)+L, D=:=L, A-L>=rat(1,1), 
          read((B,A),L,J), val(i,K), val(s2,I), val(n,A), val(a,B), val(s2,C), 
          val(i,D), val(n,E), val(a,F), val(s2,G), val(i,H), 
          p24(A,B,I,K,E,F,G,H).
p24(A,B,C,D,A,B,C,D) :- D-A>=rat(0,1), val(i,D), val(s2,C), val(a,B), val(n,A).
p23(A,B,C,D,E,F,G,H) :- I=:=rat(0,1), val(s2,I), val(n,A), val(a,B), val(s2,C), 
          val(i,D), val(n,E), val(a,F), val(s2,G), val(i,H), 
          p24(A,B,I,D,E,F,G,H).
p22(A,B,C,D,E,F,G,H) :- val(n,A), val(a,B), val(s2,C), val(i,D), val(n,E), 
          val(a,F), val(s2,G), val(i,H), p25(A,B,C,D,E,F,G,H).
p21(A,B,C) :- D=:=rat(0,1), E=:=rat(0,1), val(i,F), val(a,G), val(n,H), 
          val(i,D), val(s2,I), val(a,J), val(n,K), val(s2,L), val(i,E), 
          val(i,M), p22(A,B,L,E,K,J,I,M), p23(K,J,I,D,H,G,C,F).

verimap(pred_smtvars_types([specint,p21('Int','(Array Int Int)','Int'),p22('Int','(Array Int Int)','Int','Int','Int','(Array Int Int)','Int','Int'),p23('Int','(Array Int Int)','Int','Int','Int','(Array Int Int)','Int','Int'),p24('Int','(Array Int Int)','Int','Int','Int','(Array Int Int)','Int','Int'),p25('Int','(Array Int Int)','Int','Int','Int','(Array Int Int)','Int','Int')])).

% Progs/0_src/09_COMP/09.03_array_sum/relprop
incorrect :- N>=1, Sum1=\=Sum2, p11(N,A,Sum1), p21(N,A,Sum2), 
  val(n,N), val(a,A), val(s1,Sum1), val(s2,Sum2). 

verimap(pred_smtvars_types([incorrect])).

verimap(data_types([array-int,bool,uint,long,int])).
