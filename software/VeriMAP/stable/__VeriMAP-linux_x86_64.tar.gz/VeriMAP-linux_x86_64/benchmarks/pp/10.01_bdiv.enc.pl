% Progs/0_src/11_SPEC/11.01_bdiv.transformed/bdiv.c.map.transform.pl
bdiv4(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q>=R, Q=:=D, D>=0, R=:=1, S=:=T-U, 
          T=:=D, D>=0, U=:=1, V=:=W+X, W=:=E, E>=0, X=:=E, E>=0, 
          bdiv4(A,B,C,S,V,F,G,H,I,J,K,L,M,N,O,P).
bdiv4(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q+1=<R, Q=:=D, D>=0, R=:=1, S=:=T+U, 
          T=:=C, C>=0, U=:=E, E>=0, bdiv3(A,B,S,D,E,F,G,H,I,J,K,L,M,N,O,P).
bdiv3(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q>=R+1, Q=:=B, B>=0, R=:=F, F>=0, 
          B=:=2*H, S=:=H, H>=0, T=:=U-V, U=:=G, G>=0, V=:=1, W>=X, W=:=A, A>=0, 
          X=:=S, S>=0, Y=:=Z-A1, Z=:=A, A>=0, A1=:=S, S>=0, B1=:=T, T>=0, 
          C1=:=1, bdiv4(Y,S,C,B1,C1,F,T,H,I,J,K,L,M,N,O,P).
bdiv3(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q>=R+1, Q=:=B, B>=0, R=:=F, F>=0, 
          B=:=2*H, S=:=H, H>=0, T=:=U-V, U=:=G, G>=0, V=:=1, W+1=<X, W=:=A, 
          A>=0, X=:=S, S>=0, bdiv3(A,S,C,D,E,F,T,H,I,J,K,L,M,N,O,P).
bdiv3(A,B,C,D,E,F,G,H,A,B,C,D,E,F,G,H) :- I=<J, I=:=B, B>=0, J=:=F, F>=0.
bdiv2(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q>=R, Q=:=A, A>=0, R=:=B, B>=0, 
          S=:=T+U, T=:=B, B>=0, U=:=B, B>=0, V=:=W+X, W=:=G, G>=0, X=:=1, 
          bdiv2(A,S,C,D,E,F,V,H,I,J,K,L,M,N,O,P).
bdiv2(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q+1=<R, Q=:=A, A>=0, R=:=B, B>=0, 
          bdiv3(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
bdiv1(A,B,C,D) :- E=:=0, F=:=B, B>=0, G=:=0, 
          bdiv2(A,B,E,H,I,F,G,J,D,K,C,L,M,N,O,P).

% Progs/0_src/11_SPEC/11.01_bdiv/relprop
% bdiv1(R,M,Q,R1) :- R=<M-1, Q=:=0, R1=:=R.
incorrect :- bdiv1(R,M,Q,R1), R=<M -1, Q=\=0. 
incorrect :- bdiv1(R,M,Q,R1), R=<M -1, R=\=R1.

% bdiv1(R,M,Q,R1) :- R=:=M, Q=:=1, R1=:=0.
incorrect :- bdiv1(R,M,Q,R1), R=:=M, Q=\=1.
incorrect :- bdiv1(R,M,Q,R1), R=:=M, R1=\=0.

% bdiv1(R,M,Q1,R2) :- R>=M+1, R1=:=R-M, Q1=:=Q+1, bdiv1(R1,M,Q,R2).
incorrect :- bdiv1(R,M,Q1,R3), R>=M+1, R1=:=R-M, Q1=\=Q+1, bdiv1(R1,M,Q,R2).  
incorrect :- bdiv1(R,M,Q1,R3), R>=M+1, R1=:=R-M, R3=\=R2,  bdiv1(R1,M,Q,R2). 
