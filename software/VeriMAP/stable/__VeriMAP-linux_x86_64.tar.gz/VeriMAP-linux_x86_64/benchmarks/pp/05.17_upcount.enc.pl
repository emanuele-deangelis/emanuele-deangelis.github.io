% Progs/0_src/06_MON/06.17_upcount.transformed/1.c.map.transform.pl
new13(A,B,C,D,E,F,G,H) :- I>=J, I=:=C, J=:=0, K=:=L+M, L=:=D, M=:=1, N=:=O-P, 
          O=:=C, P=:=1, new13(A,B,N,K,E,F,G,H).
new13(A,B,C,D,A,B,C,D) :- E+1=<F, E=:=C, F=:=0.
new12(A,B,C,D,E,F,G,H) :- I=:=0, new13(A,B,C,I,E,F,G,H).
new11(A,B) :- C=:=A, B=:=D, new12(A,E,C,F,G,H,I,D).

% Progs/0_src/06_MON/06.17_upcount.transformed/2.c.map.transform.pl
new23(A,B,C,D,E,F,G,H) :- I>=J, I=:=C, J=:=0, K=:=L+M, L=:=D, M=:=1, N=:=O-P, 
          O=:=C, P=:=1, new23(A,B,N,K,E,F,G,H).
new23(A,B,C,D,A,B,C,D) :- E+1=<F, E=:=C, F=:=0.
new22(A,B,C,D,E,F,G,H) :- I=:=0, new23(A,B,C,I,E,F,G,H).
new21(A,B) :- C=:=A, B=:=D, new22(A,E,C,F,G,H,I,D).

% Progs/0_src/06_MON/06.17_upcount/relprop
incorrect :- X2>=X1, Y1>=Y2+1, new11(X1,Y1), new21(X2,Y2).
