% Progs/0_src/07_INJ/07.05_loop3.transformed/1.c.map.transform.pl
new13(A,B,C,D,E,F,G,H,I,J) :- K=<L, K=:=D, L=:=C, M=:=N+O, N=:=E, O=:=2, 
          P=:=Q+R, Q=:=D, R=:=1, new13(A,B,C,P,M,F,G,H,I,J).
new13(A,B,C,D,E,A,B,C,D,E) :- F>=G+1, F=:=D, G=:=C.
new12(A,B,C,D,E,F,G,H,I,J) :- K=:=1, L=:=0, M+1=<N, M=:=C, N=:=1, O=:=1, 
          new13(A,B,O,K,L,F,G,H,I,J).
new12(A,B,C,D,E,F,G,H,I,J) :- K=:=1, L=:=0, M>=N, M=:=C, N=:=1, 
          new13(A,B,C,K,L,F,G,H,I,J).
new11(A,B) :- C=:=A, B=:=D, new12(A,E,C,F,G,H,I,J,K,D).

% Progs/0_src/07_INJ/07.05_loop3.transformed/2.c.map.transform.pl
new23(A,B,C,D,E,F,G,H,I,J) :- K=<L, K=:=D, L=:=C, M=:=N+O, N=:=E, O=:=2, 
          P=:=Q+R, Q=:=D, R=:=1, new23(A,B,C,P,M,F,G,H,I,J).
new23(A,B,C,D,E,A,B,C,D,E) :- F>=G+1, F=:=D, G=:=C.
new22(A,B,C,D,E,F,G,H,I,J) :- K=:=1, L=:=0, M+1=<N, M=:=C, N=:=1, O=:=1, 
          new23(A,B,O,K,L,F,G,H,I,J).
new22(A,B,C,D,E,F,G,H,I,J) :- K=:=1, L=:=0, M>=N, M=:=C, N=:=1, 
          new23(A,B,C,K,L,F,G,H,I,J).
new21(A,B) :- C=:=A, B=:=D, new22(A,E,C,F,G,H,I,J,K,D).

% Progs/0_src/07_INJ/07.05_loop3/relprop
incorrect :- X>=1, A>=X+1, C=:=Z, new11(A,C), new21(X,Z).   % injective 
