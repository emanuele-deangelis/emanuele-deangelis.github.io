% Progs/0_src/01_ITE/01.11_loop.transformed/1.c.map.transform.pl
new13(A,B,C,D,E,F,G,H,I,J) :- K=<L, K=:=D, L=:=C, M=:=N+O, N=:=D, O=:=1, 
          P=:=Q+R, Q=:=E, R=:=1, new13(A,B,C,M,P,F,G,H,I,J).
new13(A,B,C,D,E,A,B,C,D,E) :- F>=G+1, F=:=D, G=:=C.
new12(A,B,C,D,E,F,G,H,I,J) :- K=:=0, L=:=0, new13(A,B,C,K,L,F,G,H,I,J).
new11(A,B) :- C=:=A, B=:=D, new12(A,E,C,F,G,H,I,J,K,D).

% Progs/0_src/01_ITE/01.11_loop.transformed/2.c.map.transform.pl
new23(A,B,C,D,E,F,G,H,I,J) :- K>=L, K=:=D, L=:=0, M=:=N-O, N=:=D, O=:=1, 
          P=:=Q+R, Q=:=E, R=:=1, new23(A,B,C,M,P,F,G,H,I,J).
new23(A,B,C,D,E,A,B,C,D,E) :- F+1=<G, F=:=D, G=:=0.
new22(A,B,C,D,E,F,G,H,I,J) :- K=:=C, L=:=0, new23(A,B,C,K,L,F,G,H,I,J).
new21(A,B) :- C=:=A, B=:=D, new22(A,E,C,F,G,H,I,J,K,D).

% Progs/0_src/01_ITE/01.11_loop/relprop
incorrect :- A=:=X, C=\=Z, new11(A,C), new21(X,Z).
