% Progs/compopt/loop-flattening.transformed/1.c.map.transform.pl
new14(A,B,C,D) :- E+1=<F, E=:=B, F=:=100, G=:=H+I, H=:=B, I=:=1, new14(A,G,C,D).
new14(A,B,C,D) :- E>=F, E=:=B, F=:=100, G=:=H+I, H=:=A, I=:=1, new13(G,B,C,D).
new13(A,B,A,B) :- C>=D, C=:=A, D=:=100.
new13(A,B,C,D) :- E+1=<F, E=:=A, F=:=100, G=:=0, new14(A,G,C,D).
new12(A,B,C,D) :- E=:=0, new13(E,B,C,D).
new11(A,B) :- new12(C,D,A,B).

verimap(pred_smtvars_types([specint,new11('Int','Int'),new12('Int','Int','Int','Int'),new13('Int','Int','Int','Int'),new14('Int','Int','Int','Int')])).

% Progs/compopt/loop-flattening.transformed/2.c.map.transform.pl
new23(A,B,C,D,E,C) :- F>=G, F=:=C, G=:=10000, D=:=100, E=:=100.
new23(A,B,C,D,E,F) :- G+1=<H, G=:=C, H=:=10000, I=:=J*K+L, L>=0, L+1=<K, I=:=C, 
          K=:=100, M=:=N-O, N=:=C, O=:=P*Q, P=:=100, Q=:=J, R=:=S+T, S=:=C, 
          T=:=1, new23(J,M,R,D,E,F).
new22(A,B,C,D,E,F) :- G=:=0, H=:=0, I+1=<J, I=:=G, J=:=100, new23(G,B,H,D,E,F).
new21(A,B) :- new22(C,D,E,A,B,F).

verimap(pred_smtvars_types([incorrect,new21('Int','Int'),new22('Int','Int','Int','Int','Int','Int'),new23('Int','Int','Int','Int','Int','Int')])).

% Progs/compopt/loop-flattening/relprop
incorrect :- B=\=D, new11(A,B), new21(C,D).
