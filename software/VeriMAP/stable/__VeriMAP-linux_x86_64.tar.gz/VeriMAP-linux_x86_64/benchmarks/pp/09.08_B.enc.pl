% v1 not verified after pairing
% v1-unfolded verified after pairing
% v2 verified without pairing

b(M1,N1,A1) :- b1(M1,N1,A1).
b1(M1,N1,A1) :- M1=0, A1=N1+1.
b1(M1,N1,A1) :- M1>0, N1>=0, X1=M1-1, 
				b1(X1,N1,Z1),
				
				%%%% N2=N1-1, b1(M1,N2,Z1),   % v2
				
				b1(X1,Z1,A1).




bite1(D,E,E) :- D=< 0.
bite1(D,E,J) :- L= -1+D, E1= E-1,  1-D=< 0, 
          % bite(L,E,M),          % version 1
          M1=M-1, bite1(L,E,M1),  % version 1 - unfolded
          
          %%%%bite(D,E1,M),  % v2 
                    
          bite1(L,M,J).
bite(A,B,C) :- D= -1+C, bite1(A,B,D).




incorrect :- M1=M2, N1=N2, A1=\=A2, b(M1,N1,A1), bite(M2,N2,A2).


verimap(pred_smtvars_types([incorrect,
	b('Int','Int','Int'),
	b1('Int','Int','Int'),
	bite('Int','Int','Int'),
	bite1('Int','Int','Int') 	

])).
	
	
