% Progs/0_src/09_COMP/09.09_two_arrays_sum.transformed/p1.c.map.transform.pl
p13(A,B,C,D,E,F,G,H,I,J) :- K=:=D+L+M, N=:=rat(1,1)+O, E=:=O, P=:=O, 
          A-O>=rat(1,1), read((B,A),O,M), read((C,A),P,L), val(i,N), val(s1,K), 
          val(n,A), val(a,B), val(b,C), val(s1,D), val(i,E), val(n,F), 
          val(a,G), val(b,H), val(s1,I), val(i,J), p13(A,B,C,K,N,F,G,H,I,J).
p13(A,B,C,D,E,A,B,C,D,E) :- E-A>=rat(0,1), val(i,E), val(s1,D), val(b,C), 
          val(a,B), val(n,A).
p12(A,B,C,D,E,F,G,H,I,J) :- val(n,A), val(a,B), val(b,C), val(s1,D), val(i,E), 
          val(n,F), val(a,G), val(b,H), val(s1,I), val(i,J), 
          p13(A,B,C,D,E,F,G,H,I,J).
p11(A,B,C,D) :- E=:=rat(0,1), F=:=rat(0,1), val(i,G), val(b,H), val(a,I), 
          val(n,J), val(i,F), val(s1,E), p12(A,B,C,E,F,J,I,H,D,G).

verimap(pred_smtvars_types([specint,p11('Int','(Array Int Int)','(Array Int Int)','Int'),p12('Int','(Array Int Int)','(Array Int Int)','Int','Int','Int','(Array Int Int)','(Array Int Int)','Int','Int'),p13('Int','(Array Int Int)','(Array Int Int)','Int','Int','Int','(Array Int Int)','(Array Int Int)','Int','Int')])).

% Progs/0_src/09_COMP/09.09_two_arrays_sum.transformed/p2.c.map.transform.pl
p25(A,B,C,D,E,F,G,H,I,J) :- K=:=D+L, M=:=rat(1,1)+N, E=:=N, A-N>=rat(1,1), 
          read((B,A),N,L), val(i,M), val(s2,K), val(n,A), val(a,B), val(b,C), 
          val(s2,D), val(i,E), val(n,F), val(a,G), val(b,H), val(s2,I), 
          val(i,J), p25(A,B,C,K,M,F,G,H,I,J).
p25(A,B,C,D,E,A,B,C,D,E) :- E-A>=rat(0,1), val(i,E), val(s2,D), val(b,C), 
          val(a,B), val(n,A).
p24(A,B,C,D,E,F,G,H,I,J) :- K=:=D+L, M=:=rat(1,1)+N, E=:=N, A-N>=rat(1,1), 
          read((C,A),N,L), val(i,M), val(s2,K), val(n,A), val(a,B), val(b,C), 
          val(s2,D), val(i,E), val(n,F), val(a,G), val(b,H), val(s2,I), 
          val(i,J), p24(A,B,C,K,M,F,G,H,I,J).
p24(A,B,C,D,E,A,B,C,D,E) :- E-A>=rat(0,1), val(i,E), val(s2,D), val(b,C), 
          val(a,B), val(n,A).
p23(A,B,C,D,E,F,G,H,I,J) :- val(n,A), val(a,B), val(b,C), val(s2,D), val(i,E), 
          val(n,F), val(a,G), val(b,H), val(s2,I), val(i,J), 
          p24(A,B,C,D,E,F,G,H,I,J).
p22(A,B,C,D,E,F,G,H,I,J) :- val(n,A), val(a,B), val(b,C), val(s2,D), val(i,E), 
          val(n,F), val(a,G), val(b,H), val(s2,I), val(i,J), 
          p25(A,B,C,D,E,F,G,H,I,J).
p21(A,B,C,D) :- E=:=rat(0,1), F=:=rat(0,1), G=:=rat(0,1), val(i,H), val(b,I), 
          val(a,J), val(n,K), val(i,E), val(s2,L), val(b,M), val(a,N), 
          val(n,O), val(s2,F), val(i,G), val(i,P), p22(A,B,C,F,G,O,N,M,L,P), 
          p23(O,N,M,L,E,K,J,I,D,H).

verimap(pred_smtvars_types([specint,p21('Int','(Array Int Int)','(Array Int Int)','Int'),p22('Int','(Array Int Int)','(Array Int Int)','Int','Int','Int','(Array Int Int)','(Array Int Int)','Int','Int'),p23('Int','(Array Int Int)','(Array Int Int)','Int','Int','Int','(Array Int Int)','(Array Int Int)','Int','Int'),p24('Int','(Array Int Int)','(Array Int Int)','Int','Int','Int','(Array Int Int)','(Array Int Int)','Int','Int'),p25('Int','(Array Int Int)','(Array Int Int)','Int','Int','Int','(Array Int Int)','(Array Int Int)','Int','Int')])).

% Progs/0_src/09_COMP/09.09_two_arrays_sum/relprop
incorrect :- N>=1, Sum1=\=Sum2, p11(N,A,B,Sum1), p21(N,A,B,Sum2), 
  val(n,N), val(a,A), val(b,B), val(s1,Sum1), val(s2,Sum2).  

verimap(pred_smtvars_types([incorrect])).

verimap(data_types([array-int,bool,uint,long,int])).
