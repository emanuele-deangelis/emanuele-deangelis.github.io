% drec
ackermann1(M1,N1,A1) :- ack1(M1,N1,A1).
ack1(M1,N1,A1) :- M1=<0, A1=N1+1.
ack1(M1,N1,A1) :- M1>=1, N1=0, X1=M1-1, Y1=1, ack1(X1,Y1,A1).
ack1(M1,N1,A1) :- M1>=1, N1>=1, X1=M1-1, Y1=N1-1, ack1(M1,Y1,Z1), ack1(X1,Z1,A1).

% iterec
ackermann2(A,B,C) :- D= -1+C, ack2(A,B,D).
ack2(D,E,E) :- D=<0.
ack2(D,E,J) :- D>=1, E=0,   K= -1+D, L=1, ack2(K,L,J).
ack2(D,E,J) :- D>=1, E=\=0, K= -1+E, L= -1+D, M= -1+N, ack2(D,K,M), ack2(L,N,J).

incorrect :- M1=M2, M1>=0, N1=N2, N1>=0, A1=\=A2, ackermann1(M1,N1,A1), ackermann2(M2,N2,A2).
