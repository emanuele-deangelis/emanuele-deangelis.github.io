% Progs/NONINT/nonint1-hard.transformed/1.c.map.transform.pl
new12(A,B,C,D,A,B,C,D) :- E>=F, E=:=D, F=:=10000.
new12(A,B,C,D,E,F,G,H) :- I+1=<J, I=:=D, J=:=10000, K>=L+1, K=:=M+N, M=:=C, 
          N=:=B, L=:=999, O=:= -1, P=:=B, Q=:=R-S, R=:=P, S=:=B, T=:=U+V, 
          U=:=B, V=:=1, W=:=X+Y, X=:=D, Y=:=1, new12(Q,T,C,W,E,F,G,H).
new12(A,B,C,D,E,F,G,H) :- I+1=<J, I=:=D, J=:=10000, K=<L, K=:=M+N, M=:=C, 
          N=:=B, L=:=999, O=:=B, P=:=Q-R, Q=:=O, R=:=B, S=:=T+U, T=:=B, U=:=1, 
          V=:=W+X, W=:=D, X=:=1, new12(P,S,C,V,E,F,G,H).
new11(A,B,C,D) :- E=:=0, new12(A,B,C,E,D,F,G,H).
specint :- new11(A,B,C,D).

verimap(pred_smtvars_types([specint,new11('Int','Int','Int','Int'),new12('Int','Int','Int','Int','Int','Int','Int','Int')])).

% Progs/NONINT/nonint1-hard.transformed/2.c.map.transform.pl
new22(A,B,C,D,A,B,C,D) :- E>=F, E=:=D, F=:=10000.
new22(A,B,C,D,E,F,G,H) :- I+1=<J, I=:=D, J=:=10000, K>=L+1, K=:=M+N, M=:=C, 
          N=:=B, L=:=999, O=:= -1, P=:=B, Q=:=R-S, R=:=P, S=:=B, T=:=U+V, 
          U=:=B, V=:=1, W=:=X+Y, X=:=D, Y=:=1, new22(Q,T,C,W,E,F,G,H).
new22(A,B,C,D,E,F,G,H) :- I+1=<J, I=:=D, J=:=10000, K=<L, K=:=M+N, M=:=C, 
          N=:=B, L=:=999, O=:=B, P=:=Q-R, Q=:=O, R=:=B, S=:=T+U, T=:=B, U=:=1, 
          V=:=W+X, W=:=D, X=:=1, new22(P,S,C,V,E,F,G,H).
new21(A,B,C,D) :- E=:=0, new22(A,B,C,E,D,F,G,H).
specint :- new21(A,B,C,D).

verimap(pred_smtvars_types([incorrect,new21('Int','Int','Int','Int'),new22('Int','Int','Int','Int','Int','Int','Int','Int')])).

% Progs/NONINT/nonint1-hard/relprop
incorrect :- L=:=L1,
			H >= 1,
			new11(L,H,J,OutL),
			new21(L1,H1,J1,OutL1),
			OutL =\= OutL1.