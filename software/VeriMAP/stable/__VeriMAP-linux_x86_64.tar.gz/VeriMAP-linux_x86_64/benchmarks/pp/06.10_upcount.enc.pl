% Progs/0_src/07_INJ/07.10_upcount.transformed/1.c.map.transform.pl
new13(A,B,C,D,E,F,G,H) :- I>=J, I=:=C, J=:=0, K=:=L+M, L=:=D, M=:=1, N=:=O-P, 
          O=:=C, P=:=1, new13(A,B,N,K,E,F,G,H).
new13(A,B,C,D,A,B,C,D) :- E+1=<F, E=:=C, F=:=0.
new12(A,B,C,D,E,F,G,H) :- I=:=0, new13(A,B,C,I,E,F,G,H).
new11(A,B) :- C=:=A, B=:=D, new12(A,E,C,F,G,H,I,D).

% Progs/0_src/07_INJ/07.10_upcount.transformed/2.c.map.transform.pl
new23(A,B,C,D,E,F,G,H) :- I>=J, I=:=C, J=:=0, K=:=L+M, L=:=D, M=:=1, N=:=O-P, 
          O=:=C, P=:=1, new23(A,B,N,K,E,F,G,H).
new23(A,B,C,D,A,B,C,D) :- E+1=<F, E=:=C, F=:=0.
new22(A,B,C,D,E,F,G,H) :- I=:=0, new23(A,B,C,I,E,F,G,H).
new21(A,B) :- C=:=A, B=:=D, new22(A,E,C,F,G,H,I,D).

% Progs/0_src/07_INJ/07.10_upcount/relprop
incorrect :- A>=0, A>=X+1, C=:=Z, new11(A,C), new21(X,Z).   % injective 
