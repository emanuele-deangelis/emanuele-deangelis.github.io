% Progs/0_src/05_ARR/05.01_fib.transformed/1.c.map.transform.pl
new13(A,B,C,D,E,F,G,H,I,J,K,L,M,N) :- O=:=rat(1,1)+D, P=:=F, Q=:=E+F, R=:=E, 
          C-D>=rat(1,1), val(t,R), val(b,Q), val(a1,P), val(i1,O), val(in1,A), 
          val(out1,B), val(n,C), val(i1,D), val(a1,E), val(b,F), val(t,G), 
          val(in1,H), val(out1,I), val(n,J), val(i1,K), val(a1,L), val(b,M), 
          val(t,N), new13(A,B,C,O,P,Q,R,H,I,J,K,L,M,N).
new13(A,B,C,D,E,F,G,A,B,C,D,E,F,G) :- D-C>=rat(0,1), val(t,G), val(b,F), 
          val(a1,E), val(i1,D), val(n,C), val(out1,B), val(in1,A).
new12(A,B,C,D,E,F,G,H,I,J,K,L,M,N) :- O=:=rat(2,1), P=:=rat(1,1), Q=:=rat(1,1), 
          val(b,Q), val(a1,P), val(i1,O), val(in1,A), val(out1,B), val(n,C), 
          val(i1,D), val(a1,E), val(b,F), val(t,G), val(in1,H), val(out1,I), 
          val(n,J), val(i1,K), val(a1,L), val(b,M), val(t,N), 
          new13(A,B,C,O,P,Q,G,H,I,J,K,L,M,N).
new11(A,B) :- A=:=C, D=:=B, val(t,E), val(b,D), val(a1,F), val(i1,G), val(n,H), 
          val(out1,I), val(in1,J), val(t,K), val(b,L), val(a1,M), val(i1,N), 
          val(n,C), val(out1,O), new12(A,O,C,N,M,L,K,J,I,H,G,F,D,E).

verimap(pred_smtvars_types([specint,new11('Int','Int'),new12('Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int'),new13('Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int')])).

% Progs/0_src/05_ARR/05.01_fib.transformed/2.c.map.transform.pl
new23(A,B,C,D,E,F,G,H,I,J) :- K=:=rat(2,1)+L, E=:=rat(1,1)+L, M=:=rat(1,1)+L, 
          N=:=O+P, Q=:=rat(-1,1)+L, D-L>=rat(2,1), read((C,A),L,P), 
          read((C,A),Q,O), write((C,A),M,N,(R,A)), val(i2,K), val(a,R), 
          val(in2,A), val(out2,B), val(a,C), val(n,D), val(i2,E), val(in2,F), 
          val(out2,G), val(a,H), val(n,I), val(i2,J), 
          new23(A,B,R,D,K,F,G,H,I,J).
new23(A,B,C,D,E,A,B,C,D,E) :- E-D>=rat(0,1), val(i2,E), val(n,D), val(a,C), 
          val(out2,B), val(in2,A).
new22(A,B,C,D,E,F,G,H,I,J) :- K=:=rat(2,1), L=:=rat(1,1), M=:=rat(1,1), 
          N=:=rat(0,1), O=:=rat(1,1), write((C,A),N,O,(P,A)), 
          write((P,A),L,M,(Q,A)), val(i2,K), val(a,Q), val(in2,A), val(out2,B), 
          val(a,C), val(n,D), val(i2,E), val(in2,F), val(out2,G), val(a,H), 
          val(n,I), val(i2,J), new23(A,B,Q,D,K,F,G,H,I,J).
new21(A,B) :- A=:=C, D=:=rat(1,1)+E, F=:=B, read((G,H),E,F), val(i2,D), 
          val(n,I), val(a,G), val(out2,J), val(in2,H), val(i2,K), val(n,C), 
          val(a,L), val(out2,M), new22(A,M,L,C,K,H,J,G,I,D).

verimap(pred_smtvars_types([specint,new21('Int','Int'),new22('Int','Int','(Array Int Int)','Int','Int','Int','Int','(Array Int Int)','Int','Int'),new23('Int','Int','(Array Int Int)','Int','Int','Int','Int','(Array Int Int)','Int','Int')])).

% Progs/0_src/05_ARR/05.01_fib/relprop
incorrect :- A1=:=A2, A1>=0, B1=\=B2, new11(A1,B1), new21(A2,B2), 
  val(in1,A1), val(in2,A2), val(out1,B1), val(out2,B2).  

verimap(pred_smtvars_types([incorrect])).

verimap(data_types([array-int,bool,uint,long,int])).
