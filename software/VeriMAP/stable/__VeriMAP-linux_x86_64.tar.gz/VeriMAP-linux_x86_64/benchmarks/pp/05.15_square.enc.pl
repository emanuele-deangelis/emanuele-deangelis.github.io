% Progs/0_src/06_MON/06.15_square.transformed/1.c.map.transform.pl
new13(A,B,C,D,E,F,G,H) :- I>=J+1, I=:=E, J=:=0, K=:=L+M, L=:=D, M=:=C, N=:=O-P, 
          O=:=E, P=:=1, new13(A,B,C,K,N,F,G,H).
new13(A,B,C,D,E,C,D,E) :- F=<G, F=:=E, G=:=0.
new12(A,B,C,D,E,F,G,H) :- I=:=0, J=:=C, new13(A,B,C,I,J,F,G,H).
new11(A,B) :- C=:=A, B=:=D, new12(A,E,C,F,G,H,D,I).

% Progs/0_src/06_MON/06.15_square.transformed/2.c.map.transform.pl
new23(A,B,C,D,E,F,G,H) :- I>=J+1, I=:=E, J=:=0, K=:=L+M, L=:=D, M=:=C, N=:=O-P, 
          O=:=E, P=:=1, new23(A,B,C,K,N,F,G,H).
new23(A,B,C,D,E,C,D,E) :- F=<G, F=:=E, G=:=0.
new22(A,B,C,D,E,F,G,H) :- I=:=0, J=:=C, new23(A,B,C,I,J,F,G,H).
new21(A,B) :- C=:=A, B=:=D, new22(A,E,C,F,G,H,D,I).

% Progs/0_src/06_MON/06.15_square/relprop
incorrect :- X2>=X1, Y1>=Y2+1, new11(X1,Y1), new21(X2,Y2).
