% Progs/compopt/spin13-ex.transformed/1.c.map.transform.pl
new13(A,B,C,A,B,C) :- D>=E, D=:=A, E=:=B.
new13(A,B,C,D,E,F) :- G+1=<H, G=:=A, H=:=B, I=:=J+K, J=:=C, K=:=1, L=:=M+N, 
          M=:=A, N=:=1, new13(L,B,I,D,E,F).
new12(A,B,C,D,E,F) :- G=:=0, new13(G,B,C,D,E,F).
new11(A,B,C) :- new12(D,A,B,E,F,C).

verimap(pred_smtvars_types([specint,new11('Int','Int','Int'),new12('Int','Int','Int','Int','Int','Int'),new13('Int','Int','Int','Int','Int','Int')])).

% Progs/compopt/spin13-ex.transformed/2.c.map.transform.pl
new23(A,B,C,D,E,F,B,C,D,E) :- G+1=<H, G=:=C, H=:=1, I>=J+1, I=:=B, J=:=0, F=:=B.
new23(A,B,C,D,E,F,B,C,D,E) :- G+1=<H, G=:=C, H=:=1, I=<J, I=:=B, J=:=0, F=:=0.
new23(A,B,C,D,E,F,G,H,I,J) :- K>=L, K=:=C, L=:=1, M=:=N-O, N=:=B, O=:=C, 
          P=:=Q+R, Q=:=E, R=:=1, S=:=T-U, T=:=C, U=:=1, 
          new23(M,B,S,D,P,F,G,H,I,J).
new22(A,B,C,D,E,F,G,H,I,J) :- K=:=B, new23(A,B,K,D,E,F,G,H,I,J).
new21(A,B,C) :- new22(D,A,E,F,B,G,H,I,J,C).

verimap(pred_smtvars_types([incorrect,new21('Int','Int','Int'),new22('Int','Int','Int','Int','Int','Int','Int','Int','Int','Int'),new23('Int','Int','Int','Int','Int','Int','Int','Int','Int','Int')])).

% Progs/compopt/spin13-ex/relprop
incorrect :- X1=\=X2, new11(A,B,X1), new21(A,B,X2).
