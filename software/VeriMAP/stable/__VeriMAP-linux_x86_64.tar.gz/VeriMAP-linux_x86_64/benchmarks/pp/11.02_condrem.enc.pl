% Progs/compopt/condrem.transformed/1.c.map.transform.pl
new14(A,B,C,D,E,F,A,B,C,D,E,F) :- F-D>=rat(0,1).
new14(A,B,C,D,E,F,G,H,I,J,K,L) :- M=:=C+rat(2,1)*E, N=:=rat(1,1)+F, 
          D-F>=rat(6,1), new14(A,B,M,D,E,N,G,H,I,J,K,L).
new14(A,B,C,D,E,F,G,H,I,J,K,L) :- M=:=C+rat(2,1)*E, N=:=rat(1,1)+F, 
          D-F=<rat(5,1), D-F>=rat(1,1), new14(A,B,M,D,E,N,G,H,I,J,K,L).
new13(A,B,C,D,E,F,G,H,I,J,K,L) :- M=:=rat(0,1), new14(A,B,C,D,E,M,G,H,I,J,K,L).
new12(A,B,C,D,E,F) :- G=:=B, H=:=A, new13(A,B,C,H,G,I,D,E,F,J,K,L).
new11(A,B,C) :- D=:=rat(0,1), new12(A,B,D,E,F,C).

verimap(pred_smtvars_types([specint,new11('Int','Int','Int'),new12('Int','Int','Int','Int','Int','Int'),new13('Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int'),new14('Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int')])).

% Progs/compopt/condrem.transformed/2.c.map.transform.pl
new24(A,B,C,D,E,F,A,B,C,D,E,F) :- F-D>=rat(0,1).
new24(A,B,C,D,E,F,G,H,I,J,K,L) :- M=:=C+rat(2,1)*E, N=:=rat(1,1)+F, 
          D-F>=rat(1,1), new24(A,B,M,D,E,N,G,H,I,J,K,L).
new23(A,B,C,D,E,F,G,H,I,J,K,L) :- M=:=rat(0,1), new24(A,B,C,D,E,M,G,H,I,J,K,L).
new22(A,B,C,D,E,F) :- G=:=B, H=:=A, new23(A,B,C,H,G,I,D,E,F,J,K,L).
new21(A,B,C) :- D=:=rat(0,1), new22(A,B,D,E,F,C).

verimap(pred_smtvars_types([incorrect,new21('Int','Int','Int'),new22('Int','Int','Int','Int','Int','Int'),new23('Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int'),new24('Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int')])).

% Progs/compopt/condrem/relprop
incorrect :- A=:=X, B=:=Y, C=\=W, new11(A,B,C), new21(X,Y,W).
