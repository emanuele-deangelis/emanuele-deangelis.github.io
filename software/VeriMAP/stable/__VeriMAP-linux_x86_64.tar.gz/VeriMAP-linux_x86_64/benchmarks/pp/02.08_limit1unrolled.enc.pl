% Progs/0_src/02_REC/02.08_limit1unrolled.transformed/1.c.map.transform.pl
new12(A,B,C,D,E,F,A,B,C,G,H,I) :- J=:=0, H=:=0, I=:=0, K=<L, K=:=C, L=:=1, 
          G=:=C.
new12(A,B,C,D,E,F,A,B,C,G,H,I) :- J=:=0, K=:=0, L=:=0, M>=N+1, M=:=C, N=:=1, 
          I=:=O-P, O=:=C, P=:=1, Q=:=0, R=<S, R=:=I, S=:=1, H=:=I, T=:=H, 
          G=:=U+V, U=:=C, V=:=T.
new12(A,B,C,D,E,F,G,H,C,I,J,K) :- L=:=0, M=:=0, N=:=0, O>=P+1, O=:=C, P=:=1, 
          K=:=Q-R, Q=:=C, R=:=1, S=:=0, T>=U+1, T=:=K, U=:=1, V=:=W-X, W=:=K, 
          X=:=1, Y=:=Z, J=:=A1+B1, A1=:=K, B1=:=Y, C1=:=J, I=:=D1+E1, D1=:=C, 
          E1=:=C1, new12(A,B,V,F1,G1,H1,G,H,I1,Z,J1,K1).
new11(A,B) :- C=:=A, B=:=D, new12(A,E,C,F,G,H,I,J,K,D,L,M).

% Progs/0_src/02_REC/02.08_limit1unrolled.transformed/2.c.map.transform.pl
new22(A,B,C,D,A,B,C,E) :- F=:=0, G=<H, G=:=C, H=:=1, E=:=C.
new22(A,B,C,D,E,F,C,G) :- H=:=0, I>=J+1, I=:=C, J=:=1, K=:=L-M, L=:=C, M=:=2, 
          N=:=O, G=:=P+Q, P=:=R+S, R=:=C, S=:=T-U, T=:=C, U=:=1, Q=:=N, 
          new22(A,B,K,V,E,F,W,O).
new21(A,B) :- C=:=A, B=:=D, new22(A,E,C,F,G,H,I,D).

% Progs/0_src/02_REC/02.08_limit1unrolled/relprop
incorrect :- A=:=X, C=\=Z, new11(A,C), new21(X,Z).
