% Progs/0_src/02_REC/02.06_limit1.transformed/1.c.map.transform.pl
new12(A,B,C,D,E,C,F,E) :- G=:=0, H=<I, H=:=C, I=:=1, F=:=C.
new12(A,B,C,D,E,C,F,G) :- H=:=0, I>=J+1, I=:=C, J=:=1, K=:=L-M, L=:=C, M=:=1, 
          G=:=N, F=:=O+P, O=:=C, P=:=G, new12(A,B,K,Q,R,S,N,T).
new11(A,B) :- C=:=A, B=:=D, new12(A,E,C,F,G,H,D,I).

% Progs/0_src/02_REC/02.06_limit1.transformed/2.c.map.transform.pl
new22(A,B,C,D,E,C,F,E) :- G=:=0, H=<I, H=:=C, I=:=1, F=:=C.
new22(A,B,C,D,E,C,F,G) :- H=:=0, I>=J+1, I=:=C, J=:=1, K=:=L-M, L=:=C, M=:=2, 
          G=:=N, F=:=O+P, O=:=Q+R, Q=:=C, R=:=S-T, S=:=C, T=:=1, P=:=G, 
          new22(A,B,K,U,V,W,N,X).
new21(A,B) :- C=:=A, B=:=D, new22(A,E,C,F,G,H,D,I).

% Progs/0_src/02_REC/02.06_limit1/relprop
incorrect :- A=:=X, C=\=Z, new11(A,C), new21(X,Z).
