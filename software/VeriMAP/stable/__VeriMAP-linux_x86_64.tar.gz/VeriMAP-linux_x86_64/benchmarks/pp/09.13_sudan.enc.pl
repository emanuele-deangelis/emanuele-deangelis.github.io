% Sudan function
% F(0,X,Y)   = X+Y
% F(N,X,0)   = X        %  SUDAN version
%%%%   F(N,X,0)   = F(N-1,X+1,0)   %%%% FF version
%%%%   F(N,X,0)   = F(N,0,X)   %%%% FF2 version
%%%%   F(N,X,0)   = F(N,X-1,1)   %%%% FF3 version
%%%%   F(N,X,0)   = F(N,1,X-1)   %%%% FF4 version
% F(N,X,Y)   = F(N-1,  F(N,X,Y-1),  F(N,X,Y-1) + Y )


sudan(M1,O1,N1, A1) :- sudan1(M1,O1,N1, A1).
sudan1(M1,O1,N1, A1) :- M1=0, A1=O1+N1.
sudan1(M1,O1,N1, A1) :- M1>=1, N1=0, 
%						A1=O1.   %  SUDAN version
						X1=M1-1, O2=O1+1, sudan1(X1,O2,N1, A1).  % FF
%						sudan1(M1,N1,O1, A1).  % FF2
%						N3=1, O2=O1-1, sudan1(M1,O2,N3, A1).  % FF3
%						N3=1, O2=O1-1, sudan1(M1,N3,O2, A1).  % FF4
						
sudan1(M1,O1,N1, A1) :- M1>=1, N1>=1, X1=M1-1, Y1=N1-1, 
						sudan1(M1,O1,Y1, Z1), 
						sudan1(M1,O1,Y1, Z2),
						N2=Z2+N1, 
						sudan1(X1,Z1, N2,  A1).
   
 


sudanit1(N,X,Y, X,Y) :- N=< 0.

%sudanit1(N,X,Y, X,Y) :- N>=1, Y= 0.  %  SUDAN version
sudanit1(N,X,Y, X2,Y2) :- N>=1, Y= 0,
		 N1=N-1, X1=X+1, sudanit1(N1,X1,Y, X2,Y2).  % FF 
%		sudanit1(N,Y,X, X2,Y2).  % FF2 
%		 Y1=1, X1=X-1, sudanit1(N,X1,Y1, X2,Y2).  % FF3 
%		 Y1=1, X1=X-1, sudanit1(N,Y1,X1, X2,Y2).  % FF4 
		 
		 
sudanit1(N,X,Y, X2,Y2) :- N>=1, Y=\= 0,
          Ym1=Y-1, 
          % sudanit(N,X,Ym1,X1), 
          X1=Xa+Ya, sudanit1(N,X,Ym1,Xa,Ya),
          
          % sudanit(N,X,Ym1,Y3), 
          Y3=Xb+Yb, sudanit1(N,X,Ym1,Xb,Yb),

          Y1=Y3+Y,
          
          N1=N-1, sudanit1(N1,X1,Y1, X2,Y2).

sudanit(N,X,Y, S) :- S= X1+Y1, sudanit1(N,X,Y, X1,Y1).




incorrect :- M1>=0, N1>=0, O1>=0, M1=M2, N1=N2, O1=O2, A1=\=A2, sudan(M1,N1,O1 ,A1), sudanit(M2,N2,O2, A2).


verimap(pred_smtvars_types([incorrect,
	sudan('Int','Int','Int','Int'),
	sudan1('Int','Int','Int','Int'),
	sudanit('Int','Int','Int','Int'),
	sudanit1('Int','Int','Int','Int','Int')

])).
	
	
