% Progs/0_src/05_ARR/05.03_loopalign.transformed/1.c.map.transform.pl
new12(A,B,C,D,E,F,G,H,I,J,K,L) :- M=:=rat(1,1)+N, E=:=N, O=:=N, P=:=Q, R=:=N, 
          S=:=T, U=:=rat(-1,1)+N, F-N>=rat(0,1), read((B,A),N,T), 
          read((C,A),U,Q), write((C,A),R,S,(V,A)), write((D,A),O,P,(W,A)), 
          val(i1,M), val(c,W), val(b,V), val(n,A), val(a,B), val(b,C), 
          val(c,D), val(i1,E), val(m1,F), val(n,G), val(a,H), val(b,I), 
          val(c,J), val(i1,K), val(m1,L), new12(A,B,V,W,M,F,G,H,I,J,K,L).
new12(A,B,C,D,E,F,A,B,C,D,E,F) :- F-E=<rat(-1,1), val(m1,F), val(i1,E), 
          val(c,D), val(b,C), val(a,B), val(n,A).
new11(A,B,C,D,E) :- A=:=rat(1,1)+F, G=:=rat(1,1), val(m1,H), val(i1,I), 
          val(b,J), val(a,K), val(n,L), val(m1,F), val(i1,G), 
          new12(A,B,C,D,G,F,L,K,J,E,I,H).

verimap(pred_smtvars_types([specint,new11('Int','(Array Int Int)','(Array Int Int)','(Array Int Int)','(Array Int Int)'),new12('Int','(Array Int Int)','(Array Int Int)','(Array Int Int)','Int','Int','Int','(Array Int Int)','(Array Int Int)','(Array Int Int)','Int','Int')])).

% Progs/0_src/05_ARR/05.03_loopalign.transformed/2.c.map.transform.pl
new22(A,B,C,D,E,F,G,H,I,J,K,L) :- M=:=rat(1,1)+N, E=:=N, O=:=rat(1,1)+N, P=:=Q, 
          R=:=N, S=:=Q, F-N>=rat(1,1), read((B,A),N,Q), write((C,A),R,S,(T,A)), 
          write((D,A),O,P,(U,A)), val(i2,M), val(c,U), val(b,T), val(n,A), 
          val(a,B), val(b,C), val(c,D), val(i2,E), val(m2,F), val(n,G), 
          val(a,H), val(b,I), val(c,J), val(i2,K), val(m2,L), 
          new22(A,B,T,U,M,F,G,H,I,J,K,L).
new22(A,B,C,D,E,F,A,B,G,D,E,F) :- F=:=H, I=:=H, J=:=K, E-H>=rat(0,1), 
          read((B,A),H,K), write((C,A),I,J,(G,A)), val(m2,F), val(i2,E), 
          val(c,D), val(b,G), val(a,B), val(n,A), val(b,C).
new21(A,B,C,D,E) :- A=:=rat(1,1)+F, G=:=rat(1,1), H=:=rat(1,1), I=:=J, 
          K=:=rat(0,1), read((C,A),K,J), write((D,A),H,I,(L,A)), val(m2,M), 
          val(i2,N), val(b,O), val(a,P), val(n,Q), val(m2,F), val(i2,G), 
          val(c,L), new22(A,B,C,L,G,F,Q,P,O,E,N,M).

verimap(pred_smtvars_types([specint,new21('Int','(Array Int Int)','(Array Int Int)','(Array Int Int)','(Array Int Int)'),new22('Int','(Array Int Int)','(Array Int Int)','(Array Int Int)','Int','Int','Int','(Array Int Int)','(Array Int Int)','(Array Int Int)','Int','Int')])).

% Progs/0_src/05_ARR/05.03_loopalign/relprop
incorrect :- N>=5, CJ>=1, CJ=<N-2, CJ=:=CJ2, 
  read((C1,N),CJ,CX), read((C2,N),CJ2,CY), CX=\=CY, 
  new11(N,A,B,C,C1), new21(N,A,B,C,C2), 
  val(a,A), val(b,B), val(c,C1), val(c,C2), val(n,N).

verimap(pred_smtvars_types([incorrect])).

verimap(data_types([array-int,bool,uint,long,int])).
