% Progs/0_src/02_REC/02.02_add-horn-faulty.transformed/1.c.map.transform.pl
new12(A,B,C,D,E,F,A,B,C,D,E,G) :- H=:=0, I=:=J, I=:=D, J=:=0, G=:=E.
new12(A,B,C,D,E,F,G,H,I,D,E,J) :- K=:=0, L=\=M, L=:=D, M=:=0, N=:=O-P, O=:=D, 
          P=:=1, Q=:=R+S, R=:=E, S=:=1, J=:=T, new12(A,B,C,N,Q,U,G,H,I,V,W,T).
new11(A,B,C) :- D=:=A, E=:=B, C=:=F, new12(A,B,G,D,E,H,I,J,K,L,M,F).

% Progs/0_src/02_REC/02.02_add-horn-faulty.transformed/2.c.map.transform.pl
new22(A,B,C,D,E,F,A,B,C,D,E,G) :- H=:=0, I=:=J, I=:=D, J=:=0, G=:=E.
new22(A,B,C,D,E,F,A,B,C,D,E,G) :- H=:=0, I=\=J, I=:=D, J=:=0, K=:=L, K=:=D, 
          L=:=1, G=:=M+N, M=:=E, N=:=1.
new22(A,B,C,D,E,F,A,B,C,D,E,G) :- H=:=0, I=\=J, I=:=D, J=:=0, K=\=L, K=:=D, 
          L=:=1, M=:=N, M=:=D, N=:=2, G=:=E.
new22(A,B,C,D,E,F,G,H,I,D,E,J) :- K=:=0, L=\=M, L=:=D, M=:=0, N=\=O, N=:=D, 
          O=:=1, P=\=Q, P=:=D, Q=:=2, R=:=S-T, S=:=D, T=:=1, U=:=V+W, V=:=E, 
          W=:=1, J=:=X, new22(A,B,C,R,U,Y,G,H,I,Z,A1,X).
new21(A,B,C) :- D=:=A, E=:=B, C=:=F, new22(A,B,G,D,E,H,I,J,K,L,M,F).

% Progs/0_src/02_REC/02.02_add-horn-faulty/relprop
incorrect :- A=:=X, B=:=Y, C=\=Z, new11(A,B,C), new21(X,Y,Z).
