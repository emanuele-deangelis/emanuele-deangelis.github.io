% Progs/0_src/02_REC/02.04_inlining.transformed/1.c.map.transform.pl
new12(A,B,C,D,E,F) :- G>=H+1, G=:=C, H=:=0, I=:=J-K, J=:=C, K=:=1, L=:=M, 
          N=:=O+P, O=:=L, P=:=1, Q+1=<R, Q=:=N, R=:=0, F=:=0, 
          new12(A,B,I,D,E,M).
new12(A,B,C,D,E,F) :- G>=H+1, G=:=C, H=:=0, I=:=J-K, J=:=C, K=:=1, L=:=M, 
          F=:=N+O, N=:=L, O=:=1, P>=Q, P=:=F, Q=:=0, new12(A,B,I,D,E,M).
new12(A,B,C,A,B,D) :- E=<F, E=:=C, F=:=0, G+1=<H, G=:=C, H=:=0, D=:=0.
new12(A,B,C,A,B,C) :- D=<E, D=:=C, E=:=0, F>=G, F=:=C, G=:=0.
new11(A,B) :- C=:=A, B=:=D, new12(A,E,C,F,G,D).

% Progs/0_src/02_REC/02.04_inlining.transformed/2.c.map.transform.pl
new22(A,B,C,D,E,F) :- G>=H+1, G=:=C, H=:=1, I=:=J-K, J=:=C, K=:=2, L=:=M, 
          N=:=O+P, O=:=L, P=:=2, Q+1=<R, Q=:=N, R=:=0, F=:=0, 
          new22(A,B,I,D,E,M).
new22(A,B,C,D,E,F) :- G>=H+1, G=:=C, H=:=1, I=:=J-K, J=:=C, K=:=2, L=:=M, 
          F=:=N+O, N=:=L, O=:=2, P>=Q, P=:=F, Q=:=0, new22(A,B,I,D,E,M).
new22(A,B,C,A,B,D) :- E=<F, E=:=C, F=:=1, G+1=<H, G=:=C, H=:=0, D=:=0.
new22(A,B,C,A,B,C) :- D=<E, D=:=C, E=:=1, F>=G, F=:=C, G=:=0.
new21(A,B) :- C=:=A, B=:=D, new22(A,E,C,F,G,D).

% Progs/0_src/02_REC/02.04_inlining/relprop
incorrect :- A=:=X, C=\=Z, new11(A,C), new21(X,Z).
