
% computes the number of moves for solving the Hanoi Towers puzzle
hanoi(N,M) :- N=:=0, M=:=0.
hanoi(N,M) :- N=:=1, M=:=1.
hanoi(N,M) :- N>=2, N1=:=N-1, N2=:=N-1, hanoi(N1,M1), hanoi(N2,M2), M=:=M1+M2+1
		% FUNCTIONALITY
		, M1=:=M2. 



hanoiit(N,M) :- N=:=0, M=:=0.
hanoiit(N,M) :- N=:=1, M=:=1.
hanoiit(N,M) :- N>=2,  M=:=2*M1+1, N1=:=N-1, hanoiit(N1,M1).



%incorrect2 :-  N=:=N1, hanoi(N1,M1),  hanoi(N,M),  M=\=M1.
incorrect :-  N=:=N1, hanoiit(N1,M1),  hanoi(N,M),  M=\=M1.


%incorrect :- incorrect2.

verimap(pred_smtvars_types([incorrect
			,incorrect2
			,hanoi('Int','Int')
			,hanoiit('Int','Int')
			])).
			
