% Progs/0_src/05_ARR/05.02_findmax.transformed/1.c.map.transform.pl
new12(A,B,C,D,E,F,G,H,I,J) :- K=:=rat(1,1)+L, M=:=L, D=:=L, E=:=N, 
          O-P=<rat(0,1), A-L>=rat(1,1), read((C,A),L,P), read((C,A),N,O), 
          val(max,M), val(i1,K), val(n,A), val(result1,B), val(a,C), val(i1,D), 
          val(max,E), val(n,F), val(result1,G), val(a,H), val(i1,I), 
          val(max,J), new12(A,B,C,K,M,F,G,H,I,J).
new12(A,B,C,D,E,F,G,H,I,J) :- K=:=rat(1,1)+L, E=:=M, D=:=L, A-L>=rat(1,1), 
          M-L>=rat(1,1), N-O>=rat(1,1), read((C,A),L,O), read((C,A),M,N), 
          val(i1,K), val(n,A), val(result1,B), val(a,C), val(i1,D), val(max,E), 
          val(n,F), val(result1,G), val(a,H), val(i1,I), val(max,J), 
          new12(A,B,C,K,E,F,G,H,I,J).
new12(A,B,C,D,E,F,G,H,I,J) :- K=:=rat(1,1)+L, E=:=M, D=:=L, M-L=<rat(-1,1), 
          A-L>=rat(1,1), N-O>=rat(1,1), read((C,A),L,O), read((C,A),M,N), 
          val(i1,K), val(n,A), val(result1,B), val(a,C), val(i1,D), val(max,E), 
          val(n,F), val(result1,G), val(a,H), val(i1,I), val(max,J), 
          new12(A,B,C,K,E,F,G,H,I,J).
new12(A,B,C,D,E,A,F,C,D,E) :- E=:=G, F=:=H, D-A>=rat(0,1), read((C,A),G,H), 
          val(max,E), val(i1,D), val(a,C), val(result1,F), val(n,A), 
          val(result1,B).
new11(A,B,C) :- D=:=rat(1,1), E=:=rat(0,1), val(max,F), val(i1,G), val(a,H), 
          val(n,I), val(max,E), val(i1,D), val(result1,J), 
          new12(B,J,A,D,E,I,C,H,G,F).

verimap(pred_smtvars_types([specint,new11('(Array Int Int)','Int','Int'),new12('Int','Int','(Array Int Int)','Int','Int','Int','Int','(Array Int Int)','Int','Int')])).

% Progs/0_src/05_ARR/05.02_findmax.transformed/2.c.map.transform.pl
new22(A,B,C,D,E,F,G,H,I,J) :- K=:=rat(1,1)+L, M=:=N, D=:=L, E-N=<rat(0,1), 
          A-L>=rat(1,1), read((C,A),L,N), val(maxv,M), val(i2,K), val(n,A), 
          val(result2,B), val(a,C), val(i2,D), val(maxv,E), val(n,F), 
          val(result2,G), val(a,H), val(i2,I), val(maxv,J), 
          new22(A,B,C,K,M,F,G,H,I,J).
new22(A,B,C,D,E,F,G,H,I,J) :- K=:=rat(1,1)+L, D=:=L, A-L>=rat(1,1), 
          E-M>=rat(1,1), read((C,A),L,M), val(i2,K), val(n,A), val(result2,B), 
          val(a,C), val(i2,D), val(maxv,E), val(n,F), val(result2,G), val(a,H), 
          val(i2,I), val(maxv,J), new22(A,B,C,K,E,F,G,H,I,J).
new22(A,B,C,D,E,A,F,C,D,E) :- E=:=F, D-A>=rat(0,1), val(maxv,E), val(i2,D), 
          val(a,C), val(result2,F), val(n,A), val(result2,B).
new21(A,B,C) :- D=:=rat(1,1), E=:=F, G=:=rat(0,1), read((A,B),G,F), 
          val(maxv,H), val(i2,I), val(a,J), val(n,K), val(maxv,E), val(i2,D), 
          val(result2,L), new22(B,L,A,D,E,K,C,J,I,H).

verimap(pred_smtvars_types([specint,new21('(Array Int Int)','Int','Int'),new22('Int','Int','(Array Int Int)','Int','Int','Int','Int','(Array Int Int)','Int','Int')])).

verimap(data_types([array-int,bool,uint,long,int])).

% Progs/0_src/05_ARR/05.02_findmax/relprop
incorrect :- B>=1, C1=\=C2, new11(A,B,C1), new21(A,B,C2), 
  val(a,A), val(n,B), val(result1,C1), val(result2,C2).


verimap(pred_smtvars_types([incorrect])).
