% Progs/NONINT/limit2.transformed/1.c.map.transform.pl
new14(A,B,C,D,E,A,B,C,D,F) :- G=:=0, H=<I, H=:=D, I=:=1, F=:=D.
new14(A,B,C,D,E,F,G,H,D,I) :- J=:=0, K>=L+1, K=:=D, L=:=1, M=:=N-O, N=:=D, 
          O=:=1, P=:=Q, I=:=R+S, R=:=D, S=:=P, new14(A,B,C,M,T,F,G,H,U,Q).
new13(A,B,C,D,E,A,B,C,D,F) :- G=:=0, H=<I, H=:=D, I=:=0, F=:=D.
new13(A,B,C,D,E,F,G,H,D,I) :- J=:=0, K>=L+1, K=:=D, L=:=0, M=:=N-O, N=:=D, 
          O=:=1, P=:=Q, I=:=R+S, R=:=D, S=:=P, new13(A,B,C,M,T,F,G,H,U,Q).
new12(A,B,C,D,E,F,G,H,I,J,K,D,E,L,M,N) :- O=:=0, P=:=D, M=:=Q, R=:=S+T, S=:=M, 
          T=:=E, U=:=D, N=:=V, L=:=W-X, W=:=R, X=:=N, 
          new13(A,B,C,P,Y,Z,A1,B1,C1,Q), new14(Z,A1,B1,U,D1,I,J,K,E1,V).
new11(A,B,C) :- D=:=A, E=:=B, C=:=F, new12(A,B,G,D,E,H,I,J,K,L,M,N,O,F,P,Q).
specint :- new11(A,B,C).

verimap(pred_smtvars_types([specint,new11('Int','Int','Int'),new12('Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int'),new13('Int','Int','Int','Int','Int','Int','Int','Int','Int','Int'),new14('Int','Int','Int','Int','Int','Int','Int','Int','Int','Int')])).

% Progs/NONINT/limit2.transformed/2.c.map.transform.pl
new24(A,B,C,D,E,A,B,C,D,F) :- G=:=0, H=<I, H=:=D, I=:=1, F=:=D.
new24(A,B,C,D,E,F,G,H,D,I) :- J=:=0, K>=L+1, K=:=D, L=:=1, M=:=N-O, N=:=D, 
          O=:=1, P=:=Q, I=:=R+S, R=:=D, S=:=P, new24(A,B,C,M,T,F,G,H,U,Q).
new23(A,B,C,D,E,A,B,C,D,F) :- G=:=0, H=<I, H=:=D, I=:=0, F=:=D.
new23(A,B,C,D,E,F,G,H,D,I) :- J=:=0, K>=L+1, K=:=D, L=:=0, M=:=N-O, N=:=D, 
          O=:=1, P=:=Q, I=:=R+S, R=:=D, S=:=P, new23(A,B,C,M,T,F,G,H,U,Q).
new22(A,B,C,D,E,F,G,H,I,J,K,D,E,L,M,N) :- O=:=0, P=:=D, M=:=Q, R=:=S+T, S=:=M, 
          T=:=E, U=:=D, N=:=V, L=:=W-X, W=:=R, X=:=N, 
          new23(A,B,C,P,Y,Z,A1,B1,C1,Q), new24(Z,A1,B1,U,D1,I,J,K,E1,V).
new21(A,B,C) :- D=:=A, E=:=B, C=:=F, new22(A,B,G,D,E,H,I,J,K,L,M,N,O,F,P,Q).
specint :- new21(A,B,C).

verimap(pred_smtvars_types([incorrect,new21('Int','Int','Int'),new22('Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int','Int'),new23('Int','Int','Int','Int','Int','Int','Int','Int','Int','Int'),new24('Int','Int','Int','Int','Int','Int','Int','Int','Int','Int')])).

% Progs/NONINT/limit2/relprop
incorrect :- B=:=Y,  C=\=Z, new11(A,B,C), new21(X,Y,Z).
