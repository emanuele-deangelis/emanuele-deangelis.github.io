% Progs/NONINT/nonint2.transformed/1.c.map.transform.pl
new12(A,B,C,A,B,C) :- D=<E, D=:=B, E=:=0.
new12(A,B,C,D,E,F) :- G>=H+1, G=:=B, H=:=0, I=:=J-K, J=:=B, K=:=1, L=:=I, 
          new12(L,I,C,D,E,F).
new11(A,B,C,D) :- new12(A,B,C,D,E,F).
specint :- new11(A,B,C,D).

verimap(pred_smtvars_types([specint,new11('Int','Int','Int','Int'),new12('Int','Int','Int','Int','Int','Int')])).

% Progs/NONINT/nonint2.transformed/2.c.map.transform.pl
new22(A,B,C,A,B,C) :- D=<E, D=:=B, E=:=0.
new22(A,B,C,D,E,F) :- G>=H+1, G=:=B, H=:=0, I=:=J-K, J=:=B, K=:=1, L=:=I, 
          new22(L,I,C,D,E,F).
new21(A,B,C,D) :- new22(A,B,C,D,E,F).
specint :- new21(A,B,C,D).

verimap(pred_smtvars_types([incorrect,new21('Int','Int','Int','Int'),new22('Int','Int','Int','Int','Int','Int')])).

% Progs/NONINT/nonint2/relprop
incorrect :- L=:=L1,
			new11(L,H,J,OutL),
			new21(L1,H1,J1,OutL1),
			OutL =\= OutL1.