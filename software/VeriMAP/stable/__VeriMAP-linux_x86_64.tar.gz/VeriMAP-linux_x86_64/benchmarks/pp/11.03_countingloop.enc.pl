% Progs/compopt/countingloop.transformed/1.c.map.transform.pl
new13(A,B,C,D,E,A,B,C,D,E) :- F>=G, F=:=A, G=:=B.
new13(A,B,C,D,E,F,G,H,I,J) :- K+1=<L, K=:=A, L=:=B, M=:=N+O, N=:=C, O=:=1, 
          P=:=Q+R, Q=:=A, R=:=1, new13(P,B,M,D,E,F,G,H,I,J).
new12(A,B,C,D,E,F,G,H,I,J) :- K=:=10, L=:=D, M=:=E, new13(K,L,M,D,E,F,G,H,I,J).
new11(A,B,C,D,E) :- F=:=B, G=:=C, new12(A,B,C,F,G,D,H,E,I,J).

verimap(pred_smtvars_types([specint,new11('Int','Int','Int','Int','Int'),new12('Int','Int','Int','Int','Int','Int','Int','Int','Int','Int'),new13('Int','Int','Int','Int','Int','Int','Int','Int','Int','Int')])).

% Progs/compopt/countingloop.transformed/2.c.map.transform.pl
new23(A,B,C,D,E,A,B,F,D,E) :- G>=H, G=:=A, H=:=B, F=:=I-J, I=:=K+L, K=:=C, 
          L=:=B, J=:=10.
new23(A,B,C,D,E,F,G,H,I,J) :- K+1=<L, K=:=A, L=:=B, M=:=N+O, N=:=A, O=:=1, 
          new23(M,B,C,D,E,F,G,H,I,J).
new22(A,B,C,D,E,F,G,H,D,E) :- F=:=10, G=:=D, H=:=E, I>=J, I=:=F, J=:=G.
new22(A,B,C,D,E,F,G,H,I,J) :- K=:=10, L=:=D, M=:=E, N+1=<O, N=:=K, O=:=L, 
          new23(K,L,M,D,E,F,G,H,I,J).
new21(A,B,C,D,E) :- F=:=B, G=:=C, new22(A,B,C,F,G,D,H,E,I,J).

verimap(pred_smtvars_types([incorrect,new21('Int','Int','Int','Int','Int'),new22('Int','Int','Int','Int','Int','Int','Int','Int','Int','Int'),new23('Int','Int','Int','Int','Int','Int','Int','Int','Int','Int')])).

% Progs/compopt/countingloop/relprop
incorrect :- D=\=D1, new11(A,B,C,D,E), new21(A,B,C,D1,E1).
