% Progs/0_src/02_REC/02.13_triangular.transformed/1.c.map.transform.pl
new13(A,B,C,D,A,B,C,E) :- F=:=0, G=<H, G=:=C, H=:=0, E=:=0.
new13(A,B,C,D,E,F,C,G) :- H=:=0, I>=J+1, I=:=C, J=:=0, K=:=L-M, L=:=C, M=:=1, 
          N=:=O, G=:=P+Q, P=:=C, Q=:=N, new13(A,B,K,R,E,F,S,O).
new12(A,B,C,D,E,F,C,G) :- H=:=C, G=:=I, new13(A,B,H,J,E,F,K,I).
new11(A,B) :- C=:=A, B=:=D, new12(A,E,C,F,G,H,I,D).

% Progs/0_src/02_REC/02.13_triangular.transformed/2.c.map.transform.pl
new23(A,B,C,D,E,A,B,C,D,F) :- G=:=0, H=<I, H=:=C, I=:=0, F=:=D.
new23(A,B,C,D,E,F,G,C,D,H) :- I=:=0, J>=K+1, J=:=C, K=:=0, L=:=M-N, M=:=C, 
          N=:=1, O=:=P+Q, P=:=C, Q=:=D, H=:=R, new23(A,B,L,O,S,F,G,T,U,R).
new22(A,B,C,D,E,F,C,G) :- H=:=C, I=:=0, G=:=J, new23(A,B,H,I,K,E,F,L,M,J).
new21(A,B) :- C=:=A, B=:=D, new22(A,E,C,F,G,H,I,D).

% Progs/0_src/02_REC/02.13_triangular/relprop
incorrect :- A=:=X, C=\=Z, new11(A,C), new21(X,Z).
