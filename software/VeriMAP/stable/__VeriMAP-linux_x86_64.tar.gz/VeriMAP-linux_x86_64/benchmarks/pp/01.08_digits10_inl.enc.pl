% Progs/0_src/01_ITE/01.08_digits10_inl.transformed/1.c.map.transform.pl
new13(A,B,C,D,E,F,G,H) :- I>=J+1, I=:=C, J=:=0, K=:=L+M, L=:=D, M=:=1, 
          N=:=O*P+Q, Q>=0, Q+1=<P, N=:=C, P=:=10, R>=S+1, R=:=O, S=:=0, 
          T=:=U+V, U=:=K, V=:=1, W=:=X*Y+Z, Z>=0, Z+1=<Y, W=:=O, Y=:=10, 
          A1>=B1+1, A1=:=X, B1=:=0, C1=:=D1+E1, D1=:=T, E1=:=1, F1=:=G1*H1+I1, 
          I1>=0, I1+1=<H1, F1=:=X, H1=:=10, J1>=K1+1, J1=:=G1, K1=:=0, 
          L1=:=M1+N1, M1=:=C1, N1=:=1, O1=:=P1*Q1+R1, R1>=0, R1+1=<Q1, O1=:=G1, 
          Q1=:=10, new13(A,B,P1,L1,E,F,G,H).
new13(A,B,C,D,E,F,G,H) :- I>=J+1, I=:=C, J=:=0, K=:=L+M, L=:=D, M=:=1, 
          N=:=O*P+Q, Q>=0, Q+1=<P, N=:=C, P=:=10, R>=S+1, R=:=O, S=:=0, 
          T=:=U+V, U=:=K, V=:=1, W=:=X*Y+Z, Z>=0, Z+1=<Y, W=:=O, Y=:=10, 
          A1>=B1+1, A1=:=X, B1=:=0, C1=:=D1+E1, D1=:=T, E1=:=1, F1=:=G1*H1+I1, 
          I1>=0, I1+1=<H1, F1=:=X, H1=:=10, J1=<K1, J1=:=G1, K1=:=0, 
          new13(A,B,G1,C1,E,F,G,H).
new13(A,B,C,D,E,F,G,H) :- I>=J+1, I=:=C, J=:=0, K=:=L+M, L=:=D, M=:=1, 
          N=:=O*P+Q, Q>=0, Q+1=<P, N=:=C, P=:=10, R>=S+1, R=:=O, S=:=0, 
          T=:=U+V, U=:=K, V=:=1, W=:=X*Y+Z, Z>=0, Z+1=<Y, W=:=O, Y=:=10, 
          A1=<B1, A1=:=X, B1=:=0, new13(A,B,X,T,E,F,G,H).
new13(A,B,C,D,E,F,G,H) :- I>=J+1, I=:=C, J=:=0, K=:=L+M, L=:=D, M=:=1, 
          N=:=O*P+Q, Q>=0, Q+1=<P, N=:=C, P=:=10, R=<S, R=:=O, S=:=0, 
          new13(A,B,O,K,E,F,G,H).
new13(A,B,C,D,A,B,C,D) :- E=<F, E=:=C, F=:=0.
new12(A,B,C,D,E,F,G,H) :- I=:=1, J=:=K*L+M, M>=0, M+1=<L, J=:=C, L=:=10, 
          new13(A,B,K,I,E,F,G,H).
new11(A,B) :- C=:=A, B=:=D, new12(A,E,C,F,G,H,I,D).

% Progs/0_src/01_ITE/01.08_digits10_inl.transformed/2.c.map.transform.pl
new23(A,B,C,D,E,F,G,H,I,J,K,L) :- M=\=N, M=:=E, N=:=0, O+1=<P, O=:=C, P=:=10, 
          Q=:=D, R=:=0, new23(A,B,C,D,R,Q,G,H,I,J,K,L).
new23(A,B,C,D,E,F,G,H,I,J,K,L) :- M=\=N, M=:=E, N=:=0, O>=P, O=:=C, P=:=10, 
          Q+1=<R, Q=:=C, R=:=100, S=:=T+U, T=:=D, U=:=1, V=:=0, 
          new23(A,B,C,D,V,S,G,H,I,J,K,L).
new23(A,B,C,D,E,F,G,H,I,J,K,L) :- M=\=N, M=:=E, N=:=0, O>=P, O=:=C, P=:=10, 
          Q>=R, Q=:=C, R=:=100, S+1=<T, S=:=C, T=:=1000, U=:=V+W, V=:=D, W=:=2, 
          X=:=0, new23(A,B,C,D,X,U,G,H,I,J,K,L).
new23(A,B,C,D,E,F,G,H,I,J,K,L) :- M=\=N, M=:=E, N=:=0, O>=P, O=:=C, P=:=10, 
          Q>=R, Q=:=C, R=:=100, S>=T, S=:=C, T=:=1000, U+1=<V, U=:=C, 
          V=:=10000, W=:=X+Y, X=:=D, Y=:=3, Z=:=0, 
          new23(A,B,C,D,Z,W,G,H,I,J,K,L).
new23(A,B,C,D,E,F,G,H,I,J,K,L) :- M=\=N, M=:=E, N=:=0, O>=P, O=:=C, P=:=10, 
          Q>=R, Q=:=C, R=:=100, S>=T, S=:=C, T=:=1000, U>=V, U=:=C, V=:=10000, 
          W=:=X*Y+Z, Z>=0, Z+1=<Y, W=:=C, Y=:=10000, A1=:=B1+C1, B1=:=D, 
          C1=:=4, new23(A,B,X,A1,E,F,G,H,I,J,K,L).
new23(A,B,C,D,E,F,A,B,C,D,E,F) :- G=:=H, G=:=E, H=:=0.
new22(A,B,C,D,E,F,G,H,I,J,K,L) :- M=:=1, N=:=1, O=:= -1, 
          new23(A,B,C,M,N,O,G,H,I,J,K,L).
new21(A,B) :- C=:=A, B=:=D, new22(A,E,C,F,G,H,I,J,K,L,M,D).

% Progs/0_src/01_ITE/01.08_digits10_inl/relprop
incorrect :- A=:=X, C=\=Z, new11(A,C), new21(X,Z).
