# 1 "SVCOMP13-loops-sum04_unsafe.map.tmp.c"
# 1 "<command-line>"
# 1 "SVCOMP13-loops-sum04_unsafe.map.tmp.c"
# 1 "MAP/UNSAFE-exbench/SVCOMP13-loops-sum04unsafe.tmp.c"
# 1 "<command-line>"
# 1 "MAP/UNSAFE-exbench/SVCOMP13-loops-sum04unsafe.tmp.c"
# 18 "MAP/UNSAFE-exbench/SVCOMP13-loops-sum04unsafe.tmp.c"
void commentedOutVERIFIERassert(int cond) {
  if (!(cond)) {
    ERROR: _TRACER_abort(1); goto ERROR;
  }
  return;
}


int main() {
  int i, sn=0;
  for(i=1; i<=8; i++) {
    if (i<4)
    sn = sn + (2);
  }
  _TRACER_abort(! ( sn==8*(2) || sn == 0 ));
}
