# 1 "SVCOMP13-loops-while_infinite_loop_4_unsafe.map.tmp.c"
# 1 "<command-line>"
# 1 "SVCOMP13-loops-while_infinite_loop_4_unsafe.map.tmp.c"
# 1 "MAP/UNSAFE-exbench/SVCOMP13-loops-whileinfiniteloop4unsafe.tmp.c"
# 1 "<command-line>"
# 1 "MAP/UNSAFE-exbench/SVCOMP13-loops-whileinfiniteloop4unsafe.tmp.c"
# 18 "MAP/UNSAFE-exbench/SVCOMP13-loops-whileinfiniteloop4unsafe.tmp.c"
void commentedOutVERIFIERassert(int cond) {
  if (!(cond)) {
    ERROR: _TRACER_abort(1); goto ERROR;
  }
  return;
}

int x=0;

void eval(void)
{
  while (1) {
      x=1;
      break;
  }
  return;
}


int main() {

  while(1)
  {
    eval();
    _TRACER_abort(! ( x==0 ));
  }

  _TRACER_abort(! ( x==0 ));

  return 0;
}
