# 1 "SVCOMP13-systemc-transmitter.02_unsafeil.map.c.tmp.c"
# 1 "<command-line>"
# 1 "SVCOMP13-systemc-transmitter.02_unsafeil.map.c.tmp.c"
# 1 "MAP/UNSAFE-exbench/SVCOMP13-systemc-transmitter.02unsafeil.c.tmp.c"
# 1 "<command-line>"
# 1 "MAP/UNSAFE-exbench/SVCOMP13-systemc-transmitter.02unsafeil.c.tmp.c"
# 18 "MAP/UNSAFE-exbench/SVCOMP13-systemc-transmitter.02unsafeil.c.tmp.c"
extern int VERIFIERnondetint();



void error(void)
{

  {
  ERROR: _TRACER_abort(1); ;
  goto ERROR;
  return;
}
}
int mpc = 0;
int t1pc = 0;
int t2pc = 0;
int mst ;
int t1st ;
int t2st ;
int mi ;
int t1i ;
int t2i ;
int ME = 2;
int T1E = 2;
int T2E = 2;
int E1 = 2;
int E2 = 2;
int ismastertriggered(void) ;
int istransmit1triggered(void) ;
int istransmit2triggered(void) ;
void immediatenotify(void) ;
void master(void)
{

  {
  if (mpc == 0) {
    goto MENTRY;
  } else {
    if (mpc == 1) {
      goto MWAIT;
    } else {

    }
  }
  MENTRY: ;
  {
  while (1) {
    while0continue: ;
    {
    E1 = 1;
    immediatenotify();
    E1 = 2;
    }
    {
    while (1) {
      while1continue: ;
      mpc = 1;
      mst = 2;

      goto returnlabel;
      MWAIT: ;
    }
    while1break: ;
    }
  }
  while0break: ;
  }

  returnlabel:
  return;
}
}
void transmit1(void)
{

  {
  if (t1pc == 0) {
    goto T1ENTRY;
  } else {
    if (t1pc == 1) {
      goto T1WAIT;
    } else {

    }
  }
  T1ENTRY: ;
  {
  while (1) {
    while2continue: ;
    t1pc = 1;
    t1st = 2;

    goto returnlabel;
    T1WAIT:
    {
    E2 = 1;
    immediatenotify();
    E2 = 2;
    }
  }
  while2break: ;
  }

  returnlabel:
  return;
}
}
void transmit2(void)
{

  {
  if (t2pc == 0) {
    goto T2ENTRY;
  } else {
    if (t2pc == 1) {
      goto T2WAIT;
    } else {

    }
  }
  T2ENTRY: ;
  {
  while (1) {
    while3continue: ;
    t2pc = 1;
    t2st = 2;

    goto returnlabel;
    T2WAIT:
    {
    error();
    }
  }
  while3break: ;
  }

  returnlabel:
  return;
}
}
int ismastertriggered(void)
{ int retres1 ;

  {
  if (mpc == 1) {
    if (ME == 1) {
      retres1 = 1;
      goto returnlabel;
    } else {

    }
  } else {

  }
  retres1 = 0;
  returnlabel:
  return (retres1);
}
}
int istransmit1triggered(void)
{ int retres1 ;

  {
  if (t1pc == 1) {
    if (E1 == 1) {
      retres1 = 1;
      goto returnlabel;
    } else {

    }
  } else {

  }
  retres1 = 0;
  returnlabel:
  return (retres1);
}
}
int istransmit2triggered(void)
{ int retres1 ;

  {
  if (t2pc == 1) {
    if (E2 == 1) {
      retres1 = 1;
      goto returnlabel;
    } else {

    }
  } else {

  }
  retres1 = 0;
  returnlabel:
  return (retres1);
}
}
void updatechannels(void)
{

  {

  return;
}
}
void initthreads(void)
{

  {
  if (mi == 1) {
    mst = 0;
  } else {
    mst = 2;
  }
  if (t1i == 1) {
    t1st = 0;
  } else {
    t1st = 2;
  }
  if (t2i == 1) {
    t2st = 0;
  } else {
    t2st = 2;
  }

  return;
}
}
int existsrunnablethread(void)
{ int retres1 ;

  {
  if (mst == 0) {
    retres1 = 1;
    goto returnlabel;
  } else {
    if (t1st == 0) {
      retres1 = 1;
      goto returnlabel;
    } else {
      if (t2st == 0) {
        retres1 = 1;
        goto returnlabel;
      } else {

      }
    }
  }
  retres1 = 0;
  returnlabel:
  return (retres1);
}
}
void eval(void)
{
  int tmp ;

  {
  {
  while (1) {
    while4continue: ;
    {
    tmp = existsrunnablethread();
    }
    if (tmp) {

    } else {
      goto while4break;
    }
    if (mst == 0) {
      int tmpndt1;
      tmpndt1 = VERIFIERnondetint();
      if (tmpndt1) {
        {
        mst = 1;
        master();
        }
      } else {

      }
    } else {

    }
    if (t1st == 0) {
      int tmpndt2;
      tmpndt2 = VERIFIERnondetint();
      if (tmpndt2) {
        {
        t1st = 1;
        transmit1();
        }
      } else {

      }
    } else {

    }
    if (t2st == 0) {
      int tmpndt3;
      tmpndt3 = VERIFIERnondetint();
      if (tmpndt3) {
        {
        t2st = 1;
        transmit2();
        }
      } else {

      }
    } else {

    }
  }
  while4break: ;
  }

  return;
}
}
void firedeltaevents(void)
{

  {
  if (ME == 0) {
    ME = 1;
  } else {

  }
  if (T1E == 0) {
    T1E = 1;
  } else {

  }
  if (T2E == 0) {
    T2E = 1;
  } else {

  }
  if (E1 == 0) {
    E1 = 1;
  } else {

  }
  if (E2 == 0) {
    E2 = 1;
  } else {

  }

  return;
}
}
void resetdeltaevents(void)
{

  {
  if (ME == 1) {
    ME = 2;
  } else {

  }
  if (T1E == 1) {
    T1E = 2;
  } else {

  }
  if (T2E == 1) {
    T2E = 2;
  } else {

  }
  if (E1 == 1) {
    E1 = 2;
  } else {

  }
  if (E2 == 1) {
    E2 = 2;
  } else {

  }

  return;
}
}
void activatethreads(void)
{ int tmp ;
  int tmp0 ;
  int tmp1 ;

  {
  {
  tmp = ismastertriggered();
  }
  if (tmp) {
    mst = 0;
  } else {

  }
  {
  tmp0 = istransmit1triggered();
  }
  if (tmp0) {
    t1st = 0;
  } else {

  }
  {
  tmp1 = istransmit2triggered();
  }
  if (tmp1) {
    t2st = 0;
  } else {

  }

  return;
}
}
void immediatenotify(void)
{

  {
  {
  activatethreads();
  }

  return;
}
}
void firetimeevents(void)
{

  {
  ME = 1;

  return;
}
}
void resettimeevents(void)
{

  {
  if (ME == 1) {
    ME = 2;
  } else {

  }
  if (T1E == 1) {
    T1E = 2;
  } else {

  }
  if (T2E == 1) {
    T2E = 2;
  } else {

  }
  if (E1 == 1) {
    E1 = 2;
  } else {

  }
  if (E2 == 1) {
    E2 = 2;
  } else {

  }

  return;
}
}
void initmodel(void)
{

  {
  mi = 1;
  t1i = 1;
  t2i = 1;

  return;
}
}
int stopsimulation(void)
{ int tmp ;
  int retres2 ;

  {
  {
  tmp = existsrunnablethread();
  }
  if (tmp) {
    retres2 = 0;
    goto returnlabel;
  } else {

  }
  retres2 = 1;
  returnlabel:
  return (retres2);
}
}
void startsimulation(void)
{ int kernelst ;
  int tmp ;
  int tmp0 ;

  {
  {
  kernelst = 0;
  updatechannels();
  initthreads();
  firedeltaevents();
  activatethreads();
  resetdeltaevents();
  }
  {
  while (1) {
    while5continue: ;
    {
    kernelst = 1;
    eval();
    }
    {
    kernelst = 2;
    updatechannels();
    }
    {
    kernelst = 3;
    firedeltaevents();
    activatethreads();
    resetdeltaevents();
    }
    {
    tmp = existsrunnablethread();
    }
    if (tmp == 0) {
      {
      kernelst = 4;
      firetimeevents();
      activatethreads();
      resettimeevents();
      }
    } else {

    }
    {
    tmp0 = stopsimulation();
    }
    if (tmp0) {
      goto while5break;
    } else {

    }
  }
  while5break: ;
  }

  return;
}
}
int main(void)
{ int retres1 ;

  {
  {
  initmodel();
  startsimulation();
  }
  retres1 = 0;
  return (retres1);
}
}
