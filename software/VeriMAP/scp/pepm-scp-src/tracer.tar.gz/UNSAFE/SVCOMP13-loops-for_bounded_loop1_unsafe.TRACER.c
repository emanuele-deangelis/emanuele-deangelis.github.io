# 1 "SVCOMP13-loops-for_bounded_loop1_unsafe.map.tmp.c"
# 1 "<command-line>"
# 1 "SVCOMP13-loops-for_bounded_loop1_unsafe.map.tmp.c"
# 1 "MAP/UNSAFE-exbench/SVCOMP13-loops-forboundedloop1unsafe.tmp.c"
# 1 "<command-line>"
# 1 "MAP/UNSAFE-exbench/SVCOMP13-loops-forboundedloop1unsafe.tmp.c"
# 18 "MAP/UNSAFE-exbench/SVCOMP13-loops-forboundedloop1unsafe.tmp.c"
extern void commentedOutVERIFIERassume(int);
void commentedOutVERIFIERassert(int cond) {
  if (!(cond)) {
    ERROR: _TRACER_abort(1); goto ERROR;
  }
  return;
}

int VERIFIERnondetint();

int main() {
  int i=0, x=0, y=0;
  int n=VERIFIERnondetint();
  _TRACER_assume( n>0 );
  for(i=0; i<n; i++)
  {
    x = x-y;
    _TRACER_abort(! ( x==0 ));
    y = VERIFIERnondetint();
    _TRACER_assume( y!=0 );
    x = x+y;
    _TRACER_abort(! ( x!=0 ));
  }
  _TRACER_abort(! ( x==0 ));
}
