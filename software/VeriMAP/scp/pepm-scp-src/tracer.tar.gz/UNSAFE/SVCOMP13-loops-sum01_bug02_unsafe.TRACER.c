# 1 "SVCOMP13-loops-sum01_bug02_unsafe.map.tmp.c"
# 1 "<command-line>"
# 1 "SVCOMP13-loops-sum01_bug02_unsafe.map.tmp.c"
# 1 "MAP/UNSAFE-exbench/SVCOMP13-loops-sum01bug02unsafe.tmp.c"
# 1 "<command-line>"
# 1 "MAP/UNSAFE-exbench/SVCOMP13-loops-sum01bug02unsafe.tmp.c"
# 18 "MAP/UNSAFE-exbench/SVCOMP13-loops-sum01bug02unsafe.tmp.c"
void commentedOutVERIFIERassert(int cond) {
  if (!(cond)) {
    ERROR: _TRACER_abort(1); goto ERROR;
  }
  return;
}

extern unsigned int VERIFIERnondetuint();
int main() {
  int i, j=10, n=VERIFIERnondetuint(), sn=0;
  for(i=1; i<=n; i++) {
    if (i<j)
    sn = sn + (2);
    j--;
  }
  _TRACER_abort(! ( sn==n*(2) || sn == 0 ));
}
