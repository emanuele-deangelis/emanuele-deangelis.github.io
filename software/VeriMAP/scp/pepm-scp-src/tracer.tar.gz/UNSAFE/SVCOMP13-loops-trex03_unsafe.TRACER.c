# 1 "SVCOMP13-loops-trex03_unsafe.map.tmp.c"
# 1 "<command-line>"
# 1 "SVCOMP13-loops-trex03_unsafe.map.tmp.c"
# 1 "MAP/UNSAFE-exbench/SVCOMP13-loops-trex03unsafe.tmp.c"
# 1 "<command-line>"
# 1 "MAP/UNSAFE-exbench/SVCOMP13-loops-trex03unsafe.tmp.c"
# 18 "MAP/UNSAFE-exbench/SVCOMP13-loops-trex03unsafe.tmp.c"
void commentedOutVERIFIERassert(int cond) {
  if (!(cond)) {
    ERROR: _TRACER_abort(1); goto ERROR;
  }
  return;
}


extern unsigned int VERIFIERnondetuint();
extern _Bool VERIFIERnondetbool();

int main()
{
  unsigned int x1=VERIFIERnondetuint(), x2=VERIFIERnondetuint(), x3=VERIFIERnondetuint();
  unsigned int d1=1, d2=1, d3=1;
  int c1=VERIFIERnondetbool(), c2=VERIFIERnondetbool();

  while(x1>0 && x2>0 && x3>0)
  {
    if (c1) x1=x1-d1;
    else if (c2) x2=x2-d2;
    else x3=x3-d3;
    c1=VERIFIERnondetbool();
    c2=VERIFIERnondetbool();
  }

  _TRACER_abort(! ( x1==0 && x2==0 && x3==0 ));
  return 0;
}
