# 1 "SVCOMP13-loops-count_up_down_unsafe.map.tmp.c"
# 1 "<command-line>"
# 1 "SVCOMP13-loops-count_up_down_unsafe.map.tmp.c"
# 1 "MAP/UNSAFE-exbench/SVCOMP13-loops-countupdownunsafe.tmp.c"
# 1 "<command-line>"
# 1 "MAP/UNSAFE-exbench/SVCOMP13-loops-countupdownunsafe.tmp.c"
# 18 "MAP/UNSAFE-exbench/SVCOMP13-loops-countupdownunsafe.tmp.c"
void commentedOutVERIFIERassert(int cond) {
  if (!(cond)) {
    ERROR: _TRACER_abort(1); goto ERROR;
  }
  return;
}
unsigned int VERIFIERnondetuint();

int main()
{
  unsigned int n = VERIFIERnondetuint();
  unsigned int x=n, y=0;
  while(x>0)
  {
    x--;
    y++;
  }
  _TRACER_abort(! ( y!=n ));
}
