# 1 "SVCOMP13-loops-kundu_unsafe.map.tmp.c"
# 1 "<command-line>"
# 1 "SVCOMP13-loops-kundu_unsafe.map.tmp.c"
# 1 "MAP/UNSAFE-exbench/SVCOMP13-loops-kunduunsafe.tmp.c"
# 1 "<command-line>"
# 1 "MAP/UNSAFE-exbench/SVCOMP13-loops-kunduunsafe.tmp.c"
# 18 "MAP/UNSAFE-exbench/SVCOMP13-loops-kunduunsafe.tmp.c"
extern int VERIFIERnondetint();

void error(void)
{

  {
  goto ERROR;
  ERROR: _TRACER_abort(1); ;
  return;
}
}

void immediatenotify(void) ;
int maxloop ;
int num ;
int i ;
int e ;
int timer ;
char data0 ;
char data1 ;
char readdata(int i0 )
{ char c ;
  char retres3 ;

  {
  if (i0 == 0) {
    retres3 = data0;
    goto returnlabel;
  } else {
    if (i0 == 1) {
      retres3 = data1;
      goto returnlabel;
    } else {
      {
 error();
      }
    }
  }
  retres3 = c;
  returnlabel:
  return (retres3);
}
}
void writedata(int i0 , char c )
{

  {
  if (i0 == 0) {
    data0 = c;
  } else {
    if (i0 == 1) {
      data1 = c;
    } else {
      {
 error();
      }
    }
  }

  return;
}
}
int P1pc;
int P1st ;
int P1i ;
int P1ev ;
void P1(void)
{

  {
  if ((int )P1pc == 0) {
    goto P1ENTRYLOC;
  } else {
    if ((int )P1pc == 1) {
      goto P1WAITLOC;
    } else {

    }
  }
  P1ENTRYLOC:
  {
  while (i < maxloop) {
    while0continue: ;
    {
    writedata(num, 'A');
    num += 1;
    P1pc = 1;
    P1st = 2;
    }

    goto returnlabel;
    P1WAITLOC: ;
  }
  while0break: ;
  }
  P1st = 2;

  returnlabel:
  return;
}
}
int isP1triggered(void)
{ int retres1 ;

  {
  if ((int )P1pc == 1) {
    if ((int )P1ev == 1) {
      retres1 = 1;
      goto returnlabel;
    } else {

    }
  } else {

  }
  retres1 = 0;
  returnlabel:
  return (retres1);
}
}
int C1pc ;
int C1st ;
int C1i ;
int C1ev ;
int C1pr ;
void C1(void)
{ char c ;

  {
  if ((int )C1pc == 0) {
    goto C1ENTRYLOC;
  } else {
    if ((int )C1pc == 1) {
      goto C1WAIT1LOC;
    } else {
      if ((int )C1pc == 2) {
        goto C1WAIT2LOC;
      } else {

      }
    }
  }
  C1ENTRYLOC:
  {
  while (i < maxloop) {
    while2continue: ;
    if (num == 0) {
      timer = 1;
      i += 1;
      C1pc = 1;
      C1st = 2;

      goto returnlabel;
      C1WAIT1LOC: ;
    } else {

    }
    num -= 1;
    if (! (num >= 0)) {
      {
 error();
      }
    } else {

    }
    {
    c = readdata(num);
    i += 1;
    C1pc = 2;
    C1st = 2;
    }

    goto returnlabel;
    C1WAIT2LOC: ;
  }
  while2break: ;
  }
  C1st = 2;

  returnlabel:
  return;
}
}
int isC1triggered(void)
{ int retres1 ;

  {
  if ((int )C1pc == 1) {
    if ((int )e == 1) {
      retres1 = 1;
      goto returnlabel;
    } else {

    }
  } else {

  }
  if ((int )C1pc == 2) {
    if ((int )C1ev == 1) {
      retres1 = 1;
      goto returnlabel;
    } else {

    }
  } else {

  }
  retres1 = 0;
  returnlabel:
  return (retres1);
}
}
void updatechannels(void)
{

  {

  return;
}
}
void initthreads(void)
{

  {
  if ((int )P1i == 1) {
    P1st = 0;
  } else {
    P1st = 2;
  }
  if ((int )C1i == 1) {
    C1st = 0;
  } else {
    C1st = 2;
  }

  return;
}
}
int existsrunnablethread(void)
{ int retres1 ;

  {
  if ((int )P1st == 0) {
    retres1 = 1;
    goto returnlabel;
  } else {
      if ((int )C1st == 0) {
        retres1 = 1;
        goto returnlabel;
      } else {

      }
    }
  }
  retres1 = 0;
  returnlabel:
  return (retres1);
}

void eval(void)
{ int tmp ;
  int tmp0 ;
  int tmp1 ;
  int tmp2 ;

  {
  {
  while (1) {
    while3continue: ;
    {
    tmp2 = existsrunnablethread();
    }
    if (tmp2) {

    } else {
      goto while3break;
    }
    if ((int )P1st == 0) {
      {
      tmp = VERIFIERnondetint();
      }
      if (tmp) {
        {
        P1st = 1;
        P1();
        }
      } else {

      }
    } else {

    }
    if ((int )C1st == 0) {
      {
 tmp1 = VERIFIERnondetint();
      }
      if (tmp1) {
        {
        C1st = 1;
        C1();
        }
      } else {

      }
    } else {

    }
  }
  while3break: ;
  }

  return;
}
}
void firedeltaevents(void)
{

  {

  return;
}
}
void resetdeltaevents(void)
{

  {

  return;
}
}
void firetimeevents(void)
{

  {
  C1ev = 1;

  P1ev = 1;




  return;
}
}
void resettimeevents(void)
{

  {
  if ((int )P1ev == 1) {
    P1ev = 2;
  } else {

  }
  if ((int )C1ev == 1) {
    C1ev = 2;
  } else {

  }

  return;
}
}
void activatethreads(void)
{ int tmp ;
  int tmp0 ;
  int tmp1 ;

  {
  {
  tmp = isP1triggered();
  }
  if (tmp) {
    P1st = 0;
  } else {

  }
  {
  tmp1 = isC1triggered();
  }
  if (tmp1) {
    C1st = 0;
  } else {

  }

  return;
}
}
void immediatenotify(void)
{

  {
  {
  activatethreads();
  }

  return;
}
}
int stopsimulation(void)
{ int tmp ;
  int retres2 ;

  {
  {
  tmp = existsrunnablethread();
  }
  if (tmp) {
    retres2 = 0;
    goto returnlabel;
  } else {

  }
  retres2 = 1;
  returnlabel:
  return (retres2);
}
}
void startsimulation(void)
{ int kernelst ;
  int tmp ;
  int tmp0 ;

  {
  {
  kernelst = 0;
  updatechannels();
  initthreads();
  firedeltaevents();
  activatethreads();
  resetdeltaevents();
  }
  {
  while (1) {
    while4continue: ;
    {
    kernelst = 1;
    eval();
    }
    {
    kernelst = 2;
    updatechannels();
    }
    {
    kernelst = 3;
    firedeltaevents();
    activatethreads();
    resetdeltaevents();
    }
    {
    tmp = existsrunnablethread();
    }
    if (tmp == 0) {
      {
      kernelst = 4;
      firetimeevents();
      activatethreads();
      resettimeevents();
      }
    } else {

    }
    {
    tmp0 = stopsimulation();
    }
    if (tmp0) {
      goto while4break;
    } else {

    }
  }
  while4break: ;
  }

  return;
}
}
void initmodel(void)
{

  {
  P1i = 1;
  C1i = 1;

  return;
}
}
int main(void)
{ int count ;
  int retres2 ;

  {
  {
  num = 0;
  i = 0;
  maxloop = 2;
  e ;
  timer = 0;
  P1pc = 0;
  C1pc = 0;

  count = 0;
  initmodel();
  startsimulation();
  }
  retres2 = 0;
  return (retres2);
}
}
