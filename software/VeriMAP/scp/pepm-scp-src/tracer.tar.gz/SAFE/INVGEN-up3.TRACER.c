# 1 "INVGEN-up3.map.tmp.c"
# 1 "<command-line>"
# 1 "INVGEN-up3.map.tmp.c"
# 1 "MAP/SAFE-exbench/INVGEN-up3.tmp.c"
# 1 "<command-line>"
# 1 "MAP/SAFE-exbench/INVGEN-up3.tmp.c"
# 20 "MAP/SAFE-exbench/INVGEN-up3.tmp.c"
void main() {
  int n;
  int i = 0;
  int k = 0;
  while( i < n ) {
   ;
 i = i + 2;
 k++;
  }
  int j = 0;
  while( j < n ) {
   ;
    if(k <= 0) ERROR: _TRACER_abort(1); goto ERROR;
 j = j + 2;
 k--;
  }
}
