# 1 "DAGGER-seesaw.map.tmp.c"
# 1 "<command-line>"
# 1 "DAGGER-seesaw.map.tmp.c"
# 1 "MAP/SAFE-exbench/DAGGER-seesaw.tmp.c"
# 1 "<command-line>"
# 1 "MAP/SAFE-exbench/DAGGER-seesaw.tmp.c"
# 18 "MAP/SAFE-exbench/DAGGER-seesaw.tmp.c"
int nondet() {int i; return i; }


int main()
{
 int x;
 int y;

 if (! (x==0)) return;
 if (! (y==0)) return;

 while (nondet())
 {
  if (nondet())
  {
   if (! (x >= 9)) return;
   x = x + 2;
   y = y + 1;
  }
  else
  {
   if (nondet())
   {
    if (!(x >= 7)) return;
    if (!(x <= 9)) return;
    x = x + 1;
    y = y + 3;
   }
   else
   {
    if (nondet())
    {
     if (! (x - 5 >=0)) return;
     if (! (x - 7 <=0)) return;
     x = x + 2;
     y = y + 1;
    }
    else
    {
     if (!(x - 4 <=0)) return;
     x = x + 1;
     y = y + 2;
    }
   }
  }
 }
 _TRACER_abort(! ( -x + 2*y >= 0 ));
 _TRACER_abort(! ( 3*x - y >= 0 ));
}
