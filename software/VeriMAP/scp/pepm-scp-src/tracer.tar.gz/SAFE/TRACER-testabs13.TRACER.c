# 1 "TRACER-testabs13.map.tmp.c"
# 1 "<command-line>"
# 1 "TRACER-testabs13.map.tmp.c"
# 1 "MAP/SAFE-exbench/TRACER-testabs13.tmp.c"
# 1 "<command-line>"
# 1 "MAP/SAFE-exbench/TRACER-testabs13.tmp.c"
# 28 "MAP/SAFE-exbench/TRACER-testabs13.tmp.c"
main(int n){
  int i;

  i=0; n=10;

  while (i < n){ i++; }

  _TRACER_abort(! ( !( i>10 ) ));

}
