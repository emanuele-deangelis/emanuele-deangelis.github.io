# 1 "SVCOMP13-loops-terminator_02_safe.map.tmp.c"
# 1 "<command-line>"
# 1 "SVCOMP13-loops-terminator_02_safe.map.tmp.c"
# 1 "MAP/SAFE-exbench/SVCOMP13-loops-terminator02safe.tmp.c"
# 1 "<command-line>"
# 1 "MAP/SAFE-exbench/SVCOMP13-loops-terminator02safe.tmp.c"
# 18 "MAP/SAFE-exbench/SVCOMP13-loops-terminator02safe.tmp.c"
extern void commentedOutVERIFIERassume(int);
void commentedOutVERIFIERassert(int cond) {
  if (!(cond)) {
    ERROR: _TRACER_abort(1); goto ERROR;
  }
  return;
}
int VERIFIERnondetint();
_Bool VERIFIERnondetbool();

main()
{
  int x=VERIFIERnondetint();
  int y=VERIFIERnondetint();
  int z=VERIFIERnondetint();
  _TRACER_assume( x<100 );
  _TRACER_assume( z<100 );
  while(x<100 && 100<z)
  {
    _Bool tmp=VERIFIERnondetbool();
    if (tmp)
   {
     x++;
   }
   else
   {
     x--;
     z--;
   }
  }

  _TRACER_abort(! ( x>=100 || z<=100 ));
}
