# 1 "SVCOMP13-loops-trex02_safe.map.tmp.c"
# 1 "<command-line>"
# 1 "SVCOMP13-loops-trex02_safe.map.tmp.c"
# 1 "MAP/SAFE-exbench/SVCOMP13-loops-trex02safe.tmp.c"
# 1 "<command-line>"
# 1 "MAP/SAFE-exbench/SVCOMP13-loops-trex02safe.tmp.c"
# 18 "MAP/SAFE-exbench/SVCOMP13-loops-trex02safe.tmp.c"
void commentedOutVERIFIERassert(int cond) {
  if (!(cond)) {
    ERROR: _TRACER_abort(1); goto ERROR;
  }
  return;
}
_Bool VERIFIERnondetbool();
int VERIFIERnondetint();


int x;

void foo() {
  x--;
}

int main() {
  x=VERIFIERnondetint();
  while (x > 0) {
    _Bool c = VERIFIERnondetbool();
    if(c) foo();
    else foo();
  }
  _TRACER_abort(! ( x<=0 ));
}
