# 1 "SVCOMP13-loops-while_infinite_loop_2_safe.map.tmp.c"
# 1 "<command-line>"
# 1 "SVCOMP13-loops-while_infinite_loop_2_safe.map.tmp.c"
# 1 "MAP/SAFE-exbench/SVCOMP13-loops-whileinfiniteloop2safe.tmp.c"
# 1 "<command-line>"
# 1 "MAP/SAFE-exbench/SVCOMP13-loops-whileinfiniteloop2safe.tmp.c"
# 18 "MAP/SAFE-exbench/SVCOMP13-loops-whileinfiniteloop2safe.tmp.c"
void commentedOutVERIFIERassert(int cond) {
  if (!(cond)) {
    ERROR: _TRACER_abort(1); goto ERROR;
  }
  return;
}
int main() {
  int x=0;

  while(1)
  {
    _TRACER_abort(! ( x==0 ));
  }

  _TRACER_abort(! ( x==0 ));
}
