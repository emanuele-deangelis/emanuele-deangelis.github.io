# 1 "INVGEN-NetBSD_loop_int.map.tmp.c"
# 1 "<command-line>"
# 1 "INVGEN-NetBSD_loop_int.map.tmp.c"
# 1 "MAP/SAFE-exbench/INVGEN-NetBSDloopint.tmp.c"
# 1 "<command-line>"
# 1 "MAP/SAFE-exbench/INVGEN-NetBSDloopint.tmp.c"
# 21 "MAP/SAFE-exbench/INVGEN-NetBSDloopint.tmp.c"
int BLASTNONDET;
int MAXPATHLEN;

int main ()
{





  int bufoff;
  int patternoff;
  int boundoff;





  int glob3pathbufoff;
  int glob3pathendoff;
  int glob3pathlimoff;
  int glob3patternoff;
  int glob3dc;

  if(MAXPATHLEN > 0); else goto END;





  bufoff = 0;
  patternoff = 0;


  boundoff = 0 + (MAXPATHLEN + 1) - 1;

  glob3pathbufoff = bufoff;
  glob3pathendoff = bufoff;
  glob3pathlimoff = boundoff;
  glob3patternoff = patternoff;

  glob3dc = 0;
  for (;;)
    if (glob3pathendoff + glob3dc >= glob3pathlimoff) break;
    else {

      glob3dc++;

      _TRACER_abort(! ( 0 <= glob3dc ));_TRACER_abort(! ( glob3dc < MAXPATHLEN + 1 ));
      if (BLASTNONDET) goto END;
    }







 END: return 0;
}
