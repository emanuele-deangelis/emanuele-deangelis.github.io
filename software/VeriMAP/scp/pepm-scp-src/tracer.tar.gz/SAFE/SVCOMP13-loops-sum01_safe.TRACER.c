# 1 "SVCOMP13-loops-sum01_safe.map.tmp.c"
# 1 "<command-line>"
# 1 "SVCOMP13-loops-sum01_safe.map.tmp.c"
# 1 "MAP/SAFE-exbench/SVCOMP13-loops-sum01safe.tmp.c"
# 1 "<command-line>"
# 1 "MAP/SAFE-exbench/SVCOMP13-loops-sum01safe.tmp.c"
# 18 "MAP/SAFE-exbench/SVCOMP13-loops-sum01safe.tmp.c"
void commentedOutVERIFIERassert(int cond) {
  if (!(cond)) {
    ERROR: _TRACER_abort(1); goto ERROR;
  }
  return;
}

extern int VERIFIERnondetint();
int main() {
  int i, n=VERIFIERnondetint(), sn=0;
  for(i=1; i<=n; i++) {
    sn = sn + (2);
  }
  _TRACER_abort(! ( sn==n*(2) || sn == 0 ));
}
