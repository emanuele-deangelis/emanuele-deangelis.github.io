# 1 "INVGEN-simple_if.map.tmp.c"
# 1 "<command-line>"
# 1 "INVGEN-simple_if.map.tmp.c"
# 1 "MAP/SAFE-exbench/INVGEN-simpleif.tmp.c"
# 1 "<command-line>"
# 1 "MAP/SAFE-exbench/INVGEN-simpleif.tmp.c"
# 20 "MAP/SAFE-exbench/INVGEN-simpleif.tmp.c"
void main() {
  int n,m;
  int i = 1;
   ;


  while( i < n ) {
    if( m > 0 ) {
      i = 2*i;
    } else {
      i = 3*i;
    }

  }
  _TRACER_abort(! ( i > 0 ));
}
