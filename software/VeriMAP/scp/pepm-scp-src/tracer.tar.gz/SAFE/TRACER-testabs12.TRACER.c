# 1 "TRACER-testabs12.map.tmp.c"
# 1 "<command-line>"
# 1 "TRACER-testabs12.map.tmp.c"
# 1 "MAP/SAFE-exbench/TRACER-testabs12.tmp.c"
# 1 "<command-line>"
# 1 "MAP/SAFE-exbench/TRACER-testabs12.tmp.c"
# 18 "MAP/SAFE-exbench/TRACER-testabs12.tmp.c"
main(){
  int i,count,n;

  _TRACER_assume( count >= 0 );
  i=0;


  while (i < 100 ){
      count++;
      i++;
  }

  _TRACER_abort(! ( !( (i > 100 ) || count < 0 ) ));
}
