# 1 "TRACER-paper-prog_d-pepm-proc.map.c.tmp.c"
# 1 "<command-line>"
# 1 "TRACER-paper-prog_d-pepm-proc.map.c.tmp.c"
# 24 "TRACER-paper-prog_d-pepm-proc.map.c.tmp.c"
int main(){
int y;
int x=0;

    _TRACER_assume( y>=0 );

 while ( x < 10000) {
  y = y + 1;
  x = x + 1;
 }

 if( y + x < 10000)
  goto ERROR;

 return 0;
ERROR: _TRACER_abort(1);
 return -1;
}
