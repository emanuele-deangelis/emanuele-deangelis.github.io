# 1 "TRACER-testloop16.map.tmp.c"
# 1 "<command-line>"
# 1 "TRACER-testloop16.map.tmp.c"
# 1 "MAP/SAFE-exbench/TRACER-testloop16.tmp.c"
# 1 "<command-line>"
# 1 "MAP/SAFE-exbench/TRACER-testloop16.tmp.c"
# 22 "MAP/SAFE-exbench/TRACER-testloop16.tmp.c"
main(int N)
{
  int i, x;

  x = 1;
  i = 0;

  while (i<N) {
    if (x==1) {
      x=2;
    } else {
      x=1;
    }
    i++;
  }

  _TRACER_abort(! ( !( x>2 ) ));

  return;
}
