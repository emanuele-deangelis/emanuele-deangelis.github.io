# 1 "SVCOMP13-loops-while_infinite_loop_3_safe.map.tmp.c"
# 1 "<command-line>"
# 1 "SVCOMP13-loops-while_infinite_loop_3_safe.map.tmp.c"
# 1 "MAP/SAFE-exbench/SVCOMP13-loops-whileinfiniteloop3safe.tmp.c"
# 1 "<command-line>"
# 1 "MAP/SAFE-exbench/SVCOMP13-loops-whileinfiniteloop3safe.tmp.c"
# 18 "MAP/SAFE-exbench/SVCOMP13-loops-whileinfiniteloop3safe.tmp.c"
void commentedOutVERIFIERassert(int cond) {
  if (!(cond)) {
    ERROR: _TRACER_abort(1); goto ERROR;
  }
  return;
}

int x=0;

void eval(void)
{
  while (1) {
      x=0;
      break;
  }
  return;
}


int main() {

  while(1)
  {
    eval();
    _TRACER_abort(! ( x==0 ));
  }

  _TRACER_abort(! ( x!=0 ));

  return 0;
}
