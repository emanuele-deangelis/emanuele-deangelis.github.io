# 1 "INVGEN-bound.map.tmp.c"
# 1 "<command-line>"
# 1 "INVGEN-bound.map.tmp.c"
# 1 "MAP/SAFE-exbench/INVGEN-bound.tmp.c"
# 1 "<command-line>"
# 1 "MAP/SAFE-exbench/INVGEN-bound.tmp.c"
# 20 "MAP/SAFE-exbench/INVGEN-bound.tmp.c"
void main() {
  int n,acca;
  int i,j,k,m;

  ;
  ;
  _TRACER_assume( n >=0 );
  _TRACER_assume( n <=200 );
  k=0;
  i=n;
  acca = i+k;
  while( i > 0 ){
    i--;
    k++;
    acca = i+k;
  }

  j = k;
  m = 0;
  acca = j+m;
  while( j > 0 ) {
 j--;
 m++;
 acca = j+m;
  }
  _TRACER_abort(! ( i >= 0 ));
}
