# 1 "INVGEN-apache-escape-absolute.map.tmp.c"
# 1 "<command-line>"
# 1 "INVGEN-apache-escape-absolute.map.tmp.c"
# 1 "MAP/SAFE-exbench/INVGEN-apache-escape-absolute.tmp.c"
# 1 "<command-line>"
# 1 "MAP/SAFE-exbench/INVGEN-apache-escape-absolute.tmp.c"
# 20 "MAP/SAFE-exbench/INVGEN-apache-escape-absolute.tmp.c"
void main ()
{
  int BLASTNONDET;
  int scheme;
  int urilen,tokenlen;
  int cp,c;


  ;
  if(urilen>0); else goto END;
  if(tokenlen>0); else goto END;
  if(scheme >= 0 );else goto END;
  if (scheme == 0
      || (urilen-1 < scheme)) {
    goto END;
  }

  cp = scheme;

  _TRACER_abort(! ( cp-1 < urilen ));
  _TRACER_abort(! ( 0 <= cp-1 ));

  if (BLASTNONDET) {
    _TRACER_abort(! ( cp < urilen ));
    _TRACER_abort(! ( 0 <= cp ));
    while ( cp != urilen-1) {
      if(BLASTNONDET) break;
      _TRACER_abort(! ( cp < urilen ));
      _TRACER_abort(! ( 0 <= cp ));
      ++cp;
    }
    _TRACER_abort(! ( cp < urilen ));
    _TRACER_abort(! ( 0 <= cp ));
    if (cp == urilen-1) goto END;
    _TRACER_abort(! ( cp+1 < urilen ));
    _TRACER_abort(! ( 0 <= cp+1 ));
    if (cp+1 == urilen-1) goto END;
    ++cp;

    scheme = cp;

    if (BLASTNONDET) {
      c = 0;

      _TRACER_abort(! ( cp < urilen ));
      _TRACER_abort(! ( 0<=cp ));
      while ( cp != urilen-1
             && c < tokenlen - 1) {
 _TRACER_abort(! ( cp < urilen ));
 _TRACER_abort(! ( 0<=cp ));
        if (BLASTNONDET) {
          ++c;

   _TRACER_abort(! ( c < tokenlen ));
   _TRACER_abort(! ( 0<=c ));

   _TRACER_abort(! ( cp < urilen ));
   _TRACER_abort(! ( 0<=cp ));

        }
        ++cp;
      }
      goto END;
    }
  }

 END:
}
