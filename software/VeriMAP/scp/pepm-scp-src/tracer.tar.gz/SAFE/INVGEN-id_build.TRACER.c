# 1 "INVGEN-id_build.map.tmp.c"
# 1 "<command-line>"
# 1 "INVGEN-id_build.map.tmp.c"
# 1 "MAP/SAFE-exbench/INVGEN-idbuild.tmp.c"
# 1 "<command-line>"
# 1 "MAP/SAFE-exbench/INVGEN-idbuild.tmp.c"
# 38 "MAP/SAFE-exbench/INVGEN-idbuild.tmp.c"
void main() {
  int offset, length, nlen;
  int i, j;

  ;

  for (i=0; i<nlen; i++) {
    for (j=0; j<8; j++) {
      _TRACER_abort(! ( 0 <= nlen-1-i ));
      _TRACER_abort(! ( nlen-1-i < nlen ));
    }
  }
  return;
}
