# 1 "INVGEN-nested.map.tmp.c"
# 1 "<command-line>"
# 1 "INVGEN-nested.map.tmp.c"
# 1 "MAP/SAFE-exbench/INVGEN-nested.tmp.c"
# 1 "<command-line>"
# 1 "MAP/SAFE-exbench/INVGEN-nested.tmp.c"
# 21 "MAP/SAFE-exbench/INVGEN-nested.tmp.c"
void main() {
  int i,k,n,l;

  ;

  for (k=1;k<n;k++){


    for (i=1;i<n;i++) {



    }
  }
  _TRACER_abort(! ( 1<=k ));
 }
