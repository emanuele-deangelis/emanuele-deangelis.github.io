# 1 "TRACER-testabs2.map.tmp.c"
# 1 "<command-line>"
# 1 "TRACER-testabs2.map.tmp.c"
# 1 "MAP/SAFE-exbench/TRACER-testabs2.tmp.c"
# 1 "<command-line>"
# 1 "MAP/SAFE-exbench/TRACER-testabs2.tmp.c"
# 21 "MAP/SAFE-exbench/TRACER-testabs2.tmp.c"
int error=0;
void main(){
  int x,y,z;

  z=1;
  x=4;



  if(z>0){
    x=4;
    y=1;
  }
  else{
    x=100;
    y=2;
  }

  _TRACER_abort(! ( !( x<=0 ) ));

}
