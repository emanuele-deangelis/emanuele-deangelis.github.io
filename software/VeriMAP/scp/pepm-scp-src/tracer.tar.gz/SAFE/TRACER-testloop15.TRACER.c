# 1 "TRACER-testloop15.map.tmp.c"
# 1 "<command-line>"
# 1 "TRACER-testloop15.map.tmp.c"
# 1 "MAP/SAFE-exbench/TRACER-testloop15.tmp.c"
# 1 "<command-line>"
# 1 "MAP/SAFE-exbench/TRACER-testloop15.tmp.c"
# 32 "MAP/SAFE-exbench/TRACER-testloop15.tmp.c"
int main()
{
  int i = 0;
  int N = 100;

  while (i<N) {
    i++;
  }

  _TRACER_abort(! ( !( i>N ) ));

  return 0;
}
