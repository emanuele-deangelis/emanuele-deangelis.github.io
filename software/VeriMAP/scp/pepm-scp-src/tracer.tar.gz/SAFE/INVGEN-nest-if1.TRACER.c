# 1 "INVGEN-nest-if1.map.tmp.c"
# 1 "<command-line>"
# 1 "INVGEN-nest-if1.map.tmp.c"
# 1 "MAP/SAFE-exbench/INVGEN-nest-if1.tmp.c"
# 1 "<command-line>"
# 1 "MAP/SAFE-exbench/INVGEN-nest-if1.tmp.c"
# 20 "MAP/SAFE-exbench/INVGEN-nest-if1.tmp.c"
int NONDET;

void main() {
  int i,k,n,l;

  ;

  _TRACER_assume( l>0 );

  for (k=1;k<n;k++){
    for (i=l;i<n;i++)
      _TRACER_abort(! ( 1<=i ));
    if(NONDET)
      for (i=l;i<n;i++);
  }

}
