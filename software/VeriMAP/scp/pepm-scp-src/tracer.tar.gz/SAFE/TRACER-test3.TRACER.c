# 1 "TRACER-test3.map.tmp.c"
# 1 "<command-line>"
# 1 "TRACER-test3.map.tmp.c"
# 1 "MAP/SAFE-exbench/TRACER-test3.tmp.c"
# 1 "<command-line>"
# 1 "MAP/SAFE-exbench/TRACER-test3.tmp.c"
# 22 "MAP/SAFE-exbench/TRACER-test3.tmp.c"
extern int unknown();

main(){
  int x=0;
  int y=0;

  if (unknown())
    x = 5;
  else
    y = 10;

  _TRACER_abort(! ( !( x!=5 && y!=10 ) ));
  return;

}
