# 1 "INVGEN-sendmail-mime7to8_arr_three_chars_no_test_ok.map.tmp.c"
# 1 "<command-line>"
# 1 "INVGEN-sendmail-mime7to8_arr_three_chars_no_test_ok.map.tmp.c"
# 1 "MAP/SAFE-exbench/INVGEN-sendmail-mime7to8arrthreecharsnotestok.tmp.c"
# 1 "<command-line>"
# 1 "MAP/SAFE-exbench/INVGEN-sendmail-mime7to8arrthreecharsnotestok.tmp.c"
# 20 "MAP/SAFE-exbench/INVGEN-sendmail-mime7to8arrthreecharsnotestok.tmp.c"
int main (void)
{

  int BLASTNONDET;
  int fbuflen;
  int fb;

  ;
  if(fbuflen >0);else goto END;
  fb = 0;
  while (BLASTNONDET)
  {

    if (BLASTNONDET)
      break;


    if (BLASTNONDET)
      break;


    _TRACER_abort(! ( 0<=fb ));
    _TRACER_abort(! ( fb<fbuflen ));

    fb++;
    if (fb >= fbuflen-1)
      fb = 0;


    _TRACER_abort(! ( 0<=fb ));
    _TRACER_abort(! ( fb<fbuflen ));


    fb++;
    if (fb >= fbuflen-1)
      fb = 0;


    _TRACER_abort(! ( 0<=fb ));
    _TRACER_abort(! ( fb<fbuflen ));


    fb++;
    if (fb >= fbuflen-1)
      fb = 0;
  }


  if (fb > 0)
  {

    _TRACER_abort(! ( 0<=fb ));
    _TRACER_abort(! ( fb<fbuflen ));

  }

 END: return 0;
}
