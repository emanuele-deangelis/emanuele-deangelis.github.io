# 1 "SVCOMP13-systemc-pc_sfifo_2_safeil.map.c.tmp.c"
# 1 "<command-line>"
# 1 "SVCOMP13-systemc-pc_sfifo_2_safeil.map.c.tmp.c"
# 1 "MAP/SAFE-exbench/SVCOMP13-systemc-pcsfifo2safeil.c.tmp.c"
# 1 "<command-line>"
# 1 "MAP/SAFE-exbench/SVCOMP13-systemc-pcsfifo2safeil.c.tmp.c"
# 18 "MAP/SAFE-exbench/SVCOMP13-systemc-pcsfifo2safeil.c.tmp.c"
extern int VERIFIERnondetint();


void error(void)
{

  {
  goto ERROR;
  ERROR: _TRACER_abort(1); ;
  return;
}
}

int qbuf0 ;
int qfree ;
int qreadev ;
int qwriteev ;
int qrequp ;
int qev ;
void updatefifoq(void)
{

  {
  if ((int )qfree == 0) {
    qwriteev = 0;
  } else {

  }
  if ((int )qfree == 1) {
    qreadev = 0;
  } else {

  }
  qev = 0;
  qrequp = 0;

  return;
}
}
int pnumwrite ;
int plastwrite ;
int pdwst ;
int pdwpc ;
int pdwi ;
int cnumread ;
int clastread ;
int cdrst ;
int cdrpc ;
int cdri ;
int isdowriteptriggered(void)
{ int retres1 ;

  {
  if ((int )pdwpc == 1) {
    if ((int )qreadev == 1) {
      retres1 = 1;
      goto returnlabel;
    } else {

    }
  } else {

  }
  retres1 = 0;
  returnlabel:
  return (retres1);
}
}
int isdoreadctriggered(void)
{ int retres1 ;

  {
  if ((int )cdrpc == 1) {
    if ((int )qwriteev == 1) {
      retres1 = 1;
      goto returnlabel;
    } else {

    }
  } else {

  }
  retres1 = 0;
  returnlabel:
  return (retres1);
}
}
void immediatenotifythreads(void)
{ int tmp ;
  int tmp0 ;

  {
  {
  tmp = isdowriteptriggered();
  }
  if (tmp) {
    pdwst = 0;
  } else {

  }
  {
  tmp0 = isdoreadctriggered();
  }
  if (tmp0) {
    cdrst = 0;
  } else {

  }

  return;
}
}
void dowritep(void)
{

  {
  if ((int )pdwpc == 0) {
    goto DWENTRY;
  } else {
    if ((int )pdwpc == 1) {
      goto DWWAITREAD;
    } else {

    }
  }
  DWENTRY:
  {
  while (1) {
    while0continue: ;
    if ((int )qfree == 0) {
      pdwst = 2;
      pdwpc = 1;

      goto returnlabel;
      DWWAITREAD: ;
    } else {

    }
    {
      qbuf0 = VERIFIERnondetint();
    plastwrite = qbuf0;
    pnumwrite += 1;
    qfree = 0;
    qrequp = 1;
    }
  }
  while0break: ;
  }
  returnlabel:
  return;
}
}
static int at ;
void doreadc(void)
{ int a ;

  {
  if ((int )cdrpc == 0) {
    goto DRENTRY;
  } else {
    if ((int )cdrpc == 1) {
      goto DRWAITWRITE;
    } else {

    }
  }
  DRENTRY:
  {
  while (1) {
    while1continue: ;
    if ((int )qfree == 1) {
      cdrst = 2;
      cdrpc = 1;
      at = a;

      goto returnlabel;
      DRWAITWRITE:
      a = at;
    } else {

    }
    a = qbuf0;
    clastread = a;
    cnumread += 1;
    qfree = 1;
    qrequp = 1;
    if (plastwrite == clastread) {
      if (pnumwrite == cnumread) {

      } else {
        {
        error();
        }
      }
    } else {
      {
      error();
      }
    }
  }
  while1break: ;
  }
  returnlabel:
  return;
}
}
void updatechannels(void)
{

  {
  if ((int )qrequp == 1) {
    {
    updatefifoq();
    }
  } else {

  }

  return;
}
}
void initthreads(void)
{

  {
  if ((int )pdwi == 1) {
    pdwst = 0;
  } else {
    pdwst = 2;
  }
  if ((int )cdri == 1) {
    cdrst = 0;
  } else {
    cdrst = 2;
  }

  return;
}
}
int existsrunnablethread(void)
{ int retres1 ;

  {
  if ((int )pdwst == 0) {
    retres1 = 1;
    goto returnlabel;
  } else {
    if ((int )cdrst == 0) {
      retres1 = 1;
      goto returnlabel;
    } else {

    }
  }
  retres1 = 0;
  returnlabel:
  return (retres1);
}
}
void firedeltaevents(void)
{

  {
  if ((int )qreadev == 0) {
    qreadev = 1;
  } else {

  }
  if ((int )qwriteev == 0) {
    qwriteev = 1;
  } else {

  }

  return;
}
}
void resetdeltaevents(void)
{

  {
  if ((int )qreadev == 1) {
    qreadev = 2;
  } else {

  }
  if ((int )qwriteev == 1) {
    qwriteev = 2;
  } else {

  }

  return;
}
}
void activatethreads(void)
{ int tmp ;
  int tmp0 ;

  {
  {
  tmp = isdowriteptriggered();
  }
  if (tmp) {
    pdwst = 0;
  } else {

  }
  {
  tmp0 = isdoreadctriggered();
  }
  if (tmp0) {
    cdrst = 0;
  } else {

  }

  return;
}
}
void eval(void)
{ int tmp ;
  int tmp0 ;
  int tmp1 ;

  {
  {
  while (1) {
    while2continue: ;
    {
    tmp1 = existsrunnablethread();
    }
    if (tmp1) {

    } else {
      goto while2break;
    }
    if ((int )pdwst == 0) {
      {
 tmp = VERIFIERnondetint();
      }
      if (tmp) {
        {
        pdwst = 1;
        dowritep();
        }
      } else {

      }
    } else {

    }
    if ((int )cdrst == 0) {
      {
 tmp0 = VERIFIERnondetint();
      }
      if (tmp0) {
        {
        cdrst = 1;
        doreadc();
        }
      } else {

      }
    } else {

    }
  }
  while2break: ;
  }

  return;
}
}
int stopsimulation(void)
{ int tmp ;
  int retres2 ;

  {
  {
  tmp = existsrunnablethread();
  }
  if (tmp) {
    retres2 = 0;
    goto returnlabel;
  } else {

  }
  retres2 = 1;
  returnlabel:
  return (retres2);
}
}
void startsimulation(void)
{ int kernelst ;
  int tmp ;

  {
  {
  kernelst = 0;
  updatechannels();
  initthreads();
  firedeltaevents();
  activatethreads();
  resetdeltaevents();
  }
  {
  while (1) {
    while3continue: ;
    {
    kernelst = 1;
    eval();
    }
    {
    kernelst = 2;
    updatechannels();
    }
    {
    kernelst = 3;
    firedeltaevents();
    activatethreads();
    resetdeltaevents();
    tmp = stopsimulation();
    }
    if (tmp) {
      goto while3break;
    } else {

    }
  }
  while3break: ;
  }

  return;
}
}
void initmodel(void)
{

  {
  qfree = 1;
  qwriteev = 2;
  qreadev = qwriteev;
  pnumwrite = 0;
  pdwpc = 0;
  pdwi = 1;
  cnumread = 0;
  cdrpc = 0;
  cdri = 1;

  return;
}
}
int main(void)
{ int retres1 ;

  {
  {
  initmodel();
  startsimulation();
  }
  retres1 = 0;
  return (retres1);
}
}
