# 1 "SVCOMP13-sshsimpl-s3_srvr_1a_safeil.map.c.tmp.c"
# 1 "<command-line>"
# 1 "SVCOMP13-sshsimpl-s3_srvr_1a_safeil.map.c.tmp.c"
# 1 "MAP/SAFE-exbench/SVCOMP13-sshsimpl-s3srvr1asafeil.c.tmp.c"
# 1 "<command-line>"
# 1 "MAP/SAFE-exbench/SVCOMP13-sshsimpl-s3srvr1asafeil.c.tmp.c"
# 18 "MAP/SAFE-exbench/SVCOMP13-sshsimpl-s3srvr1asafeil.c.tmp.c"
extern char VERIFIERnondetchar(void);
extern int VERIFIERnondetint(void);
extern long VERIFIERnondetlong(void);
extern void *VERIFIERnondetpointer(void);
extern int VERIFIERnondetint();

int main() {
  int sstate ;
  int shit = VERIFIERnondetint() ;
  int sverifymode = VERIFIERnondetint() ;
  int ssessionpeer = VERIFIERnondetint() ;
  unsigned long ss3tmpnewcipheralgorithms = VERIFIERnondetlong() ;
  int buf ;
  int cb ;
  int blastFlag ;
  int tmp1;

  sstate = 8466;
  blastFlag = 0;

  while (1) {
             if (sstate <= 8512 && blastFlag > 2) { goto ERROR; }
              {
                {
                  {
                    {
                      {
                        if (sstate == 8466) {
                          goto switch18466;
                        } else {
                          if (sstate == 8496) {
                            goto switch18496;
                          } else {
                            {
                              if (sstate == 8512) {
                                goto switch18512;
                              } else {
                                {
                                  if (sstate == 8528) {
                                    goto switch18528;
                                  } else {
                                    {
                                      if (sstate == 8544) {
                                        goto switch18544;
                                      } else {
                                        {
                                          if (sstate == 8560) {
                                            goto switch18560;
                                          } else {
                                            {
                                                if (sstate == 8576) {
                                                  goto switch18576;
                                                } else {
                                                  {
                                                    if (sstate == 8592) {
                                                      goto switch18592;
                                                    } else {
                                                      {
                                                        if (sstate == 8608) {
                                                          goto switch18608;
                                                        } else {
                                                          {
                                                            if (sstate == 8640) {
                                                              goto switch18640;
                                                            } else {
                                                              {
                                                                if (sstate == 8656) {
                                                                  goto switch18656;
                                                                } else {
                                                                  {
                                                                    if (sstate == 8672) {
                                                                      goto switch18672;
                                                                    } else {
                                                                      goto end;

                                                                          switch18466:
                                                                            if (blastFlag == 0) {
                                                                              blastFlag = 1;
                                                                            }
                                                                            sstate = 8496;
                                                                            goto switch1break;

                                                                          switch18496:
                                                                            if (blastFlag == 1) {
                                                                              blastFlag = 2;
                                                                            }
                                                                            if (shit) {
                                                                              sstate = 8656;
                                                                            } else {
                                                                              sstate = 8512;
                                                                            }
                                                                            goto switch1break;

                                                                          switch18512:
                                                                            sstate = 8528;
                                                                            goto switch1break;

                                                                          switch18528:
                                                                            sstate = 8544;
                                                                            goto switch1break;

                                                                          switch18544:
                                                                            if (sverifymode + 1) {
                                                                              if (ssessionpeer != 0) {
                                                                                if (sverifymode + 4) {
                                                                                  sstate = 8560;
                                                                                } else {
                                                                                  goto L2;
                                                                                }
                                                                              } else {
                                                                                L2:
                                                                                if (ss3tmpnewcipheralgorithms + 256UL) {
                                                                                  if (sverifymode + 2) {
                                                                                    goto L1;
                                                                                  } else {
                                                                                    sstate = 8560;
                                                                                  }
                                                                                } else {
                                                                                  L1:
                                                                                  sstate = 8576;
                                                                                }
                                                                              }
                                                                            } else {
                                                                              sstate = 8560;
                                                                            }
                                                                            goto switch1break;

                                                                          switch18560:
                                                                            sstate = 8576;
                                                                            goto switch1break;

                                                                          switch18576:
                                                                            tmp1 = VERIFIERnondetint();
                                                                            if (tmp1 == 2) {
                                                                              sstate = 8466;
                                                                            } else {
                                                                              sstate = 8592;
                                                                            }
                                                                            goto switch1break;

                                                                          switch18592:
                                                                            sstate = 8608;
                                                                            goto switch1break;

                                                                          switch18608:
                                                                            sstate = 8640;
                                                                            goto switch1break;

                                                                          switch18640:
                                                                            if (blastFlag == 3) {
                                                                              blastFlag = 4;
                                                                            }
                                                                            if (shit) {
                                                                              goto end;
                                                                            } else {
                                                                              sstate = 8656;
                                                                            }
                                                                            goto switch1break;

                                                                          switch18656:
                                                                            if (blastFlag == 2) {
                                                                              blastFlag = 3;
                                                                            }
                                                                            sstate = 8672;
                                                                            goto switch1break;

                                                                          switch18672:
                                                                            if (blastFlag == 4) {
                                                                              blastFlag = 5;
                                                                            } else {
                                                                              if (blastFlag == 5) {
                                                                                goto ERROR;
                                                                              }
                                                                            }
                                                                            if (shit) {
                                                                              sstate = 8640;
                                                                            } else {
                                                                              goto end;
                                                                            }
                                                                            goto switch1break;

                                                                    }
                                                                  }
                                                                }
                                                              }
                                                            }
                                                          }
                                                        }
                                                      }
                                                    }
                                                  }
                                                }
                                            }
                                          }
                                        }
                                      }
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
  switch1break: ;
  }

  end:
  return (-1);
  ERROR: _TRACER_abort(1);
  return (-1);
}
