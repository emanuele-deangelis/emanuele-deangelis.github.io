# 1 "TRACER-testwp10.map.tmp.c"
# 1 "<command-line>"
# 1 "TRACER-testwp10.map.tmp.c"
# 1 "MAP/SAFE-exbench/TRACER-testwp10.tmp.c"
# 1 "<command-line>"
# 1 "MAP/SAFE-exbench/TRACER-testwp10.tmp.c"
# 19 "MAP/SAFE-exbench/TRACER-testwp10.tmp.c"
main(){
# 41 "MAP/SAFE-exbench/TRACER-testwp10.tmp.c"
  int x;
  if (x==1){
    x++;
  }
  else{
    if (x==2){
      x++;
    }
    else{
      if(x==3){
 x++;
      }
      else
 x=0;
    }
  }

  _TRACER_abort(! ( !( x>4 ) ));

}
