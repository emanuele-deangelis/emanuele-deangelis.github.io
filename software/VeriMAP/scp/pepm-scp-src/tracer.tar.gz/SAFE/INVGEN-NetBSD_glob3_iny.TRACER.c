# 1 "INVGEN-NetBSD_glob3_iny.map.tmp.c"
# 1 "<command-line>"
# 1 "INVGEN-NetBSD_glob3_iny.map.tmp.c"
# 1 "MAP/SAFE-exbench/INVGEN-NetBSDglob3iny.tmp.c"
# 1 "<command-line>"
# 1 "MAP/SAFE-exbench/INVGEN-NetBSDglob3iny.tmp.c"
# 20 "MAP/SAFE-exbench/INVGEN-NetBSDglob3iny.tmp.c"
int BLASTNONDET;

int main ()
{





  int bufoff, patternoff, boundoff;

  int MAXPATHLEN;





  int error;

  int pathbufoff;
  int pathendoff;
  int pathlimoff;





  if(MAXPATHLEN >0); else goto END;

  bufoff = 0;
  patternoff = 0;

  boundoff = MAXPATHLEN;
# 67 "MAP/SAFE-exbench/INVGEN-NetBSDglob3iny.tmp.c"
  pathbufoff = 0;
  pathendoff = 0;
  pathlimoff = MAXPATHLEN;



  error = 0;


  while (BLASTNONDET) {
    int i;


    _TRACER_abort(! ( 0 <= patternoff )); _TRACER_abort(! ( patternoff <= MAXPATHLEN ));

      if (BLASTNONDET) continue;




    i = 0;
    for (;;)
      if (i > MAXPATHLEN) goto END;
      else {
 _TRACER_abort(! ( 0 <= i )); _TRACER_abort(! ( i <= MAXPATHLEN ));

        i++;
        if (BLASTNONDET) goto END;
      }




    _TRACER_abort(! ( 0 <= pathlimoff )); _TRACER_abort(! ( pathlimoff <= MAXPATHLEN ));


    if (i > MAXPATHLEN){
      if ( BLASTNONDET ) {





 if ( BLASTNONDET ) {
   error = 5;
   goto END;
 }
 else {

   _TRACER_abort(! ( 0 <= i ));_TRACER_abort(! ( i <= MAXPATHLEN + 1 ));

   continue;
 }
      }
    }





    if ( BLASTNONDET) {

      _TRACER_abort(! ( i <= MAXPATHLEN + 1 ));

      continue;
    }
  ENDLOOP1:
  }



 END: return 0;
}
