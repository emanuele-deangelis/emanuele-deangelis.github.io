# 1 "INVGEN-rajamani_1.map.tmp.c"
# 1 "<command-line>"
# 1 "INVGEN-rajamani_1.map.tmp.c"
# 1 "MAP/SAFE-exbench/INVGEN-rajamani1.tmp.c"
# 1 "<command-line>"
# 1 "MAP/SAFE-exbench/INVGEN-rajamani1.tmp.c"
# 19 "MAP/SAFE-exbench/INVGEN-rajamani1.tmp.c"
int BLASTNONDET;

int main(){
  int x=0;
  int y=0;
  int z=0;
  int w=0;

  while ( BLASTNONDET ){
    if ( BLASTNONDET ) {
      x++; y = y+100;
    } else if ( BLASTNONDET ) {
      if( x >= 4)
 { x=x+1; y=y+1;}
    } else if ( y >10*w)
      if (z>=100*x )
      y = -y;
    w=w+1;
    z=z+10;
  }
  if ( x >=4 )
    _TRACER_abort(! ( y>2 ));
}
