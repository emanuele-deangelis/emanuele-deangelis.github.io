# 1 "INVGEN-apache-get-tag.map.tmp.c"
# 1 "<command-line>"
# 1 "INVGEN-apache-get-tag.map.tmp.c"
# 1 "MAP/SAFE-exbench/INVGEN-apache-get-tag.tmp.c"
# 1 "<command-line>"
# 1 "MAP/SAFE-exbench/INVGEN-apache-get-tag.tmp.c"
# 19 "MAP/SAFE-exbench/INVGEN-apache-get-tag.tmp.c"
void main()
{
  int tagbuflen;
  int t;
  int BLASTNONDET;

  ;


  if(tagbuflen >= 1); else goto END;

  t = 0;

  --tagbuflen;
# 55 "MAP/SAFE-exbench/INVGEN-apache-get-tag.tmp.c"
  while (1) {
    if (t == tagbuflen) {
      _TRACER_abort(! ( 0 <= t ));
      _TRACER_abort(! ( t <= tagbuflen ));

      goto END;
    }
    if (BLASTNONDET) {
      break;
    }
     _TRACER_abort(! ( 0 <= t ));
     _TRACER_abort(! ( t <= tagbuflen ));

    t++;

  }

   _TRACER_abort(! ( 0 <= t ));
   _TRACER_abort(! ( t <= tagbuflen ));

  t++;
# 94 "MAP/SAFE-exbench/INVGEN-apache-get-tag.tmp.c"
  while (1) {

    if (t == tagbuflen) {
      _TRACER_abort(! ( 0 <= t ));
      _TRACER_abort(! ( t <= tagbuflen ));

      goto END;
    }

    if (BLASTNONDET) {

      if ( BLASTNONDET) {

  _TRACER_abort(! ( 0 <= t ));
 _TRACER_abort(! ( t <= tagbuflen ));

        t++;
        if (t == tagbuflen) {

   _TRACER_abort(! ( 0 <= t ));
   _TRACER_abort(! ( t <= tagbuflen ));

          goto END;
        }
      }
    }
    else if ( BLASTNONDET) {
      break;
    }


    _TRACER_abort(! ( 0 <= t ));
    _TRACER_abort(! ( t <= tagbuflen ));

    t++;

  }

  _TRACER_abort(! ( 0 <= t ));
  _TRACER_abort(! ( t <= tagbuflen ));


  END:
}
