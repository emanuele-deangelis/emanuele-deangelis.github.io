# 1 "SVCOMP13-sshsimpl-s3_srvr_1b_safeil.map.c.tmp.c"
# 1 "<command-line>"
# 1 "SVCOMP13-sshsimpl-s3_srvr_1b_safeil.map.c.tmp.c"
# 1 "MAP/SAFE-exbench/SVCOMP13-sshsimpl-s3srvr1bsafeil.c.tmp.c"
# 1 "<command-line>"
# 1 "MAP/SAFE-exbench/SVCOMP13-sshsimpl-s3srvr1bsafeil.c.tmp.c"
# 18 "MAP/SAFE-exbench/SVCOMP13-sshsimpl-s3srvr1bsafeil.c.tmp.c"
extern char VERIFIERnondetchar(void);
extern int VERIFIERnondetint(void);
extern long VERIFIERnondetlong(void);
extern void *VERIFIERnondetpointer(void);
extern int VERIFIERnondetint();

int main() {
  int sstate ;
  int shit = VERIFIERnondetint() ;
  int blastFlag ;
  int tmp1;

  sstate = 8466;
  blastFlag = 0;

  while (1) {
   if (sstate <= 8512 && blastFlag > 2) { goto ERROR; }
              {
                {
                  {
                    {
                      {
                        if (sstate == 8466) {
                          goto switch18466;
                        } else {
                          {
                            {
                              if (sstate == 8512) {
                                goto switch18512;
                              } else {
                                {
                                  {
                                    {
                                      {
                                        {
                                          {
                                            {
                                                {
                                                  {
                                                    {
                                                      {
                                                        {
                                                          {
                                                            if (sstate == 8640) {
                                                              goto switch18640;
                                                            } else {
                                                              {
                                                                if (sstate == 8656) {
                                                                  goto switch18656;
                                                                } else {
                                                                  {
                                                                    {
                                                                      goto end;

                                                                          switch18466:
                                                                            if (blastFlag == 0) {
                                                                              blastFlag = 2;
                                                                            }
                                                                            if (shit) {
                                                                              sstate = 8656;
                                                                            } else {
                                                                              sstate = 8512;
                                                                            }
                                                                            goto switch1break;

                                                                          switch18512:
                                                                            tmp1 = VERIFIERnondetint();
                                                                            if (tmp1) {
                                                                              sstate = 8466;
                                                                            } else {
                                                                              sstate = 8640;
                                                                            }
                                                                            goto switch1break;

                                                                          switch18640:
                                                                            if (blastFlag == 3) {
                                                                              blastFlag = 4;
                                                                            }
                                                                            if (shit) {
                                                                              goto end;
                                                                            } else {
                                                                              sstate = 8656;
                                                                            }
                                                                            goto switch1break;

                                                                          switch18656:
                                                                            if (blastFlag == 2) {
                                                                              blastFlag = 3;
                                                                            }

                                                                            if (blastFlag == 4) {
                                                                              blastFlag = 5;
                                                                            } else {
                                                                              if (blastFlag == 5) {
                                                                                goto ERROR;
                                                                              }
                                                                            }
                                                                            if (shit) {
                                                                              sstate = 8640;
                                                                            } else {
                                                                              goto end;
                                                                            }
                                                                            goto switch1break;

                                                                    }
                                                                  }
                                                                }
                                                              }
                                                            }
                                                          }
                                                        }
                                                      }
                                                    }
                                                  }
                                                }
                                            }
                                          }
                                        }
                                      }
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
  switch1break: ;
  }

  end:
  return (-1);
  ERROR: _TRACER_abort(1);
  return (-1);
}
