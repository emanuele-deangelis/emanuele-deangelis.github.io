# 1 "INVGEN-nest-if4.map.tmp.c"
# 1 "<command-line>"
# 1 "INVGEN-nest-if4.map.tmp.c"
# 1 "MAP/SAFE-exbench/INVGEN-nest-if4.tmp.c"
# 1 "<command-line>"
# 1 "MAP/SAFE-exbench/INVGEN-nest-if4.tmp.c"
# 20 "MAP/SAFE-exbench/INVGEN-nest-if4.tmp.c"
int NONDET;

void main() {
  int i,k,n,l;

  ;

  _TRACER_assume( l>0 );

  for (k=1;k<n;k++){
    if(NONDET)
      for (i=l;i<n;i++)
 _TRACER_abort(! ( 1<=i ));
    for (i=l;i<n;i++);
  }

 }
