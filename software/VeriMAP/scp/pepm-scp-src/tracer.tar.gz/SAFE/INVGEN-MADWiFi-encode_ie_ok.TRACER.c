# 1 "INVGEN-MADWiFi-encode_ie_ok.map.tmp.c"
# 1 "<command-line>"
# 1 "INVGEN-MADWiFi-encode_ie_ok.map.tmp.c"
# 1 "MAP/SAFE-exbench/INVGEN-MADWiFi-encodeieok.tmp.c"
# 1 "<command-line>"
# 1 "MAP/SAFE-exbench/INVGEN-MADWiFi-encodeieok.tmp.c"
# 20 "MAP/SAFE-exbench/INVGEN-MADWiFi-encodeieok.tmp.c"
int main()
{


  int p;
  int i;
  int leaderlen;
  int bufsize;
  int bufsize0;
  int ielen;

  ;


  if(leaderlen >0); else goto END;
  if(bufsize >0); else goto END;
  if(ielen >0); else goto END;

  if (bufsize < leaderlen)
    goto END;


  p = 0;

  bufsize0 = bufsize;
  bufsize -= leaderlen;
  p += leaderlen;


  if (bufsize < 2*ielen)
    goto END;



  for (i = 0; i < ielen && bufsize > 2; i++) {
    _TRACER_abort(! ( 0<=p ));
    _TRACER_abort(! ( p+1<bufsize0 ));


    p += 2;
  }




 END:
}
