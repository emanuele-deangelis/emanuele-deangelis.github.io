# 1 "INVGEN-NetBSD_g_Ctoc.map.tmp.c"
# 1 "<command-line>"
# 1 "INVGEN-NetBSD_g_Ctoc.map.tmp.c"
# 1 "MAP/SAFE-exbench/INVGEN-NetBSDgCtoc.tmp.c"
# 1 "<command-line>"
# 1 "MAP/SAFE-exbench/INVGEN-NetBSDgCtoc.tmp.c"
# 20 "MAP/SAFE-exbench/INVGEN-NetBSDgCtoc.tmp.c"
int BASESZ;
int BLASTNONDET;
int main ()
{


  int i;
  int j;
  int len = BASESZ;

  if(BASESZ > 0 ); else goto END;


  _TRACER_abort(! ( 0 <= BASESZ-1 ));

  if (len == 0)
    goto END;

  i = 0;
  j = 0;
  while (1) {
    if ( len == 0 ){
      goto END;
    } else {
      _TRACER_abort(! ( 0<= j )); _TRACER_abort(! ( j < BASESZ ));
      _TRACER_abort(! ( 0<= i )); _TRACER_abort(! ( i < BASESZ ));

      if ( BLASTNONDET ) {
        i++;
        j++;
        goto END;
      }
    }
    i ++;
    j ++;
    len --;
  }

 END: return 0;
}
