# 1 "SVCOMP13-loops-terminator_03_safe.map.tmp.c"
# 1 "<command-line>"
# 1 "SVCOMP13-loops-terminator_03_safe.map.tmp.c"
# 1 "MAP/SAFE-exbench/SVCOMP13-loops-terminator03safe.tmp.c"
# 1 "<command-line>"
# 1 "MAP/SAFE-exbench/SVCOMP13-loops-terminator03safe.tmp.c"
# 18 "MAP/SAFE-exbench/SVCOMP13-loops-terminator03safe.tmp.c"
void commentedOutVERIFIERassert(int cond) {
  if (!(cond)) {
    ERROR: _TRACER_abort(1); goto ERROR;
  }
  return;
}
int VERIFIERnondetint();
_Bool VERIFIERnondetbool();

main()
{
  int x=VERIFIERnondetint();
  int y=VERIFIERnondetint();

  if (y>0)
  {
    while(x<100)
    {
      x=x+y;
     }
  }

  _TRACER_abort(! ( y<=0 || (y>0 && x>=100) ));
}
