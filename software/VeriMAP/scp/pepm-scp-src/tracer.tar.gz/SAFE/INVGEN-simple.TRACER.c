# 1 "INVGEN-simple.map.tmp.c"
# 1 "<command-line>"
# 1 "INVGEN-simple.map.tmp.c"
# 1 "MAP/SAFE-exbench/INVGEN-simple.tmp.c"
# 1 "<command-line>"
# 1 "MAP/SAFE-exbench/INVGEN-simple.tmp.c"
# 20 "MAP/SAFE-exbench/INVGEN-simple.tmp.c"
void main() {
  int x=0;
  int n;

  _TRACER_assume( n > 0 );
  while( x < n ){
    x++;
  }
  _TRACER_abort(! ( x<=n ));
}
