# 1 "INVGEN-fragtest_simple.map.tmp.c"
# 1 "<command-line>"
# 1 "INVGEN-fragtest_simple.map.tmp.c"
# 1 "MAP/SAFE-exbench/INVGEN-fragtestsimple.tmp.c"
# 1 "<command-line>"
# 1 "MAP/SAFE-exbench/INVGEN-fragtestsimple.tmp.c"
# 20 "MAP/SAFE-exbench/INVGEN-fragtestsimple.tmp.c"
int BLASTNONDET;

void main(){
  int i,pvlen ;
  int tmp1 ;
  int k = 0;
  int n;

  i = 0;


  while ( BLASTNONDET )
    i = i + 1;
  if (i > pvlen) {
    pvlen = i;
  } else {

  }
  i = 0;

  while ( BLASTNONDET ) {
    tmp1 = i;
    i = i + 1;
    k = k +1;
  }
  while ( BLASTNONDET );

  int j = 0;
  n = i;

  while (1) {

    _TRACER_abort(! ( k >= 0 ));
    k = k -1;
    i = i - 1;
    j = j + 1;
    if (j < n) {

    } else {
      break;
    }
    }
  return;

}
