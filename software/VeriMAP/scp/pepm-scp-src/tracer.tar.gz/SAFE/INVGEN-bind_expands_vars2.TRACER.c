# 1 "INVGEN-bind_expands_vars2.map.tmp.c"
# 1 "<command-line>"
# 1 "INVGEN-bind_expands_vars2.map.tmp.c"
# 1 "MAP/SAFE-exbench/INVGEN-bindexpandsvars2.tmp.c"
# 1 "<command-line>"
# 1 "MAP/SAFE-exbench/INVGEN-bindexpandsvars2.tmp.c"
# 20 "MAP/SAFE-exbench/INVGEN-bindexpandsvars2.tmp.c"
int main() {

  int cp1off, n1, n2, mci;
  int MAXDATA;
  if (MAXDATA > 0 ); else goto END;

  if ((n1 <= MAXDATA * 2)); else goto END;

  if ((cp1off <= n1)); else goto END;

  if ((n2 <= MAXDATA*2 - n1)); else goto END;

  for (mci = 0; mci < n2; mci++) {

    _TRACER_abort(! ( cp1off+mci < MAXDATA * 2 ));

  }



 END: return 0;
}
