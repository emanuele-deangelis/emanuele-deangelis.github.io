# 1 "SVCOMP13-loops-sum03_safe.map.tmp.c"
# 1 "<command-line>"
# 1 "SVCOMP13-loops-sum03_safe.map.tmp.c"
# 1 "MAP/SAFE-exbench/SVCOMP13-loops-sum03safe.tmp.c"
# 1 "<command-line>"
# 1 "MAP/SAFE-exbench/SVCOMP13-loops-sum03safe.tmp.c"
# 18 "MAP/SAFE-exbench/SVCOMP13-loops-sum03safe.tmp.c"
void commentedOutVERIFIERassert(int cond) {
  if (!(cond)) {
    ERROR: _TRACER_abort(1); goto ERROR;
  }
  return;
}

unsigned int VERIFIERnondetuint();

int main() {
  int sn=0;
  unsigned int loop1=VERIFIERnondetuint(), n1=VERIFIERnondetuint();
  unsigned int x=0;

  while(1){
    sn = sn + (2);
    x++;
    _TRACER_abort(! ( sn==x*(2) || sn == 0 ));
  }
}
