# 1 "MAP-interpolants_needed-pepm-proc.map.c.tmp.c"
# 1 "<command-line>"
# 1 "MAP-interpolants_needed-pepm-proc.map.c.tmp.c"
# 24 "MAP-interpolants_needed-pepm-proc.map.c.tmp.c"
int main(){

 int x=0;
 int y=0;

 while (VERIFIERnondetint()) {
  if (VERIFIERnondetint()) {
   x = x+1;
   y = y+2;
  } else if (VERIFIERnondetint()) {
   if (x >= 4) {
       x = x+1;
       y = y+3;
   }
  }
 }

    if(3*x < y)
  goto ERROR;

 return 0;
ERROR: _TRACER_abort(1);
 return -1;
}
