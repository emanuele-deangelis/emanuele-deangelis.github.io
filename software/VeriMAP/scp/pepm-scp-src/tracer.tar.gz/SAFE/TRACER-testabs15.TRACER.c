# 1 "TRACER-testabs15.map.tmp.c"
# 1 "<command-line>"
# 1 "TRACER-testabs15.map.tmp.c"
# 1 "MAP/SAFE-exbench/TRACER-testabs15.tmp.c"
# 1 "<command-line>"
# 1 "MAP/SAFE-exbench/TRACER-testabs15.tmp.c"
# 28 "MAP/SAFE-exbench/TRACER-testabs15.tmp.c"
main(int n){
  int i, a, b;
  int TRACERNONDET;

  if(n >=0){

    i=0; a=0; b=0;

    while (i < n){
      if (TRACERNONDET){
 a=a+1;
 b=b+2;
      }
      else{
 a=a+2;
 b=b+1;
      }
      i++;
    }
    _TRACER_abort(! ( !( a+b != 3*n ) ));
  }
}
