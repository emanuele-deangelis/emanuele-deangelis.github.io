# 1 "INVGEN-gulwani_cegar1.map.tmp.c"
# 1 "<command-line>"
# 1 "INVGEN-gulwani_cegar1.map.tmp.c"
# 1 "MAP/SAFE-exbench/INVGEN-gulwanicegar1.tmp.c"
# 1 "<command-line>"
# 1 "MAP/SAFE-exbench/INVGEN-gulwanicegar1.tmp.c"
# 20 "MAP/SAFE-exbench/INVGEN-gulwanicegar1.tmp.c"
int BLASTNONDET;
void main() {
  int x,y;

  _TRACER_assume( 0 <= x ); _TRACER_assume( x <= 2 );
  _TRACER_assume( 0 <= y ); _TRACER_assume( y <= 2 );
  while( BLASTNONDET ) {
 x+=2;
 y+=2;
  }
  if( y >= 0 )
    if( y <= 0 )
      if( 4 <= x )
 _TRACER_abort(! ( x < 4 ));
}
