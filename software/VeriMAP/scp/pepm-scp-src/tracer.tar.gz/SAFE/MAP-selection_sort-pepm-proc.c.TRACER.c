# 1 "MAP-selection_sort-pepm-proc.map.c.tmp.c"
# 1 "<command-line>"
# 1 "MAP-selection_sort-pepm-proc.map.c.tmp.c"
# 24 "MAP-selection_sort-pepm-proc.map.c.tmp.c"
int main(){

int n;
int i=0;
int j=0;
int min=0;

 _TRACER_assume( n>=0 );

 while (i < n-1) {

  min = i;

  j=i+1;

  while (j < n) {

   if( j >= n || -1 >= j || min >= n || -1 >= min )
    goto ERROR;

   if (VERIFIERnondetint()) {
    min = j;
   }

   if ( i != min) {

    if( i >= n || -1 >= i || min >= n || -1 >= min )
     goto ERROR;
   }

   j=j+1;

  }

  i=i+1;
 }

 return 0;
ERROR: _TRACER_abort(1);
 return -1;
}
