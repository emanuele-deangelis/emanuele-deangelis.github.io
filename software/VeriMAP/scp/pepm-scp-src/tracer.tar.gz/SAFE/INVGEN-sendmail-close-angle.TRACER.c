# 1 "INVGEN-sendmail-close-angle.map.tmp.c"
# 1 "<command-line>"
# 1 "INVGEN-sendmail-close-angle.map.tmp.c"
# 1 "MAP/SAFE-exbench/INVGEN-sendmail-close-angle.tmp.c"
# 1 "<command-line>"
# 1 "MAP/SAFE-exbench/INVGEN-sendmail-close-angle.tmp.c"
# 25 "MAP/SAFE-exbench/INVGEN-sendmail-close-angle.tmp.c"
int main (void)
{






  int BLASTNONDET;
  int in;
  int inlen;
  int bufferlen;
  int buf;
  int buflim;


  ;

  if(bufferlen >1);else goto END;
  if(inlen > 0);else goto END;
  if(bufferlen < inlen);else goto END;




  buf = 0;
  in = 0;
  buflim = bufferlen - 2;



  while (BLASTNONDET)
  {
    if (buf == buflim)
      break;
    _TRACER_abort(! ( 0<=buf ));
    _TRACER_abort(! ( buf<bufferlen ));

    buf++;
out:
    in++;
    _TRACER_abort(! ( 0<=in ));
    _TRACER_abort(! ( in<inlen ));

  }

    _TRACER_abort(! ( 0<=buf ));
    _TRACER_abort(! ( buf<bufferlen ));

  buf++;


  _TRACER_abort(! ( 0<=buf ));
  _TRACER_abort(! ( buf<bufferlen ));


  buf++;

 END: return 0;
}
