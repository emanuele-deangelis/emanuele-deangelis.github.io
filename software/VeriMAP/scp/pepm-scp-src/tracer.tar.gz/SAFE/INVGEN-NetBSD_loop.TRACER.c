# 1 "INVGEN-NetBSD_loop.map.tmp.c"
# 1 "<command-line>"
# 1 "INVGEN-NetBSD_loop.map.tmp.c"
# 1 "MAP/SAFE-exbench/INVGEN-NetBSDloop.tmp.c"
# 1 "<command-line>"
# 1 "MAP/SAFE-exbench/INVGEN-NetBSDloop.tmp.c"
# 20 "MAP/SAFE-exbench/INVGEN-NetBSDloop.tmp.c"
int BLASTNONDET;


int main ()
{


  int MAXPATHLEN;
  int pathbufoff;


  int boundoff;



  int glob2poff;
  int glob2pathbufoff;
  int glob2pathlimoff;

  if(MAXPATHLEN > 0); else goto END;

  pathbufoff = 0;
  boundoff = pathbufoff + (MAXPATHLEN + 1) - 1;
# 51 "MAP/SAFE-exbench/INVGEN-NetBSDloop.tmp.c"
  glob2pathbufoff = pathbufoff;
  glob2pathlimoff = boundoff;

  for (glob2poff = glob2pathbufoff;
      glob2poff <= glob2pathlimoff;
      glob2poff++) {


    _TRACER_abort(! ( 0 <= glob2poff )); _TRACER_abort(! ( glob2poff < MAXPATHLEN + 1 ));

  }






 END: return 0;
}
