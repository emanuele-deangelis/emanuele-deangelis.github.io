# 1 "INVGEN-SpamAssassin-loop_ok.map.tmp.c"
# 1 "<command-line>"
# 1 "INVGEN-SpamAssassin-loop_ok.map.tmp.c"
# 1 "MAP/SAFE-exbench/INVGEN-SpamAssassin-loopok.tmp.c"
# 1 "<command-line>"
# 1 "MAP/SAFE-exbench/INVGEN-SpamAssassin-loopok.tmp.c"
# 22 "MAP/SAFE-exbench/INVGEN-SpamAssassin-loopok.tmp.c"
int BLASTNONDET;

void main ()
{
  int len;
  int i;
  int j;

  int bufsize;
  int limit = bufsize - 4;

  ;

  for (i = 0; i < len; ) {
    for (j = 0; i < len && j < limit; ){
      if (i + 1 < len){


 if( BLASTNONDET ) goto ELSE;





        j++;
        i++;






        j++;
        i++;




        j++;
      } else {
ELSE:

 _TRACER_abort(! ( 0<=i ));




        j++;
        i++;
      }
    }
  }
}
