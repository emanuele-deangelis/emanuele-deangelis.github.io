# 1 "INVGEN-up-nested.map.tmp.c"
# 1 "<command-line>"
# 1 "INVGEN-up-nested.map.tmp.c"
# 1 "MAP/SAFE-exbench/INVGEN-up-nested.tmp.c"
# 1 "<command-line>"
# 1 "MAP/SAFE-exbench/INVGEN-up-nested.tmp.c"
# 20 "MAP/SAFE-exbench/INVGEN-up-nested.tmp.c"
int NONDET;

void main() {
  int n,j,i,k;

  ;
  i = 0;
  k = 0;

  _TRACER_assume( j<=n );
  while ( j <= n ) {



    _TRACER_assume( i >= 0 );
# 43 "MAP/SAFE-exbench/INVGEN-up-nested.tmp.c"
    j++;
  }
  _TRACER_abort(! ( i>= 0 ));
# 55 "MAP/SAFE-exbench/INVGEN-up-nested.tmp.c"
}
