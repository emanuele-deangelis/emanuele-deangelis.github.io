# 1 "INVGEN-sendmail-mime-fromqp.map.tmp.c"
# 1 "<command-line>"
# 1 "INVGEN-sendmail-mime-fromqp.map.tmp.c"
# 1 "MAP/SAFE-exbench/INVGEN-sendmail-mime-fromqp.tmp.c"
# 1 "<command-line>"
# 1 "MAP/SAFE-exbench/INVGEN-sendmail-mime-fromqp.tmp.c"
# 20 "MAP/SAFE-exbench/INVGEN-sendmail-mime-fromqp.tmp.c"
int BLASTNONDET;

int main (void)
{
  int outfilelen;
# 33 "MAP/SAFE-exbench/INVGEN-sendmail-mime-fromqp.tmp.c"
  int nchar = 0;

  int out = 0;

  ;

  if(outfilelen > 0); else goto RETURN;


  while(BLASTNONDET)
  {

    if(BLASTNONDET)
    {


      if(BLASTNONDET)


 goto AFTERLOOP;




      if(BLASTNONDET)
      {
 out = 0;
 nchar = 0;
 goto LOOPEND;
      }
      else
      {




 if(BLASTNONDET) goto AFTERLOOP;

 nchar++;
 if (nchar >= outfilelen)
   goto AFTERLOOP;


 _TRACER_abort(! ( 0<=out ));
 _TRACER_abort(! ( out<outfilelen ));

 out++;
      }
    }
    else
    {


      nchar++;
      if (nchar >= outfilelen)
 goto AFTERLOOP;


      _TRACER_abort(! ( 0<=out ));
      _TRACER_abort(! ( out<outfilelen ));

      out++;


      if(BLASTNONDET) goto AFTERLOOP;
    }
  LOOPEND:
  }
 AFTERLOOP:


  _TRACER_abort(! ( 0<=out ));
  _TRACER_abort(! ( out<outfilelen ));

  out++;
 RETURN: return 0;
}
