# 1 "TRACER-testloop28-unsafe.map.tmp.c"
# 1 "<command-line>"
# 1 "TRACER-testloop28-unsafe.map.tmp.c"
# 1 "MAP/SAFE-exbench/TRACER-testloop28.tmp.c"
# 1 "<command-line>"
# 1 "MAP/SAFE-exbench/TRACER-testloop28.tmp.c"
# 20 "MAP/SAFE-exbench/TRACER-testloop28.tmp.c"
extern int unknown();
main() {
 int varByTheMAPgroup = 42;
int i,n,x, NONDET;

  x=0;
  i=0;
  while (i<n) {
    if (unknown() >0){
      assert( !( x>0 ) );
    }
    else{
      x = 1;
    }
    i++;
  }
}
