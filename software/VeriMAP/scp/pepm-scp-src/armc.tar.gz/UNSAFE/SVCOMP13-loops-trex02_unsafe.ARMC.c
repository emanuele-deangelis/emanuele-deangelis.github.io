# 1 "SVCOMP13-loops-trex02_unsafe.map.tmp.c"
# 1 "<command-line>"
# 1 "SVCOMP13-loops-trex02_unsafe.map.tmp.c"
# 1 "MAP/UNSAFE-exbench/SVCOMP13-loops-trex02_unsafe.tmp.c"
# 1 "<command-line>"
# 1 "MAP/UNSAFE-exbench/SVCOMP13-loops-trex02_unsafe.tmp.c"
# 18 "MAP/UNSAFE-exbench/SVCOMP13-loops-trex02_unsafe.tmp.c"
void assert( int cond ) {
  if (!(cond)) {
    ERROR: goto ERROR;
  }
  return;
}
_Bool __VERIFIER_nondet_bool();
int __VERIFIER_nondet_int();


int x;

void foo() {
  x--;
}

int main() {
 int varByTheMAPgroup = 42;
x=__VERIFIER_nondet_int();
  while (x > 0) {
    _Bool c = __VERIFIER_nondet_bool();
    if(c) foo();
    else foo();
  }
  assert( x==0 );
}
