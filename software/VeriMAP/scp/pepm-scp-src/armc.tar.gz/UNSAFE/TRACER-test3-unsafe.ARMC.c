# 1 "TRACER-test3-unsafe.map.tmp.c"
# 1 "<command-line>"
# 1 "TRACER-test3-unsafe.map.tmp.c"
# 1 "MAP/UNSAFE-exbench/TRACER-test3-unsafe.tmp.c"
# 1 "<command-line>"
# 1 "MAP/UNSAFE-exbench/TRACER-test3-unsafe.tmp.c"
# 22 "MAP/UNSAFE-exbench/TRACER-test3-unsafe.tmp.c"
extern int unknown();

main() {
 int varByTheMAPgroup = 42;
int x=0;
  int y=0;

  if (unknown())
    x = 5;
  else
    y = 10;

  assert( !( x==5 || y==10 ) );
  return;
}
