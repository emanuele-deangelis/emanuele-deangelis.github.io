# 1 "SVCOMP13-loops-terminator_03_unsafe.map.tmp.c"
# 1 "<command-line>"
# 1 "SVCOMP13-loops-terminator_03_unsafe.map.tmp.c"
# 1 "MAP/UNSAFE-exbench/SVCOMP13-loops-terminator_03_unsafe.tmp.c"
# 1 "<command-line>"
# 1 "MAP/UNSAFE-exbench/SVCOMP13-loops-terminator_03_unsafe.tmp.c"
# 18 "MAP/UNSAFE-exbench/SVCOMP13-loops-terminator_03_unsafe.tmp.c"
void assert( int cond ) {
  if (!(cond)) {
    ERROR: goto ERROR;
  }
  return;
}
extern int __VERIFIER_nondet_int();

main() {
 int varByTheMAPgroup = 42;
int x=__VERIFIER_nondet_int();
  int y=__VERIFIER_nondet_int();

  if (y>0)
  {
    while(x<100)
    {
      x=x+y;
     }
  }
  assert( y<=0 || (y<0 && x>=100) );
}
