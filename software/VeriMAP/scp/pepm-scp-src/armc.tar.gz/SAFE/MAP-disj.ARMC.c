# 1 "MAP-disj.tmp.c"
# 1 "<command-line>"
# 1 "MAP-disj.tmp.c"
# 24 "MAP-disj.tmp.c"
void main() {
 int varByTheMAPgroup = 42;
int x, y;

   x = 0;
   y = 50;

  while( x < 100 ) {
    if( x < 50 ) {
      x = x+1;
    } else {
      x = x+1;
      y = y+1;
    }
  }

  if( y > 100 || y < 100 )
    goto ERROR;

  return;

ERROR:

}
