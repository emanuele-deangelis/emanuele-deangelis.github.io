# 1 "TRACER-testwp17.map.tmp.c"
# 1 "<command-line>"
# 1 "TRACER-testwp17.map.tmp.c"
# 1 "MAP/SAFE-exbench/TRACER-testwp17.tmp.c"
# 1 "<command-line>"
# 1 "MAP/SAFE-exbench/TRACER-testwp17.tmp.c"
# 19 "MAP/SAFE-exbench/TRACER-testwp17.tmp.c"
main() {
 int varByTheMAPgroup = 42;
int x;
  int NONDET;

  if(NONDET>0)


    x=0;
  else
    x=1;
# 37 "MAP/SAFE-exbench/TRACER-testwp17.tmp.c"
  if (x==0){


    assert( !( x !=0 ) );
  }
}
