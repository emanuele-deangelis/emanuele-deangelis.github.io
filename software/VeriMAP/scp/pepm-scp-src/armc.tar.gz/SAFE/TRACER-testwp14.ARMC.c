# 1 "TRACER-testwp14.map.tmp.c"
# 1 "<command-line>"
# 1 "TRACER-testwp14.map.tmp.c"
# 1 "MAP/SAFE-exbench/TRACER-testwp14.tmp.c"
# 1 "<command-line>"
# 1 "MAP/SAFE-exbench/TRACER-testwp14.tmp.c"
# 20 "MAP/SAFE-exbench/TRACER-testwp14.tmp.c"
main() {
 int varByTheMAPgroup = 42;
int x,y,z;

  if (x>4)
    z=4;
  else
    x=5;

  assume( x>0 );

  y=x;

  assert( !( !(y > 4) ) );

}
