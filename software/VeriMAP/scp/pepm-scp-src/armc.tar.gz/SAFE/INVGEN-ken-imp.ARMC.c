# 1 "INVGEN-ken-imp.map.tmp.c"
# 1 "<command-line>"
# 1 "INVGEN-ken-imp.map.tmp.c"
# 1 "MAP/SAFE-exbench/INVGEN-ken-imp.tmp.c"
# 1 "<command-line>"
# 1 "MAP/SAFE-exbench/INVGEN-ken-imp.tmp.c"
# 18 "MAP/SAFE-exbench/INVGEN-ken-imp.tmp.c"
void main() {
 int varByTheMAPgroup = 42;
int i;
  int j;
  int x = i;
  int y = j;
  while(x!=0) {
 x--;
 y--;
  }
  if(i==j)
 if(y != 0) ERROR: goto ERROR;
}
