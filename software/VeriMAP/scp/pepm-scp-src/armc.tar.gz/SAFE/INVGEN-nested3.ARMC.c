# 1 "INVGEN-nested3.map.tmp.c"
# 1 "<command-line>"
# 1 "INVGEN-nested3.map.tmp.c"
# 1 "MAP/SAFE-exbench/INVGEN-nested3.tmp.c"
# 1 "<command-line>"
# 1 "MAP/SAFE-exbench/INVGEN-nested3.tmp.c"
# 19 "MAP/SAFE-exbench/INVGEN-nested3.tmp.c"
void main() {
 int varByTheMAPgroup = 42;
int i,k,n,l;

  ;

  assume( l>0 );

  for (k=1;k<n;k++){
    for (i=l;i<n;i++) {
      assert( 1<=i );
    }
    for (i=l;i<n;i++) {
    }
  }

 }
