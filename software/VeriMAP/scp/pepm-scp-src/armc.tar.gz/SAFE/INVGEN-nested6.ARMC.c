# 1 "INVGEN-nested6.map.tmp.c"
# 1 "<command-line>"
# 1 "INVGEN-nested6.map.tmp.c"
# 1 "MAP/SAFE-exbench/INVGEN-nested6.tmp.c"
# 1 "<command-line>"
# 1 "MAP/SAFE-exbench/INVGEN-nested6.tmp.c"
# 20 "MAP/SAFE-exbench/INVGEN-nested6.tmp.c"
int __BLAST_NONDET;

void main() {
 int varByTheMAPgroup = 42;
int i,j,k,n;

  if( k == n); else goto END;

  for (i=0;i<n;i++) {
    for (j=2*i;j<n;j++) {
      if( __BLAST_NONDET ) {
 for (k=j;k<n;k++) {
   assert( k>=2*i );
 }
      }
      else {
 assert( k >= n );
 assert( k <= n );
      }
    }
  }
 END:
}
