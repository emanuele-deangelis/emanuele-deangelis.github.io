# 1 "TRACER-testabs12.map.tmp.c"
# 1 "<command-line>"
# 1 "TRACER-testabs12.map.tmp.c"
# 1 "MAP/SAFE-exbench/TRACER-testabs12.tmp.c"
# 1 "<command-line>"
# 1 "MAP/SAFE-exbench/TRACER-testabs12.tmp.c"
# 18 "MAP/SAFE-exbench/TRACER-testabs12.tmp.c"
main() {
 int varByTheMAPgroup = 42;
int i,count,n;

  assume( count >= 0 );
  i=0;


  while (i < 100 ){
      count++;
      i++;
  }

  assert( !( (i > 100 ) || count < 0 ) );
}
