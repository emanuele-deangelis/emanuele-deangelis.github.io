# 1 "MAP-singleloop2-pepm-proc.map.c.tmp.c"
# 1 "<command-line>"
# 1 "MAP-singleloop2-pepm-proc.map.c.tmp.c"
# 24 "MAP-singleloop2-pepm-proc.map.c.tmp.c"
int main() {
 int varByTheMAPgroup = 42;
int x=0;
int y=0;
int n;

 assume( n>=1 );

 while(x < 2*n){
    x = x + 1;

    if ( x > n )
    y = y - 1;
    else
    y = y + 2;
 }

 if(x < y)
  goto ERROR;

 return 0;
ERROR:
 return -1;
}
