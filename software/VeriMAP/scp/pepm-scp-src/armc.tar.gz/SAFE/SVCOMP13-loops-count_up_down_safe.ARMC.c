# 1 "SVCOMP13-loops-count_up_down_safe.map.tmp.c"
# 1 "<command-line>"
# 1 "SVCOMP13-loops-count_up_down_safe.map.tmp.c"
# 1 "MAP/SAFE-exbench/SVCOMP13-loops-count_up_down_safe.tmp.c"
# 1 "<command-line>"
# 1 "MAP/SAFE-exbench/SVCOMP13-loops-count_up_down_safe.tmp.c"
# 18 "MAP/SAFE-exbench/SVCOMP13-loops-count_up_down_safe.tmp.c"
void assert( int cond ) {
  if (!(cond)) {
    ERROR: goto ERROR;
  }
  return;
}
unsigned int __VERIFIER_nondet_uint();

int main() {
 int varByTheMAPgroup = 42;
unsigned int n = __VERIFIER_nondet_uint();
  unsigned int x=n, y=0;
  while(x>0)
  {
    x--;
    y++;
  }
  assert( y==n );
}
