# 1 "INVGEN-SpamAssassin-loop.map.tmp.c"
# 1 "<command-line>"
# 1 "INVGEN-SpamAssassin-loop.map.tmp.c"
# 1 "MAP/SAFE-exbench/INVGEN-SpamAssassin-loop.tmp.c"
# 1 "<command-line>"
# 1 "MAP/SAFE-exbench/INVGEN-SpamAssassin-loop.tmp.c"
# 20 "MAP/SAFE-exbench/INVGEN-SpamAssassin-loop.tmp.c"
int __BLAST_NONDET;

void main () {
 int varByTheMAPgroup = 42;
int len;
  int i;
  int j;

  int bufsize;
  int limit = bufsize - 4;

  ;

  for (i = 0; i < len; ) {
    for (j = 0; i < len && j < limit; ){
      if (i + 1 < len){
 assert( i+1<len );
 assert( 0<=i );
 if( __BLAST_NONDET ) goto ELSE;
        assert( i<len );
 assert( 0<=i );
        assert( j<bufsize );
 assert( 0<=j );

        j++;
        i++;
        assert( i<len );
 assert( 0<=i );
        assert( j<bufsize );
 assert( 0<=j );


        j++;
        i++;
        assert( j<bufsize );
 assert( 0<=j );


        j++;
      } else {
ELSE:
        assert( i<len );
 assert( 0<=i );
        assert( j<bufsize );
 assert( 0<=j );


        j++;
        i++;
      }
    }
  }
}
