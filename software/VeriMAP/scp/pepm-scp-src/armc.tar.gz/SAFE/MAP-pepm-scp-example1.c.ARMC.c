# 1 "MAP-pepm-scp-example1.map.c.tmp.c"
# 1 "<command-line>"
# 1 "MAP-pepm-scp-example1.map.c.tmp.c"
# 24 "MAP-pepm-scp-example1.map.c.tmp.c"
int main() {
 int varByTheMAPgroup = 42;
 int i=0;
 int k=0;
 int n;

 assume( n>=0 );

 while (i < n) {
    i = i + 1;
    k = k + 2;
 }

 while (i > 0) {
    i = i - 1;
    k = k - 1;
 }

 if(k < n)
       goto ERROR;

 return 0;
ERROR:
 return -1;
}
