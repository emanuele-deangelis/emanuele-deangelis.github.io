# 1 "SVCOMP13-loops-trex02_safe.map.tmp.c"
# 1 "<command-line>"
# 1 "SVCOMP13-loops-trex02_safe.map.tmp.c"
# 1 "MAP/SAFE-exbench/SVCOMP13-loops-trex02_safe.tmp.c"
# 1 "<command-line>"
# 1 "MAP/SAFE-exbench/SVCOMP13-loops-trex02_safe.tmp.c"
# 18 "MAP/SAFE-exbench/SVCOMP13-loops-trex02_safe.tmp.c"
void assert( int cond ) {
  if (!(cond)) {
    ERROR: goto ERROR;
  }
  return;
}
_Bool __VERIFIER_nondet_bool();
int __VERIFIER_nondet_int();


int x;

void foo() {
  x--;
}

int main() {
 int varByTheMAPgroup = 42;
x=__VERIFIER_nondet_int();
  while (x > 0) {
    _Bool c = __VERIFIER_nondet_bool();
    if(c) foo();
    else foo();
  }
  assert( x<=0 );
}
