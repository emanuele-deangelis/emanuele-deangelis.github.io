# 1 "SVCOMP13-loops-terminator_02_safe.map.tmp.c"
# 1 "<command-line>"
# 1 "SVCOMP13-loops-terminator_02_safe.map.tmp.c"
# 1 "MAP/SAFE-exbench/SVCOMP13-loops-terminator_02_safe.tmp.c"
# 1 "<command-line>"
# 1 "MAP/SAFE-exbench/SVCOMP13-loops-terminator_02_safe.tmp.c"
# 18 "MAP/SAFE-exbench/SVCOMP13-loops-terminator_02_safe.tmp.c"
extern void assume( int );
void assert( int cond ) {
  if (!(cond)) {
    ERROR: goto ERROR;
  }
  return;
}
int __VERIFIER_nondet_int();
_Bool __VERIFIER_nondet_bool();

main() {
 int varByTheMAPgroup = 42;
int x=__VERIFIER_nondet_int();
  int y=__VERIFIER_nondet_int();
  int z=__VERIFIER_nondet_int();
  assume( x<100 );
  assume( z<100 );
  while(x<100 && 100<z)
  {
    _Bool tmp=__VERIFIER_nondet_bool();
    if (tmp)
   {
     x++;
   }
   else
   {
     x--;
     z--;
   }
  }

  assert( x>=100 || z<=100 );
}
