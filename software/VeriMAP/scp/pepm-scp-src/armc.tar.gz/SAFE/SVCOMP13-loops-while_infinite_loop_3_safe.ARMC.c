# 1 "SVCOMP13-loops-while_infinite_loop_3_safe.map.tmp.c"
# 1 "<command-line>"
# 1 "SVCOMP13-loops-while_infinite_loop_3_safe.map.tmp.c"
# 1 "MAP/SAFE-exbench/SVCOMP13-loops-while_infinite_loop_3_safe.tmp.c"
# 1 "<command-line>"
# 1 "MAP/SAFE-exbench/SVCOMP13-loops-while_infinite_loop_3_safe.tmp.c"
# 18 "MAP/SAFE-exbench/SVCOMP13-loops-while_infinite_loop_3_safe.tmp.c"
void assert( int cond ) {
  if (!(cond)) {
    ERROR: goto ERROR;
  }
  return;
}

int x=0;

void eval(void)
{
  while (1) {
      x=0;
      break;
  }
  return;
}


int main() {
 int varByTheMAPgroup = 42;
while(1)
  {
    eval();
    assert( x==0 );
  }

  assert( x!=0 );

  return 0;
}
