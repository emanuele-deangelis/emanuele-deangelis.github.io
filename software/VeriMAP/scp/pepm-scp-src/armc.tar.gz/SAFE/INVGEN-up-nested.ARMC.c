# 1 "INVGEN-up-nested.map.tmp.c"
# 1 "<command-line>"
# 1 "INVGEN-up-nested.map.tmp.c"
# 1 "MAP/SAFE-exbench/INVGEN-up-nested.tmp.c"
# 1 "<command-line>"
# 1 "MAP/SAFE-exbench/INVGEN-up-nested.tmp.c"
# 20 "MAP/SAFE-exbench/INVGEN-up-nested.tmp.c"
int NONDET;

void main() {
 int varByTheMAPgroup = 42;
int n,j,i,k;

  ;
  i = 0;
  k = 0;

  assume( j<=n );
  while ( j <= n ) {



    assume( i >= 0 );
# 43 "MAP/SAFE-exbench/INVGEN-up-nested.tmp.c"
    j++;
  }
  assert( i>= 0 );
# 55 "MAP/SAFE-exbench/INVGEN-up-nested.tmp.c"
}
