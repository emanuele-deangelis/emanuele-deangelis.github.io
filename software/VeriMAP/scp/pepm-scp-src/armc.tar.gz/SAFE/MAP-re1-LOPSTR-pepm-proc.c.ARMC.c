# 1 "MAP-re1-LOPSTR-pepm-proc.map.c.tmp.c"
# 1 "<command-line>"
# 1 "MAP-re1-LOPSTR-pepm-proc.map.c.tmp.c"
# 24 "MAP-re1-LOPSTR-pepm-proc.map.c.tmp.c"
int main() {
 int varByTheMAPgroup = 42;
 int x=0;
 int y=0;
 int n;

 assume( n>=0 );

 while (x < n) {
    x = x + 1;
    y = y + 1;
 }

 while (x > 0) {
    x = x - 1;
    y = y - 1;
 }

 if(y > x)
       goto ERROR;

 return 0;
ERROR:
 return -1;
}
