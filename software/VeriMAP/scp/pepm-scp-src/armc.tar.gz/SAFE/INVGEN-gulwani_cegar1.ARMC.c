# 1 "INVGEN-gulwani_cegar1.map.tmp.c"
# 1 "<command-line>"
# 1 "INVGEN-gulwani_cegar1.map.tmp.c"
# 1 "MAP/SAFE-exbench/INVGEN-gulwani_cegar1.tmp.c"
# 1 "<command-line>"
# 1 "MAP/SAFE-exbench/INVGEN-gulwani_cegar1.tmp.c"
# 20 "MAP/SAFE-exbench/INVGEN-gulwani_cegar1.tmp.c"
int __BLAST_NONDET;
void main() {
 int varByTheMAPgroup = 42;
int x,y;

  assume( 0 <= x ); assume( x <= 2 );
  assume( 0 <= y ); assume( y <= 2 );
  while( __BLAST_NONDET ) {
 x+=2;
 y+=2;
  }
  if( y >= 0 )
    if( y <= 0 )
      if( 4 <= x )
 assert( x < 4 );
}
