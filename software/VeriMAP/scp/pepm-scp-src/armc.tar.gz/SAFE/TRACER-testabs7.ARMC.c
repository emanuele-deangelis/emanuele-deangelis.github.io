# 1 "TRACER-testabs7.map.tmp.c"
# 1 "<command-line>"
# 1 "TRACER-testabs7.map.tmp.c"
# 1 "MAP/SAFE-exbench/TRACER-testabs7.tmp.c"
# 1 "<command-line>"
# 1 "MAP/SAFE-exbench/TRACER-testabs7.tmp.c"
# 31 "MAP/SAFE-exbench/TRACER-testabs7.tmp.c"
main(int n) {
 int varByTheMAPgroup = 42;
int i;

  i=0;n=10;
# 43 "MAP/SAFE-exbench/TRACER-testabs7.tmp.c"
  while (i < n){ i++; }

  assert( !( i>10 ) );

}
