# 1 "TRACER-testfunc14.map.tmp.c"
# 1 "<command-line>"
# 1 "TRACER-testfunc14.map.tmp.c"
# 1 "MAP/SAFE-exbench/TRACER-testfunc14.tmp.c"
# 1 "<command-line>"
# 1 "MAP/SAFE-exbench/TRACER-testfunc14.tmp.c"
# 23 "MAP/SAFE-exbench/TRACER-testfunc14.tmp.c"
extern int unknown();

void bar(){
  int i,NONDET,q,z;
  i=0;

  if (q>0) z=4;
  else z=5;

  while (NONDET){
    i++;
  }
  return;
}

main() {
 int varByTheMAPgroup = 42;
int p,x;

  if (p>0) x=1;
  else x=3;

  bar();

  assert( !( x==2 ) );

}
