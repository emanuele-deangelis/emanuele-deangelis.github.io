# 1 "INVGEN-NetBSD_glob3_iny.map.tmp.c"
# 1 "<command-line>"
# 1 "INVGEN-NetBSD_glob3_iny.map.tmp.c"
# 1 "MAP/SAFE-exbench/INVGEN-NetBSD_glob3_iny.tmp.c"
# 1 "<command-line>"
# 1 "MAP/SAFE-exbench/INVGEN-NetBSD_glob3_iny.tmp.c"
# 20 "MAP/SAFE-exbench/INVGEN-NetBSD_glob3_iny.tmp.c"
int __BLAST_NONDET;

int main () {
 int varByTheMAPgroup = 42;
int buf_off, pattern_off, bound_off;

  int MAXPATHLEN;





  int error;

  int pathbuf_off;
  int pathend_off;
  int pathlim_off;





  if(MAXPATHLEN >0); else goto END;

  buf_off = 0;
  pattern_off = 0;

  bound_off = MAXPATHLEN;
# 67 "MAP/SAFE-exbench/INVGEN-NetBSD_glob3_iny.tmp.c"
  pathbuf_off = 0;
  pathend_off = 0;
  pathlim_off = MAXPATHLEN;



  error = 0;


  while (__BLAST_NONDET) {
    int i;


    assert( 0 <= pattern_off ); assert( pattern_off <= MAXPATHLEN );

      if (__BLAST_NONDET) continue;




    i = 0;
    for (;;)
      if (i > MAXPATHLEN) goto END;
      else {
 assert( 0 <= i ); assert( i <= MAXPATHLEN );

        i++;
        if (__BLAST_NONDET) goto END;
      }




    assert( 0 <= pathlim_off ); assert( pathlim_off <= MAXPATHLEN );


    if (i > MAXPATHLEN){
      if ( __BLAST_NONDET ) {





 if ( __BLAST_NONDET ) {
   error = 5;
   goto END;
 }
 else {

   assert( 0 <= i );assert( i <= MAXPATHLEN + 1 );

   continue;
 }
      }
    }





    if ( __BLAST_NONDET) {

      assert( i <= MAXPATHLEN + 1 );

      continue;
    }
  END_LOOP1:
  }



 END: return 0;
}
