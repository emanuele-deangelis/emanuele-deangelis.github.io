# 1 "TRACER-testwp16.map.tmp.c"
# 1 "<command-line>"
# 1 "TRACER-testwp16.map.tmp.c"
# 1 "MAP/SAFE-exbench/TRACER-testwp16.tmp.c"
# 1 "<command-line>"
# 1 "MAP/SAFE-exbench/TRACER-testwp16.tmp.c"
# 21 "MAP/SAFE-exbench/TRACER-testwp16.tmp.c"
main() {
 int varByTheMAPgroup = 42;
int t,x2,x3,temp;


  t = 1;
  x2 = temp;
  x3 = temp;



  if (x2 == 0){

    if (x3 == 3)
      t++;
  }


  t++;

  assert( !(t>1000) );

}
