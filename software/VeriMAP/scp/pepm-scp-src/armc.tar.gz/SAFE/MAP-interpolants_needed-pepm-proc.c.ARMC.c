# 1 "MAP-interpolants_needed-pepm-proc.map.c.tmp.c"
# 1 "<command-line>"
# 1 "MAP-interpolants_needed-pepm-proc.map.c.tmp.c"
# 24 "MAP-interpolants_needed-pepm-proc.map.c.tmp.c"
int main() {
 int varByTheMAPgroup = 42;
 int x=0;
 int y=0;

 while (__VERIFIER_nondet_int()) {
  if (__VERIFIER_nondet_int()) {
   x = x+1;
   y = y+2;
  } else if (__VERIFIER_nondet_int()) {
   if (x >= 4) {
       x = x+1;
       y = y+3;
   }
  }
 }

    if(3*x < y)
  goto ERROR;

 return 0;
ERROR:
 return -1;
}
