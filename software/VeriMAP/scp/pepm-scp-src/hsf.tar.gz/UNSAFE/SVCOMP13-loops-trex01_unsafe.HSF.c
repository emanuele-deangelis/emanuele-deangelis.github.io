# 1 "SVCOMP13-loops-trex01_unsafe.map.tmp.c"
# 1 "<command-line>"
# 1 "SVCOMP13-loops-trex01_unsafe.map.tmp.c"
# 1 "MAP/UNSAFE-exbench/SVCOMP13-loops-trex01_unsafe.tmp.c"
# 1 "<command-line>"
# 1 "MAP/UNSAFE-exbench/SVCOMP13-loops-trex01_unsafe.tmp.c"
# 18 "MAP/UNSAFE-exbench/SVCOMP13-loops-trex01_unsafe.tmp.c"
void commentedOutVERIFIERassert(int cond) {
  if (!(cond)) {
    ERROR: goto ERROR;
  }
  return 0;
}
_Bool __VERIFIER_nondet_bool();

void f(int d) {
  int x, y, k, z = 1;
  L1:
  while (z < k) { z = 2 * z; }
  if ( z>=2 ) ; else errorFn();;
  L2:
  while (x > 0 && y > 0) {
    _Bool c = __VERIFIER_nondet_bool();
    if (c) {
      P1:
      x = x - d;
      y = __VERIFIER_nondet_bool();
      z = z - 1;
    } else {
      y = y - d;
    }
  }
}

void main() {
  _Bool c = __VERIFIER_nondet_bool();
  if (c) {
    f(1);
  } else {
    f(2);
  }
}
