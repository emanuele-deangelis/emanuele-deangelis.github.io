# 1 "TRACER-test1-unsafe.map.tmp.c"
# 1 "<command-line>"
# 1 "TRACER-test1-unsafe.map.tmp.c"
# 1 "MAP/UNSAFE-exbench/TRACER-test1-unsafe.tmp.c"
# 1 "<command-line>"
# 1 "MAP/UNSAFE-exbench/TRACER-test1-unsafe.tmp.c"
# 20 "MAP/UNSAFE-exbench/TRACER-test1-unsafe.tmp.c"
extern int unknown();
int main(){
  int x = 0;

  if (unknown()) x = x+1;

  if ( !( x > 1 ) ) ; else errorFn();;

  if (unknown()) x = x+2;

  if ( !( x > 3 ) ) ; else errorFn();;

  if (unknown()) x = x+4;

  if ( !( x >= 7 ) ) ; else errorFn();;
  return x;
}
