# 1 "TRACER-testwp1-unsafe.map.tmp.c"
# 1 "<command-line>"
# 1 "TRACER-testwp1-unsafe.map.tmp.c"
# 1 "MAP/SAFE-exbench/TRACER-testwp1.tmp.c"
# 1 "<command-line>"
# 1 "MAP/SAFE-exbench/TRACER-testwp1.tmp.c"
# 20 "MAP/SAFE-exbench/TRACER-testwp1.tmp.c"
main()
{
  int x, y, z;

        if (x>0)
          z = 2;
        else
          x = -1;


        if (y>0)

          z = 3;
        else

          y = 1;

  if ( !( x+y<=0 ) ) ; else errorFn();;
}
