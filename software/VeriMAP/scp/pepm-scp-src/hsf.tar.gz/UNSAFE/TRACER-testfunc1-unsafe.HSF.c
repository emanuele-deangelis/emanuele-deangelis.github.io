# 1 "TRACER-testfunc1-unsafe.map.tmp.c"
# 1 "<command-line>"
# 1 "TRACER-testfunc1-unsafe.map.tmp.c"
# 1 "MAP/UNSAFE-exbench/TRACER-testfunc1-unsafe.tmp.c"
# 1 "<command-line>"
# 1 "MAP/UNSAFE-exbench/TRACER-testfunc1-unsafe.tmp.c"
# 20 "MAP/UNSAFE-exbench/TRACER-testfunc1-unsafe.tmp.c"
int f1(int w)
{
    int z;
    z = w + 3;
    return z;
}

int f2(int w1)
{
  int z1;
  z1 = w1 + 5;
  return z1;
}

void main()
{
  int x,a,b,arbit;

  if (arbit) {
    a = f1(x);
    b = a - x - 3;
  }
  else {
    a = f2(x);
    b = a - x - 5;
  }

  if ( !( b == 0 ) ) ; else errorFn();;
  return 0;
}
