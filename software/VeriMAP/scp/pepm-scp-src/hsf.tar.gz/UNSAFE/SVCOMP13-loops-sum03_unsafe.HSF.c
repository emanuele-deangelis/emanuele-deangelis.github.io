# 1 "SVCOMP13-loops-sum03_unsafe.map.tmp.c"
# 1 "<command-line>"
# 1 "SVCOMP13-loops-sum03_unsafe.map.tmp.c"
# 1 "MAP/UNSAFE-exbench/SVCOMP13-loops-sum03_unsafe.tmp.c"
# 1 "<command-line>"
# 1 "MAP/UNSAFE-exbench/SVCOMP13-loops-sum03_unsafe.tmp.c"
# 18 "MAP/UNSAFE-exbench/SVCOMP13-loops-sum03_unsafe.tmp.c"
void commentedOutVERIFIERassert(int cond) {
  if (!(cond)) {
    ERROR: goto ERROR;
  }
  return 0;
}

extern unsigned int __VERIFIER_nondet_uint();

int main() {
  int sn=0;
  unsigned int loop1=__VERIFIER_nondet_uint(), n1=__VERIFIER_nondet_uint();
  unsigned int x=0;

  while(1){
    if (x<10)
      sn = sn + (2);
    x++;
    if ( sn==x*(2) || sn == 0 ) ; else errorFn();;
  }
}
