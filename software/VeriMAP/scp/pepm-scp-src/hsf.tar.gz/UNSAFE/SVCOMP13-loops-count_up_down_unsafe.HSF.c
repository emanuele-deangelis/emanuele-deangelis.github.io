# 1 "SVCOMP13-loops-count_up_down_unsafe.map.tmp.c"
# 1 "<command-line>"
# 1 "SVCOMP13-loops-count_up_down_unsafe.map.tmp.c"
# 1 "MAP/UNSAFE-exbench/SVCOMP13-loops-count_up_down_unsafe.tmp.c"
# 1 "<command-line>"
# 1 "MAP/UNSAFE-exbench/SVCOMP13-loops-count_up_down_unsafe.tmp.c"
# 18 "MAP/UNSAFE-exbench/SVCOMP13-loops-count_up_down_unsafe.tmp.c"
void commentedOutVERIFIERassert(int cond) {
  if (!(cond)) {
    ERROR: goto ERROR;
  }
  return 0;
}
unsigned int __VERIFIER_nondet_uint();

int main()
{
  unsigned int n = __VERIFIER_nondet_uint();
  unsigned int x=n, y=0;
  while(x>0)
  {
    x--;
    y++;
  }
  if ( y!=n ) ; else errorFn();;
}
