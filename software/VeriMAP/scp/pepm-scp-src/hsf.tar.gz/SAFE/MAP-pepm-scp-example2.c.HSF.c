# 1 "MAP-pepm-scp-example2.map.c.tmp.c"
# 1 "<command-line>"
# 1 "MAP-pepm-scp-example2.map.c.tmp.c"
# 30 "MAP-pepm-scp-example2.map.c.tmp.c"
int x = 0;
int y = 0;
int n;

void incr(int z)
{
  y = y + z;
}

void main() {

  while (x < n) {
    x = x + 1;
    incr(x);
  }

  if ( x<=y ) ; else errorFn();;

}
