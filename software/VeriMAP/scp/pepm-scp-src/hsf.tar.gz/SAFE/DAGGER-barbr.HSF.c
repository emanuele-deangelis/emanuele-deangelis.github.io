# 1 "DAGGER-barbr.map.tmp.c"
# 1 "<command-line>"
# 1 "DAGGER-barbr.map.tmp.c"
# 1 "MAP/SAFE-exbench/DAGGER-barbr.tmp.c"
# 1 "<command-line>"
# 1 "MAP/SAFE-exbench/DAGGER-barbr.tmp.c"
# 18 "MAP/SAFE-exbench/DAGGER-barbr.tmp.c"
int nondet() {int i; return i;}


int main()
{
 int barber;
 int chair;
 int open;
 int p1;
 int p2;
 int p3;
 int p4;
 int p5;

 barber=0;
 chair=0;
 open=0;
 p1=0;
 p2=0;
 p3=0;
 p4=0;
 p5=0;

 while(nondet())
 {
  if (nondet())
  {
   if (!(p1 >= 0)) return 0;
   if (!(p1 <= 0)) return 0;
   if (!(barber >= 1)) return 0;
   barber = barber-1;
   chair = chair+1;
   p1 = 1;
  }
  else
  {
   if (nondet())
   {
    if (!(p2 >= 0)) return 0;
    if (!(p2 <= 0)) return 0;
    if (!(barber >= 1)) return 0;
    barber = barber-1;
    chair = chair+1;
    p2 = 1;
   }
   else
   {
    if (nondet())
    {
     if (!(p2 >= 1)) return 0;
     if (!(p2 <= 1)) return 0;
     if (!(open >=1)) return 0;
     open = open -1;
     p2 = 0;
    }
    else
    {
     if (nondet())
     {
      if (!(p3>=0)) return 0;
      if (!(p3<=0)) return 0;
      if (!(barber >=1)) return 0;
      barber = barber-1;
      chair = chair +1;
      p3 =1;
     }
     else
     {
      if (nondet())
      {
       if (!(p3>=1)) return 0;
       if (!(p3<=1)) return 0;
       if (!(open >=1)) return 0;
       open = open -1;
       p3 =0;
      }
      else
      {
       if (nondet())
       {
        if (!(p4 >=0)) return 0;
        if (!(p4 <=0)) return 0;
        if (!(barber >=1)) return 0;
        barber= barber-1;
        chair = chair +1;
        p4 = p4+1;
       }
       else
       {
        if (nondet())
        {
         if (! (p4 >=1)) return 0;
         if (! (p4 <=1)) return 0;
         if (! (open >=1)) return 0;
         open = open - 1;
         p4=p4 -1;
        }
        else
        {
         if (nondet())
         {
          if (! (p5>=0)) return 0;
          if (! (p5<=0)) return 0;
          barber=barber+1;
          p5=1;
         }
         else
         {
          if (nondet())
          {
           if (! (p5>=1)) return 0;
           if (! (p5<=1)) return 0;
           if (! (chair >=1)) return 0;
           chair= chair -1;
           p5=2;
          }
          else
          {
           if (nondet())
           {
            if (! (p5>=2)) return 0;
            if (! (p5<=2)) return 0;
            open=open +1;
            p5=3;
           }
           else
           {
            if (nondet())
            {
             if (! (p5 >= 3)) return 0;
             if (! (p5 <= 3)) return 0;
             if (! (open == 0)) return 0;
             p5=0;
            }
             else
            {
             if (! (p1 >= 1)) return 0;
             if (! (p1 <= 1)) return 0;
             if (! (open >= 1)) return 0;
             open = open-1;
             p1 = 0;
            }
           }
          }
         }
        }
       }
      }
     }
    }
   }
  }
 }
 if ( p5 >= open ) ; else errorFn();;
 if ( p1 <= 1 ) ; else errorFn();;
 if ( p2 <= 1 ) ; else errorFn();;
 if ( p3 <= 1 ) ; else errorFn();;
 if ( p4 <= 1 ) ; else errorFn();;
 if ( p5 <= 3 ) ; else errorFn();;
 if ( p4 >= 0 ) ; else errorFn();;
 if ( p3 >= 0 ) ; else errorFn();;
 if ( p2 >= 0 ) ; else errorFn();;
 if ( p1 >= 0 ) ; else errorFn();;
 if ( open >= 0 ) ; else errorFn();;
 if ( chair >= 0 ) ; else errorFn();;
 if ( barber >= 0 ) ; else errorFn();;
}
