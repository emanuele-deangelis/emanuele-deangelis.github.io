# 1 "SVCOMP13-loops-while_infinite_loop_1_safe.map.tmp.c"
# 1 "<command-line>"
# 1 "SVCOMP13-loops-while_infinite_loop_1_safe.map.tmp.c"
# 1 "MAP/SAFE-exbench/SVCOMP13-loops-while_infinite_loop_1_safe.tmp.c"
# 1 "<command-line>"
# 1 "MAP/SAFE-exbench/SVCOMP13-loops-while_infinite_loop_1_safe.tmp.c"
# 18 "MAP/SAFE-exbench/SVCOMP13-loops-while_infinite_loop_1_safe.tmp.c"
void commentedOutVERIFIERassert(int cond) {
  if (!(cond)) {
    ERROR: goto ERROR;
  }
  return 0;
}

int main() {
  int x=0;

  while(1)
  {
    if ( x==0 ) ; else errorFn();;
  }

  if ( x!=0 ) ; else errorFn();;
}
