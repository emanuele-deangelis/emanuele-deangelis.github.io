# 1 "SVCOMP13-loops-for_infinite_loop_2_safe.map.tmp.c"
# 1 "<command-line>"
# 1 "SVCOMP13-loops-for_infinite_loop_2_safe.map.tmp.c"
# 1 "MAP/SAFE-exbench/SVCOMP13-loops-for_infinite_loop_2_safe.tmp.c"
# 1 "<command-line>"
# 1 "MAP/SAFE-exbench/SVCOMP13-loops-for_infinite_loop_2_safe.tmp.c"
# 18 "MAP/SAFE-exbench/SVCOMP13-loops-for_infinite_loop_2_safe.tmp.c"
extern void commentedOutVERIFIERassume(int);
void commentedOutVERIFIERassert(int cond) {
  if (!(cond)) {
    ERROR: goto ERROR;
  }
  return 0;
}

int __VERIFIER_nondet_int();

int main() {
  int i=0, x=0, y=0;
  int n=__VERIFIER_nondet_int();
  assume(n>0);;
  for(i=0; 1; i++)
  {
    if ( x==0 ) ; else errorFn();;
  }
  if ( x!=0 ) ; else errorFn();;
}
