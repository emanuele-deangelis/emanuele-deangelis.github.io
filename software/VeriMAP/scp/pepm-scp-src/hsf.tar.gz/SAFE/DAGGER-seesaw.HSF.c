# 1 "DAGGER-seesaw.map.tmp.c"
# 1 "<command-line>"
# 1 "DAGGER-seesaw.map.tmp.c"
# 1 "MAP/SAFE-exbench/DAGGER-seesaw.tmp.c"
# 1 "<command-line>"
# 1 "MAP/SAFE-exbench/DAGGER-seesaw.tmp.c"
# 18 "MAP/SAFE-exbench/DAGGER-seesaw.tmp.c"
int nondet() {int i; return i; }


int main()
{
 int x;
 int y;

 if (! (x==0)) return 0;
 if (! (y==0)) return 0;

 while (nondet())
 {
  if (nondet())
  {
   if (! (x >= 9)) return 0;
   x = x + 2;
   y = y + 1;
  }
  else
  {
   if (nondet())
   {
    if (!(x >= 7)) return 0;
    if (!(x <= 9)) return 0;
    x = x + 1;
    y = y + 3;
   }
   else
   {
    if (nondet())
    {
     if (! (x - 5 >=0)) return 0;
     if (! (x - 7 <=0)) return 0;
     x = x + 2;
     y = y + 1;
    }
    else
    {
     if (!(x - 4 <=0)) return 0;
     x = x + 1;
     y = y + 2;
    }
   }
  }
 }
 if ( -x + 2*y >= 0 ) ; else errorFn();;
 if ( 3*x - y >= 0 ) ; else errorFn();;
}
