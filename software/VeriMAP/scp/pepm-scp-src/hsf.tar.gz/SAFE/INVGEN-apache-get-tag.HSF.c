# 1 "INVGEN-apache-get-tag.map.tmp.c"
# 1 "<command-line>"
# 1 "INVGEN-apache-get-tag.map.tmp.c"
# 1 "MAP/SAFE-exbench/INVGEN-apache-get-tag.tmp.c"
# 1 "<command-line>"
# 1 "MAP/SAFE-exbench/INVGEN-apache-get-tag.tmp.c"
# 19 "MAP/SAFE-exbench/INVGEN-apache-get-tag.tmp.c"
void main()
{
  int tagbuf_len;
  int t;
  int __BLAST_NONDET;

  ;


  if(tagbuf_len >= 1); else goto END;

  t = 0;

  --tagbuf_len;
# 55 "MAP/SAFE-exbench/INVGEN-apache-get-tag.tmp.c"
  while (1) {
    if (t == tagbuf_len) {
      if ( 0 <= t ) ; else errorFn();;
      if ( t <= tagbuf_len ) ; else errorFn();;

      goto END;
    }
    if (__BLAST_NONDET) {
      break;
    }
     if ( 0 <= t ) ; else errorFn();;
     if ( t <= tagbuf_len ) ; else errorFn();;

    t++;

  }

   if ( 0 <= t ) ; else errorFn();;
   if ( t <= tagbuf_len ) ; else errorFn();;

  t++;
# 94 "MAP/SAFE-exbench/INVGEN-apache-get-tag.tmp.c"
  while (1) {

    if (t == tagbuf_len) {
      if ( 0 <= t ) ; else errorFn();;
      if ( t <= tagbuf_len ) ; else errorFn();;

      goto END;
    }

    if (__BLAST_NONDET) {

      if ( __BLAST_NONDET) {

  if ( 0 <= t ) ; else errorFn();;
 if ( t <= tagbuf_len ) ; else errorFn();;

        t++;
        if (t == tagbuf_len) {

   if ( 0 <= t ) ; else errorFn();;
   if ( t <= tagbuf_len ) ; else errorFn();;

          goto END;
        }
      }
    }
    else if ( __BLAST_NONDET) {
      break;
    }


    if ( 0 <= t ) ; else errorFn();;
    if ( t <= tagbuf_len ) ; else errorFn();;

    t++;

  }

  if ( 0 <= t ) ; else errorFn();;
  if ( t <= tagbuf_len ) ; else errorFn();;


  END:
}
