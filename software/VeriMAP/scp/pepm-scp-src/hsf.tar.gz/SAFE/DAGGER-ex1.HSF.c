# 1 "DAGGER-ex1.map.tmp.c"
# 1 "<command-line>"
# 1 "DAGGER-ex1.map.tmp.c"
# 1 "MAP/SAFE-exbench/DAGGER-ex1.tmp.c"
# 1 "<command-line>"
# 1 "MAP/SAFE-exbench/DAGGER-ex1.tmp.c"
# 18 "MAP/SAFE-exbench/DAGGER-ex1.tmp.c"
int main () {

int x;
int y;
int xa = 0;
int ya = 0;

while (nondet()) {
 x = xa + 2*ya;
 y = -2*xa + ya;

 x++;
 if (nondet()) y = y+x;
 else y = y-x;

 xa = x - 2*y;
 ya = 2*x + y;
}

if ( xa + 2*ya >= 0 ) ; else errorFn();;
return 0;
}
