# 1 "TRACER-testloop7.map.tmp.c"
# 1 "<command-line>"
# 1 "TRACER-testloop7.map.tmp.c"
# 1 "MAP/SAFE-exbench/TRACER-testloop7.tmp.c"
# 1 "<command-line>"
# 1 "MAP/SAFE-exbench/TRACER-testloop7.tmp.c"
# 26 "MAP/SAFE-exbench/TRACER-testloop7.tmp.c"
extern int unknown();

void main()
{
  int x, y;

  y = 0;
  x = 1;
  while ( unknown() < 10) {
    if (x<2) {
      x=2;
    } else {
      x=1;
    }
    if (y<1) {
      y=0;
    }
  }
  if ( !( x > 2 ) ) ; else errorFn();;
  return 0;
}
