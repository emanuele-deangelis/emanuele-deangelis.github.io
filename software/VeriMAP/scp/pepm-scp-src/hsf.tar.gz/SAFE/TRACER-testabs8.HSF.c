# 1 "TRACER-testabs8.map.tmp.c"
# 1 "<command-line>"
# 1 "TRACER-testabs8.map.tmp.c"
# 1 "MAP/SAFE-exbench/TRACER-testabs8.tmp.c"
# 1 "<command-line>"
# 1 "MAP/SAFE-exbench/TRACER-testabs8.tmp.c"
# 34 "MAP/SAFE-exbench/TRACER-testabs8.tmp.c"
main(int n){
  int i;

  i=0;n=10;



  while (i < n){ i++; }

  if ( !( i>10 ) ) ; else errorFn();;

}
