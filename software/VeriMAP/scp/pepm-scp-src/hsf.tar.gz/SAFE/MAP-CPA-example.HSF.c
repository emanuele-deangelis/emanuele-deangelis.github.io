# 1 "MAP-CPA-example.tmp.c"
# 1 "<command-line>"
# 1 "MAP-CPA-example.tmp.c"
# 30 "MAP-CPA-example.tmp.c"
int main() {
  int i = 0;
  int a = 0;

  while (1) {
    if (i == 20) {
       goto LOOPEND;
    } else {
       i++;
       a++;
    }

    if (i != a) {
      goto ERROR;
    }
  }

  LOOPEND:

  if (a != 20) {
     goto ERROR;
  }

  return (0);
  ERROR:
  return (-1);
}
