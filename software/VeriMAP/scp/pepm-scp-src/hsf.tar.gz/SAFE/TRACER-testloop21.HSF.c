# 1 "TRACER-testloop21.map.tmp.c"
# 1 "<command-line>"
# 1 "TRACER-testloop21.map.tmp.c"
# 1 "MAP/SAFE-exbench/TRACER-testloop21.tmp.c"
# 1 "<command-line>"
# 1 "MAP/SAFE-exbench/TRACER-testloop21.tmp.c"
# 25 "MAP/SAFE-exbench/TRACER-testloop21.tmp.c"
void main(){

  int NONDET;
  int i,N;
  int a;
  int x;


  x=0;
  i=0;


  if (NONDET > 0) a=1; else a=2;

 LOOP:
  if (i<N){
    i=i+1;
    goto LOOP;
  }

  if ( !( x >0 ) ) ; else errorFn();;
  return 0;
}
