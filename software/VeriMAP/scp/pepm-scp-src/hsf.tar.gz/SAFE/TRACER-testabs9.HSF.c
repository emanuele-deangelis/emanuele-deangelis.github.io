# 1 "TRACER-testabs9.map.tmp.c"
# 1 "<command-line>"
# 1 "TRACER-testabs9.map.tmp.c"
# 1 "MAP/SAFE-exbench/TRACER-testabs9.tmp.c"
# 1 "<command-line>"
# 1 "MAP/SAFE-exbench/TRACER-testabs9.tmp.c"
# 27 "MAP/SAFE-exbench/TRACER-testabs9.tmp.c"
void main(){

  int x,y;
  y=99;
  x=0;


  if ( !( x<0 ) ) ; else errorFn();;

}
