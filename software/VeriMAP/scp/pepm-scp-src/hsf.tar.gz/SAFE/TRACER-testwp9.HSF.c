# 1 "TRACER-testwp9.map.tmp.c"
# 1 "<command-line>"
# 1 "TRACER-testwp9.map.tmp.c"
# 1 "MAP/SAFE-exbench/TRACER-testwp9.tmp.c"
# 1 "<command-line>"
# 1 "MAP/SAFE-exbench/TRACER-testwp9.tmp.c"
# 18 "MAP/SAFE-exbench/TRACER-testwp9.tmp.c"
void main(){
  int x;


  if (x>10){
    if ( !( x < 5 ) ) ; else errorFn();;
    x=x+2;
  }

}
