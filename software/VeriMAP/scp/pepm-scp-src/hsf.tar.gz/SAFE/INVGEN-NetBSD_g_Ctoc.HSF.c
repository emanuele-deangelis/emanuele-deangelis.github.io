# 1 "INVGEN-NetBSD_g_Ctoc.map.tmp.c"
# 1 "<command-line>"
# 1 "INVGEN-NetBSD_g_Ctoc.map.tmp.c"
# 1 "MAP/SAFE-exbench/INVGEN-NetBSD_g_Ctoc.tmp.c"
# 1 "<command-line>"
# 1 "MAP/SAFE-exbench/INVGEN-NetBSD_g_Ctoc.tmp.c"
# 20 "MAP/SAFE-exbench/INVGEN-NetBSD_g_Ctoc.tmp.c"
int BASE_SZ;
int __BLAST_NONDET;
int main ()
{


  int i;
  int j;
  int len = BASE_SZ;

  if(BASE_SZ > 0 ); else goto END;


  if ( 0 <= BASE_SZ-1 ) ; else errorFn();;

  if (len == 0)
    goto END;

  i = 0;
  j = 0;
  while (1) {
    if ( len == 0 ){
      goto END;
    } else {
      if ( 0<= j ) ; else errorFn();; if ( j < BASE_SZ ) ; else errorFn();;
      if ( 0<= i ) ; else errorFn();; if ( i < BASE_SZ ) ; else errorFn();;

      if ( __BLAST_NONDET ) {
        i++;
        j++;
        goto END;
      }
    }
    i ++;
    j ++;
    len --;
  }

 END: return 0;
}
