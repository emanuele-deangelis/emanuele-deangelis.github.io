# 1 "INVGEN-NetBSD_glob3_iny.map.tmp.c"
# 1 "<command-line>"
# 1 "INVGEN-NetBSD_glob3_iny.map.tmp.c"
# 1 "MAP/SAFE-exbench/INVGEN-NetBSD_glob3_iny.tmp.c"
# 1 "<command-line>"
# 1 "MAP/SAFE-exbench/INVGEN-NetBSD_glob3_iny.tmp.c"
# 20 "MAP/SAFE-exbench/INVGEN-NetBSD_glob3_iny.tmp.c"
int __BLAST_NONDET;

int main ()
{





  int buf_off, pattern_off, bound_off;

  int MAXPATHLEN;





  int error;

  int pathbuf_off;
  int pathend_off;
  int pathlim_off;





  if(MAXPATHLEN >0); else goto END;

  buf_off = 0;
  pattern_off = 0;

  bound_off = MAXPATHLEN;
# 67 "MAP/SAFE-exbench/INVGEN-NetBSD_glob3_iny.tmp.c"
  pathbuf_off = 0;
  pathend_off = 0;
  pathlim_off = MAXPATHLEN;



  error = 0;


  while (__BLAST_NONDET) {
    int i;


    if ( 0 <= pattern_off ) ; else errorFn();; if ( pattern_off <= MAXPATHLEN ) ; else errorFn();;

      if (__BLAST_NONDET) continue;




    i = 0;
    for (;;)
      if (i > MAXPATHLEN) goto END;
      else {
 if ( 0 <= i ) ; else errorFn();; if ( i <= MAXPATHLEN ) ; else errorFn();;

        i++;
        if (__BLAST_NONDET) goto END;
      }




    if ( 0 <= pathlim_off ) ; else errorFn();; if ( pathlim_off <= MAXPATHLEN ) ; else errorFn();;


    if (i > MAXPATHLEN){
      if ( __BLAST_NONDET ) {





 if ( __BLAST_NONDET ) {
   error = 5;
   goto END;
 }
 else {

   if ( 0 <= i ) ; else errorFn();;if ( i <= MAXPATHLEN + 1 ) ; else errorFn();;

   continue;
 }
      }
    }





    if ( __BLAST_NONDET) {

      if ( i <= MAXPATHLEN + 1 ) ; else errorFn();;

      continue;
    }
  END_LOOP1:
  }



 END: return 0;
}
