# 1 "INVGEN-gulwani_fig1a.map.tmp.c"
# 1 "<command-line>"
# 1 "INVGEN-gulwani_fig1a.map.tmp.c"
# 1 "MAP/SAFE-exbench/INVGEN-gulwani_fig1a.tmp.c"
# 1 "<command-line>"
# 1 "MAP/SAFE-exbench/INVGEN-gulwani_fig1a.tmp.c"
# 20 "MAP/SAFE-exbench/INVGEN-gulwani_fig1a.tmp.c"
int __BLAST_NONDET;
void main() {
  int x,y;

  x = -50;
  while( x < 0 ) {
 x = x+y;
 y++;
  }
  if ( y>0 ) ; else errorFn();;
}
