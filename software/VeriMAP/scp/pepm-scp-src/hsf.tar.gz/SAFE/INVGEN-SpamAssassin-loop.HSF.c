# 1 "INVGEN-SpamAssassin-loop.map.tmp.c"
# 1 "<command-line>"
# 1 "INVGEN-SpamAssassin-loop.map.tmp.c"
# 1 "MAP/SAFE-exbench/INVGEN-SpamAssassin-loop.tmp.c"
# 1 "<command-line>"
# 1 "MAP/SAFE-exbench/INVGEN-SpamAssassin-loop.tmp.c"
# 20 "MAP/SAFE-exbench/INVGEN-SpamAssassin-loop.tmp.c"
int __BLAST_NONDET;

void main ()
{
  int len;
  int i;
  int j;

  int bufsize;
  int limit = bufsize - 4;

  ;

  for (i = 0; i < len; ) {
    for (j = 0; i < len && j < limit; ){
      if (i + 1 < len){
 if ( i+1<len ) ; else errorFn();;
 if ( 0<=i ) ; else errorFn();;
 if( __BLAST_NONDET ) goto ELSE;
        if ( i<len ) ; else errorFn();;
 if ( 0<=i ) ; else errorFn();;
        if ( j<bufsize ) ; else errorFn();;
 if ( 0<=j ) ; else errorFn();;

        j++;
        i++;
        if ( i<len ) ; else errorFn();;
 if ( 0<=i ) ; else errorFn();;
        if ( j<bufsize ) ; else errorFn();;
 if ( 0<=j ) ; else errorFn();;


        j++;
        i++;
        if ( j<bufsize ) ; else errorFn();;
 if ( 0<=j ) ; else errorFn();;


        j++;
      } else {
ELSE:
        if ( i<len ) ; else errorFn();;
 if ( 0<=i ) ; else errorFn();;
        if ( j<bufsize ) ; else errorFn();;
 if ( 0<=j ) ; else errorFn();;


        j++;
        i++;
      }
    }
  }
}
