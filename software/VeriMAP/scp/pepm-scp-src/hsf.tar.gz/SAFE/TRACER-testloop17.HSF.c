# 1 "TRACER-testloop17.map.tmp.c"
# 1 "<command-line>"
# 1 "TRACER-testloop17.map.tmp.c"
# 1 "MAP/SAFE-exbench/TRACER-testloop17.tmp.c"
# 1 "<command-line>"
# 1 "MAP/SAFE-exbench/TRACER-testloop17.tmp.c"
# 23 "MAP/SAFE-exbench/TRACER-testloop17.tmp.c"
int main(int N)
{
  int i, j, k;

  i = 0;
  j = 0;
  k = 0;

  assume(N > 1);;

  while (i < N) {
    if (i<1)
      k = 1;
    else
      k = 0;
    j++;
    i++;
  }

  if ( !( k>0 ) ) ; else errorFn();;

  return 0;
}
