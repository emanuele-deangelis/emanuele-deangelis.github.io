# 1 "INVGEN-simple.map.tmp.c"
# 1 "<command-line>"
# 1 "INVGEN-simple.map.tmp.c"
# 1 "MAP/SAFE-exbench/INVGEN-simple.tmp.c"
# 1 "<command-line>"
# 1 "MAP/SAFE-exbench/INVGEN-simple.tmp.c"
# 20 "MAP/SAFE-exbench/INVGEN-simple.tmp.c"
void main() {
  int x=0;
  int n;

  assume(n > 0);;
  while( x < n ){
    x++;
  }
  if ( x<=n ) ; else errorFn();;
}
