# 1 "INVGEN-apache-escape-absolute.map.tmp.c"
# 1 "<command-line>"
# 1 "INVGEN-apache-escape-absolute.map.tmp.c"
# 1 "MAP/SAFE-exbench/INVGEN-apache-escape-absolute.tmp.c"
# 1 "<command-line>"
# 1 "MAP/SAFE-exbench/INVGEN-apache-escape-absolute.tmp.c"
# 20 "MAP/SAFE-exbench/INVGEN-apache-escape-absolute.tmp.c"
void main ()
{
  int __BLAST_NONDET;
  int scheme;
  int urilen,tokenlen;
  int cp,c;


  ;
  if(urilen>0); else goto END;
  if(tokenlen>0); else goto END;
  if(scheme >= 0 );else goto END;
  if (scheme == 0
      || (urilen-1 < scheme)) {
    goto END;
  }

  cp = scheme;

  if ( cp-1 < urilen ) ; else errorFn();;
  if ( 0 <= cp-1 ) ; else errorFn();;

  if (__BLAST_NONDET) {
    if ( cp < urilen ) ; else errorFn();;
    if ( 0 <= cp ) ; else errorFn();;
    while ( cp != urilen-1) {
      if(__BLAST_NONDET) break;
      if ( cp < urilen ) ; else errorFn();;
      if ( 0 <= cp ) ; else errorFn();;
      ++cp;
    }
    if ( cp < urilen ) ; else errorFn();;
    if ( 0 <= cp ) ; else errorFn();;
    if (cp == urilen-1) goto END;
    if ( cp+1 < urilen ) ; else errorFn();;
    if ( 0 <= cp+1 ) ; else errorFn();;
    if (cp+1 == urilen-1) goto END;
    ++cp;

    scheme = cp;

    if (__BLAST_NONDET) {
      c = 0;

      if ( cp < urilen ) ; else errorFn();;
      if ( 0<=cp ) ; else errorFn();;
      while ( cp != urilen-1
             && c < tokenlen - 1) {
 if ( cp < urilen ) ; else errorFn();;
 if ( 0<=cp ) ; else errorFn();;
        if (__BLAST_NONDET) {
          ++c;

   if ( c < tokenlen ) ; else errorFn();;
   if ( 0<=c ) ; else errorFn();;

   if ( cp < urilen ) ; else errorFn();;
   if ( 0<=cp ) ; else errorFn();;

        }
        ++cp;
      }
      goto END;
    }
  }

 END:
}
