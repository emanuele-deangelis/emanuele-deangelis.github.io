# 1 "SVCOMP13-loops-sum01_safe.map.tmp.c"
# 1 "<command-line>"
# 1 "SVCOMP13-loops-sum01_safe.map.tmp.c"
# 1 "MAP/SAFE-exbench/SVCOMP13-loops-sum01_safe.tmp.c"
# 1 "<command-line>"
# 1 "MAP/SAFE-exbench/SVCOMP13-loops-sum01_safe.tmp.c"
# 18 "MAP/SAFE-exbench/SVCOMP13-loops-sum01_safe.tmp.c"
void commentedOutVERIFIERassert(int cond) {
  if (!(cond)) {
    ERROR: goto ERROR;
  }
  return 0;
}

extern int __VERIFIER_nondet_int();
int main() {
  int i, n=__VERIFIER_nondet_int(), sn=0;
  for(i=1; i<=n; i++) {
    sn = sn + (2);
  }
  if ( sn==n*(2) || sn == 0 ) ; else errorFn();;
}
