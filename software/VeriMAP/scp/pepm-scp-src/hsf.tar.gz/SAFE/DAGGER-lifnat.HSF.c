# 1 "DAGGER-lifnat.map.tmp.c"
# 1 "<command-line>"
# 1 "DAGGER-lifnat.map.tmp.c"
# 1 "MAP/SAFE-exbench/DAGGER-lifnat.tmp.c"
# 1 "<command-line>"
# 1 "MAP/SAFE-exbench/DAGGER-lifnat.tmp.c"
# 18 "MAP/SAFE-exbench/DAGGER-lifnat.tmp.c"
int nondet() {int i; return i;}


int main()
{
 int I;
 int Sa;
 int Ea;
 int Ma;
 int Sb;
 int Eb;
 int Mb;

 if (! (I>=1)) return 0;
 Sa=0;
 Ea=0;
 Ma=0;
 Sb=0;
 Eb=0;
 Mb=0;

 while(nondet())
 {
  if (nondet())
  {
   if (! (Eb >=1)) return 0;
   Eb = Eb -1;
   Mb = Mb +1;
  }
  else
  {
   if (nondet())
   {
    if (! (Ea >=1)) return 0;
    Ea = Ea -1;
    Ma = Ma +1;
   }
   else
   {
    if (nondet())
    {
     if (! (Sa>=1)) return 0;
     Sa=Sa-1;
     I=I+Sb+Eb+Mb;
     Sb=0;
     Eb=1;
     Mb=0;

    }
    else
    {
     if (nondet())
     {
      if (! (Sb>=1)) return 0;
      I=I+Sb+Eb+Mb;
      Sb=0;
      Eb=1;
      Mb=0;
     }
     else
     {
      if (nondet())
      {

       if (! (Sb>=1)) return 0;
       Sb=Sb-1;
       I=I+Sa+Ea+Ma;
       Sa=0;
       Ea=1;
       Ma=0;

      }
      else
      {
       if (nondet())
       {
        if (! (Sa>=1)) return 0;
        I=I+Sa+Ea+Ma;
        Sa=0;
        Ea=1;
        Ma=0;
       }
       else
       {
        if (nondet())
        {
         if (! (Sa>=1)) return 0;
         Sa=Sa-1;
         Sb=Sb+Eb+Mb+1;
         Eb=0;
         Mb=0;
        }
        else
        {
         if (nondet())
         {
          if (! (I>=1)) return 0;
          I=I-1;
          Sb=Sb+Eb+Mb+1;
          Eb=0;
          Mb=0;
         }
         else
         {
          if (nondet())
          {
           if (! (I >= 1)) return 0;
           I = I -1;
           Sa = Sa + Ea + Ma + 1;
           Ea = 0;
           Ma =0;
          }
          else
          {
           if (! (Sb >= 1)) return 0;
           Sb = Sb-1;
           Sa = Ea+Ma+1;
           Ea = 0;
           Ma = 0;

          }
         }
        }
       }
      }
     }
    }
   }
  }
 }

 if ( Ea + Ma <= 1 ) ; else errorFn();;
 if ( Eb + Mb <= 1 ) ; else errorFn();;
 if ( I >= 0 ) ; else errorFn();;
 if ( Sa >= 0 ) ; else errorFn();;
 if ( Ma >= 0 ) ; else errorFn();;
 if ( Ea >= 0 ) ; else errorFn();;
 if ( Sb >= 0 ) ; else errorFn();;
 if ( Mb >= 0 ) ; else errorFn();;
 if ( Eb >= 0 ) ; else errorFn();;
 if ( I + Sa + Ea + Ma + Sb + Eb + Mb >= 1 ) ; else errorFn();;
}
