# 1 "SVCOMP13-loops-sum04_safe.map.tmp.c"
# 1 "<command-line>"
# 1 "SVCOMP13-loops-sum04_safe.map.tmp.c"
# 1 "MAP/SAFE-exbench/SVCOMP13-loops-sum04_safe.tmp.c"
# 1 "<command-line>"
# 1 "MAP/SAFE-exbench/SVCOMP13-loops-sum04_safe.tmp.c"
# 18 "MAP/SAFE-exbench/SVCOMP13-loops-sum04_safe.tmp.c"
void commentedOutVERIFIERassert(int cond) {
  if (!(cond)) {
    ERROR: goto ERROR;
  }
  return 0;
}


int main() {
  int i, sn=0;
  for(i=1; i<=8; i++) {
    sn = sn + (2);
  }
  if ( sn==8*(2) || sn == 0 ) ; else errorFn();;
}
