# 1 "INVGEN-sendmail-close-angle.map.tmp.c"
# 1 "<command-line>"
# 1 "INVGEN-sendmail-close-angle.map.tmp.c"
# 1 "MAP/SAFE-exbench/INVGEN-sendmail-close-angle.tmp.c"
# 1 "<command-line>"
# 1 "MAP/SAFE-exbench/INVGEN-sendmail-close-angle.tmp.c"
# 25 "MAP/SAFE-exbench/INVGEN-sendmail-close-angle.tmp.c"
int main (void)
{






  int __BLAST_NONDET;
  int in;
  int inlen;
  int bufferlen;
  int buf;
  int buflim;


  ;

  if(bufferlen >1);else goto END;
  if(inlen > 0);else goto END;
  if(bufferlen < inlen);else goto END;




  buf = 0;
  in = 0;
  buflim = bufferlen - 2;



  while (__BLAST_NONDET)
  {
    if (buf == buflim)
      break;
    if ( 0<=buf ) ; else errorFn();;
    if ( buf<bufferlen ) ; else errorFn();;

    buf++;
out:
    in++;
    if ( 0<=in ) ; else errorFn();;
    if ( in<inlen ) ; else errorFn();;

  }

    if ( 0<=buf ) ; else errorFn();;
    if ( buf<bufferlen ) ; else errorFn();;

  buf++;


  if ( 0<=buf ) ; else errorFn();;
  if ( buf<bufferlen ) ; else errorFn();;


  buf++;

 END: return 0;
}
