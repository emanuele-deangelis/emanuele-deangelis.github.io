# 1 "MAP/SAFE-exbench/TRACER-testwp7.tmp.c"
# 1 "<command-line>"
# 1 "MAP/SAFE-exbench/TRACER-testwp7.tmp.c"
# 25 "MAP/SAFE-exbench/TRACER-testwp7.tmp.c"
main()
{
  int x, y, z;



        if (x>0) {



          z = 2;
        }
        else {



          x = 0;
        }
# 57 "MAP/SAFE-exbench/TRACER-testwp7.tmp.c"
        if (y>0) {



          z = 3;
        }
        else {



          y = 1;
        }



  __VERIFIER_assert(!( x+y<=0 ));
}
