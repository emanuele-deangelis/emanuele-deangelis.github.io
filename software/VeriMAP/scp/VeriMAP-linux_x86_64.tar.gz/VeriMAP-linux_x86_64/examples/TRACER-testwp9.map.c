# 1 "MAP/SAFE-exbench/TRACER-testwp9.tmp.c"
# 1 "<command-line>"
# 1 "MAP/SAFE-exbench/TRACER-testwp9.tmp.c"
# 18 "MAP/SAFE-exbench/TRACER-testwp9.tmp.c"
void main(){
  int x;


  if (x>10){
    __VERIFIER_assert(!( x < 5 ));
    x=x+2;
  }

}
