# 1 "MAP/SAFE-exbench/TRACER-testabs9.tmp.c"
# 1 "<command-line>"
# 1 "MAP/SAFE-exbench/TRACER-testabs9.tmp.c"
# 27 "MAP/SAFE-exbench/TRACER-testabs9.tmp.c"
void main(){

  int x,y;
  y=99;
  x=0;


  __VERIFIER_assert(!( x<0 ));

}
